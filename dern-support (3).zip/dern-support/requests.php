<?php
$pageTitle = 'Засварын хүсэлтүүд';
require_once 'includes/config.php';
requireLogin();
$db = getDB();
$uid = $_SESSION['user_id'];

$r = $db->prepare("SELECT * FROM support_requests WHERE user_id=? ORDER BY created_at DESC");
$r->bind_param('i', $uid);
$r->execute();
$requests = $r->get_result()->fetch_all(MYSQLI_ASSOC);

$statusMn = ['pending'=>'Хүлээгдэж буй','scheduled'=>'Товлосон','in_progress'=>'Хийгдэж байна','completed'=>'Дууссан','cancelled'=>'Цуцлагдсан'];
$priorityMn = ['low'=>'Бага','medium'=>'Дунд','high'=>'Өндөр','urgent'=>'Яаралтай'];

require_once 'includes/header.php';
?>

<div class="page-header">
    <div class="page-header-inner">
        <h1>🎫 Засварын хүсэлтүүд</h1>
        <a href="new_request.php" class="btn btn-primary">➕ Шинэ хүсэлт</a>
    </div>
</div>

<div class="section">
    <div class="container">
        <div class="table-container">
            <div class="table-header">
                <div class="search-box" style="margin:0;flex:1;max-width:400px;">
                    <input type="text" id="searchInput" placeholder="Хайх...">
                </div>
                <span style="color:var(--gray);font-size:0.9rem;">Нийт: <?= count($requests) ?></span>
            </div>
            <?php if (empty($requests)): ?>
                <div style="padding:60px;text-align:center;color:var(--gray);">
                    <i class="fas fa-inbox" style="font-size:4rem;display:block;margin-bottom:16px;opacity:.2;"></i>
                    <h3>Хүсэлт байхгүй байна</h3>
                    <p style="margin-bottom:20px;">Та одоогоор ямар ч засварын хүсэлт гаргаагүй байна.</p>
                    <a href="new_request.php" class="btn btn-primary">➕ Шинэ хүсэлт гаргах</a>
                </div>
            <?php else: ?>
                <table id="dataTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Гарчиг</th>
                            <th>Тоног төхөөрөмж</th>
                            <th>Тэргүүлэх</th>
                            <th>Төлөв</th>
                            <th>Үнийн санал</th>
                            <th>Товлосон</th>
                            <th>Үйлдэл</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($requests as $req): ?>
                        <tr>
                            <td><?= $req['id'] ?></td>
                            <td><strong><?= clean($req['title']) ?></strong></td>
                            <td><?= clean($req['device_type'] ?? '-') ?></td>
                            <td><span class="badge badge-<?= $req['priority'] ?>"><?= $priorityMn[$req['priority']] ?></span></td>
                            <td><span class="badge badge-<?= $req['status'] ?>"><?= $statusMn[$req['status']] ?></span></td>
                            <td><?= $req['estimated_cost'] ? number_format($req['estimated_cost']) . '₮' : '-' ?></td>
                            <td><?= $req['scheduled_date'] ? date('Y-м-d', strtotime($req['scheduled_date'])) : '-' ?></td>
                            <td>
                                <a href="view_request.php?id=<?= $req['id'] ?>" class="btn btn-primary btn-sm">👁</a>
                                <?php if ($req['status'] === 'pending'): ?>
                                <a href="delete_request.php?id=<?= $req['id'] ?>" class="btn btn-danger btn-sm btn-delete">🗑️</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
