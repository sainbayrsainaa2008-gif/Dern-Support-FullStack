<?php
$pageTitle = 'Нүүр хуудас';
require_once 'includes/header.php';
$db = getDB();

// Статистик мэдээлэл
$stats = [];
$r = $db->query("SELECT COUNT(*) as c FROM support_requests"); $stats['requests'] = $r->fetch_assoc()['c'];
$r = $db->query("SELECT COUNT(*) as c FROM users"); $stats['users'] = $r->fetch_assoc()['c'];
$r = $db->query("SELECT COUNT(*) as c FROM knowledge_base"); $stats['kb'] = $r->fetch_assoc()['c'];
$r = $db->query("SELECT COUNT(*) as c FROM support_requests WHERE status='completed'"); $stats['completed'] = $r->fetch_assoc()['c'];
?>

<!-- Hero хэсэг -->
<div class="hero">
    <div class="container">
        <h1>Тавтай морил, <span>Dern-Support</span>-д</h1>
        <p>Таны компьютер, лаптоп болон бусад тоног төхөөрөмжийн найдвартай засварын үйлчилгээ. Хурдан, найдвартай, хямд.</p>
        <div class="hero-btns">
            <?php if (!isset($_SESSION['user_id'])): ?>
                <a href="register.php" class="btn btn-primary">➕ Бүртгүүлэх</a>
                <a href="login.php" class="btn btn-secondary">🔑 Нэвтрэх</a>
            <?php else: ?>
                <a href="new_request.php" class="btn btn-primary">➕ Хүсэлт гаргах</a>
                <a href="dashboard.php" class="btn btn-secondary">📊 Хяналтын самбар</a>
            <?php endif; ?>
            <a href="knowledge.php" class="btn btn-secondary">📚 Мэдлэгийн сан</a>
        </div>
    </div>
</div>

<!-- Статистик -->
<div class="section" style="background:#fff; padding:40px 20px;">
    <div class="container">
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon icon-blue">🎫</div>
                <div class="stat-info"><h3><?= $stats['requests'] ?></h3><p>Нийт хүсэлт</p></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon icon-green">✅</div>
                <div class="stat-info"><h3><?= $stats['completed'] ?></h3><p>Дууссан засвар</p></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon icon-yellow">👥</div>
                <div class="stat-info"><h3><?= $stats['users'] ?></h3><p>Бүртгэлтэй хэрэглэгч</p></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon icon-red">📚</div>
                <div class="stat-info"><h3><?= $stats['kb'] ?></h3><p>Мэдлэгийн нийтлэл</p></div>
            </div>
        </div>
    </div>
</div>

<!-- Үйлчилгээнүүд -->
<div class="section">
    <div class="container">
        <div class="section-title">
            <h2>Бидний үйлчилгээ</h2>
            <p>Мэргэжлийн техникийн тусламжийг хурдан, найдвартай хүргэнэ</p>
        </div>
        <div class="cards-grid">
            <div class="card">
                <div class="card-icon icon-blue">🖥️</div>
                <h3>Компьютерийн засвар</h3>
                <p>Ширээний болон зөөврийн компьютерийн тоног төхөөрөмж, программ хангамжийн бүх төрлийн засвар</p>
            </div>
            <div class="card">
                <div class="card-icon icon-green">🏢</div>
                <h3>Бизнесийн дэмжлэг</h3>
                <p>Бизнесийн байршилд очиж үйлчилгээ үзүүлэх. Сүлжээ, сервер болон ажлын компьютерийн засвар</p>
            </div>
            <div class="card">
                <div class="card-icon icon-yellow">📖</div>
                <h3>Мэдлэгийн сан</h3>
                <p>Нийтлэг асуудлуудыг өөрөө шийдвэрлэх зөвлөмж, заавар болон шийдлүүд</p>
            </div>
            <div class="card">
                <div class="card-icon icon-red">⏰</div>
                <h3>Яаралтай засвар</h3>
                <p>Яаралтай тохиолдолд 24 цагийн дотор хариу өгч, засварыг хурдан гүйцэтгэнэ</p>
            </div>
        </div>
    </div>
</div>

<!-- Хэрхэн ажилладаг -->
<div class="section" style="background: #fff;">
    <div class="container">
        <div class="section-title">
            <h2>Хэрхэн ажилладаг вэ?</h2>
        </div>
        <div class="cards-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));">
            <div class="card" style="text-align:center;">
                <div class="card-icon icon-blue" style="margin:0 auto 16px;"><span style="font-size:1.3rem;font-weight:700;">1</span></div>
                <h3>Бүртгүүлэх</h3>
                <p>Хувь хүн эсвэл бизнесийн аккаунт үүсгэнэ</p>
            </div>
            <div class="card" style="text-align:center;">
                <div class="card-icon icon-yellow" style="margin:0 auto 16px;"><span style="font-size:1.3rem;font-weight:700;">2</span></div>
                <h3>Хүсэлт гаргах</h3>
                <p>Асуудлаа тайлбарлаж, засварын хүсэлт илгээнэ</p>
            </div>
            <div class="card" style="text-align:center;">
                <div class="card-icon icon-green" style="margin:0 auto 16px;"><span style="font-size:1.3rem;font-weight:700;">3</span></div>
                <h3>Захиалга авах</h3>
                <p>Манай мэргэжилтэн тохиромжтой цагийг товлоно</p>
            </div>
            <div class="card" style="text-align:center;">
                <div class="card-icon icon-red" style="margin:0 auto 16px;"><span style="font-size:1.3rem;font-weight:700;">4</span></div>
                <h3>Засвар дуусгах</h3>
                <p>Мэргэжилтэн засварыг гүйцэтгэж, тайлагнана</p>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
