<?php
$pageTitle = 'Бүртгүүлэх';
require_once 'includes/config.php';

if (isset($_SESSION['user_id'])) { header('Location: ' . SITE_URL . '/dashboard.php'); exit; }

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = getDB();
    $type = clean($_POST['account_type'] ?? 'individual');
    $fname = clean($_POST['first_name'] ?? '');
    $lname = clean($_POST['last_name'] ?? '');
    $company = clean($_POST['company_name'] ?? '');
    $email = clean($_POST['email'] ?? '');
    $phone = clean($_POST['phone'] ?? '');
    $address = clean($_POST['address'] ?? '');
    $pass = $_POST['password'] ?? '';
    $pass2 = $_POST['password2'] ?? '';

    if (!$fname || !$lname || !$email || !$pass) {
        $error = 'Бүх заавал талбаруудыг бөглөнө үү.';
    } elseif ($pass !== $pass2) {
        $error = 'Нууц үгнүүд таарахгүй байна.';
    } elseif (strlen($pass) < 6) {
        $error = 'Нууц үг хамгийн багадаа 6 тэмдэгт байх ёстой.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'И-мэйл хаяг буруу байна.';
    } else {
        $check = $db->prepare("SELECT id FROM users WHERE email = ?");
        $check->bind_param('s', $email);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            $error = 'Энэ и-мэйл хаяг аль хэдийн бүртгэгдсэн байна.';
        } else {
            $hashed = password_hash($pass, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO users (account_type, first_name, last_name, company_name, email, phone, address, password) VALUES (?,?,?,?,?,?,?,?)");
            $stmt->bind_param('ssssssss', $type, $fname, $lname, $company, $email, $phone, $address, $hashed);
            if ($stmt->execute()) {
                $success = 'Бүртгэл амжилттай. Та одоо нэвтэрч болно.';
            } else {
                $error = 'Бүртгэл амжилтгүй боллоо. Дахин оролдоно уу.';
            }
        }
    }
}

require_once 'includes/header.php';
?>

<div class="form-container" style="max-width:600px;">
    <h2><i class="fas fa-user-plus" style="color:var(--primary)"></i> Бүртгүүлэх</h2>
    <?php if ($error): ?><div class="alert alert-danger">❗ <?= $error ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success">✅ <?= $success ?> <a href="login.php">Нэвтрэх</a></div><?php endif; ?>

    <form method="POST" id="mainForm">
        <div class="form-group">
            <label>Аккаунтын төрөл *</label>
            <select name="account_type" required onchange="toggleCompany(this.value)">
                <option value="individual">Хувь хүн</option>
                <option value="business">Бизнес / Байгууллага</option>
            </select>
        </div>
        <div class="form-group" id="company_group" style="display:none;">
            <label>Байгууллагын нэр</label>
            <input type="text" name="company_name" placeholder="Байгууллагын нэр оруулна уу">
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Нэр *</label>
                <input type="text" name="first_name" placeholder="Таны нэр" required value="<?= clean($_POST['first_name'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Овог *</label>
                <input type="text" name="last_name" placeholder="Таны овог" required value="<?= clean($_POST['last_name'] ?? '') ?>">
            </div>
        </div>
        <div class="form-group">
            <label>И-мэйл хаяг *</label>
            <input type="email" name="email" placeholder="example@email.com" required value="<?= clean($_POST['email'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Утасны дугаар</label>
            <input type="tel" name="phone" placeholder="99001234" value="<?= clean($_POST['phone'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Хаяг</label>
            <textarea name="address" placeholder="Таны хаяг"><?= clean($_POST['address'] ?? '') ?></textarea>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Нууц үг *</label>
                <input type="password" name="password" placeholder="Хамгийн багадаа 6 тэмдэгт" required>
            </div>
            <div class="form-group">
                <label>Нууц үг давтах *</label>
                <input type="password" name="password2" placeholder="Нууц үгийг давтана уу" required>
            </div>
        </div>
        <button type="submit" class="btn btn-primary btn-full">➕ Бүртгүүлэх</button>
    </form>
    <div class="form-link">Аль хэдийн бүртгэлтэй юу? <a href="login.php">Нэвтрэх</a></div>
</div>

<script>
function toggleCompany(val) {
    document.getElementById('company_group').style.display = val === 'business' ? 'block' : 'none';
}
</script>

<?php require_once 'includes/footer.php'; ?>
