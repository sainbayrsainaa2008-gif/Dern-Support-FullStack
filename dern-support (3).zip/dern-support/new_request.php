<?php
$pageTitle = 'Шинэ хүсэлт гаргах';
require_once 'includes/config.php';
requireLogin();
$db = getDB();
$uid = $_SESSION['user_id'];

$error = ''; $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = clean($_POST['title'] ?? '');
    $desc = clean($_POST['description'] ?? '');
    $device = clean($_POST['device_type'] ?? '');
    $priority = clean($_POST['priority'] ?? 'medium');
    $date = clean($_POST['scheduled_date'] ?? '');
    $time = clean($_POST['scheduled_time'] ?? '');

    if (!$title || !$desc) {
        $error = 'Гарчиг болон тайлбарыг заавал оруулна уу.';
    } else {
        $stmt = $db->prepare("INSERT INTO support_requests (user_id, title, description, device_type, priority, scheduled_date, scheduled_time) VALUES (?,?,?,?,?,?,?)");
        $dateVal = $date ?: null;
        $timeVal = $time ?: null;
        $stmt->bind_param('issssss', $uid, $title, $desc, $device, $priority, $dateVal, $timeVal);
        if ($stmt->execute()) {
            $newId = $db->insert_id;
            header('Location: ' . SITE_URL . '/view_request.php?id=' . $newId . '&success=1');
            exit;
        } else {
            $error = 'Хүсэлт үүсгэхэд алдаа гарлаа. Дахин оролдоно уу.';
        }
    }
}

require_once 'includes/header.php';
?>

<div class="page-header">
    <div class="page-header-inner">
        <h1>➕ Шинэ засварын хүсэлт</h1>
        <a href="requests.php" class="btn btn-secondary" style="background:var(--border);color:var(--dark);">←  Буцах</a>
    </div>
</div>

<div class="section">
    <div class="container">
        <div class="form-container" style="max-width:680px;">
            <?php if ($error): ?><div class="alert alert-danger">❗ <?= $error ?></div><?php endif; ?>

            <form method="POST" id="mainForm">
                <div class="form-group">
                    <label>Хүсэлтийн гарчиг *</label>
                    <input type="text" name="title" placeholder="Жишээ: Компьютер асахгүй байна" required value="<?= clean($_POST['title'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Тайлбар *</label>
                    <textarea name="description" placeholder="Асуудлаа дэлгэрэнгүй тайлбарлана уу. Хэзээнээс эхэлсэн, ямар алдааны мэдэгдэл гарч байгаа зэргийг оруулна уу." required rows="5"><?= clean($_POST['description'] ?? '') ?></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Тоног төхөөрөмжийн төрөл</label>
                        <select name="device_type">
                            <option value="">-- Сонгоно уу --</option>
                            <option value="Ширээний компьютер">Ширээний компьютер</option>
                            <option value="Зөөврийн компьютер">Зөөврийн компьютер</option>
                            <option value="Принтер">Принтер</option>
                            <option value="Монитор">Монитор</option>
                            <option value="Сервер">Сервер</option>
                            <option value="Сүлжээний тоног төхөөрөмж">Сүлжээний тоног төхөөрөмж</option>
                            <option value="Бусад">Бусад</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Яаралтай эсэх</label>
                        <select name="priority">
                            <option value="low">Бага - Ямар нэг цагт</option>
                            <option value="medium" selected>Дунд - 2-3 хоногийн дотор</option>
                            <option value="high">Өндөр - 24 цагийн дотор</option>
                            <option value="urgent">Яаралтай - Яаралтай тусламж</option>
                        </select>
                    </div>
                </div>

                <div style="background:var(--light);border-radius:8px;padding:20px;margin-bottom:20px;">
                    <h4 style="margin-bottom:14px;color:var(--dark);">📅 Цаг товлох (заавал биш)</h4>
                    <div class="form-row">
                        <div class="form-group" style="margin:0;">
                            <label>Өдөр</label>
                            <input type="date" name="scheduled_date" min="<?= date('Y-m-d') ?>" value="<?= clean($_POST['scheduled_date'] ?? '') ?>">
                        </div>
                        <div class="form-group" style="margin:0;">
                            <label>Цаг</label>
                            <input type="time" name="scheduled_time" value="<?= clean($_POST['scheduled_time'] ?? '') ?>">
                        </div>
                    </div>
                </div>

                <div style="background:#fef3c7;border-radius:8px;padding:14px;margin-bottom:20px;font-size:0.9rem;color:#92400e;">
                    ℹ️ Хүсэлт илгээсний дараа манай мэргэжилтэн тантай холбоо барьж, нарийвчилсан мэдээлэл авна.
                </div>

                <button type="submit" class="btn btn-primary btn-full">📨 Хүсэлт илгээх</button>
            </form>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
