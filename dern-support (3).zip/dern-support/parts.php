<?php
$pageTitle = 'Нөөц эд анги';
require_once 'includes/config.php';
requireLogin();
$db = getDB();

$search = clean($_GET['search'] ?? '');
$sql = "SELECT * FROM spare_parts" . ($search ? " WHERE name LIKE ? OR category LIKE ? OR part_number LIKE ?" : "") . " ORDER BY category, name";

if ($search) {
    $stmt = $db->prepare($sql);
    $s = "%$search%";
    $stmt->bind_param('sss', $s, $s, $s);
    $stmt->execute();
    $parts = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} else {
    $parts = $db->query($sql)->fetch_all(MYSQLI_ASSOC);
}

require_once 'includes/header.php';
?>

<div class="page-header">
    <div class="page-header-inner">
        <h1>⚙️ Нөөц эд ангиуд</h1>
    </div>
</div>

<div class="section">
    <div class="container">
        <form method="GET" style="display:flex;gap:10px;margin-bottom:24px;">
            <input type="text" name="search" placeholder="Эд ангийн нэр, ангилал хайх..." value="<?= $search ?>" style="flex:1;padding:10px 16px;border:2px solid var(--border);border-radius:8px;font-size:.95rem;">
            <button type="submit" class="btn btn-primary">🔍 Хайх</button>
            <?php if ($search): ?><a href="parts.php" class="btn" style="background:var(--border);color:var(--dark);">✕</a><?php endif; ?>
        </form>

        <div class="table-container">
            <div class="table-header">
                <h3>Нөөцийн жагсаалт</h3>
                <span style="color:var(--gray);font-size:.9rem;">Нийт: <?= count($parts) ?> эд анги</span>
            </div>
            <table>
                <thead>
                    <tr><th>Нэр</th><th>Дугаар</th><th>Ангилал</th><th>Тоо хэмжээ</th><th>Үнэ</th><th>Нийлүүлэгч</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($parts)): ?>
                    <tr><td colspan="6" style="text-align:center;color:var(--gray);padding:40px;">Үр дүн олдсонгүй</td></tr>
                    <?php else: ?>
                    <?php foreach ($parts as $p): ?>
                    <tr>
                        <td><strong><?= clean($p['name']) ?></strong></td>
                        <td style="font-family:monospace;color:var(--gray);"><?= clean($p['part_number'] ?? '-') ?></td>
                        <td><?= clean($p['category'] ?? '-') ?></td>
                        <td>
                            <span class="badge" style="background:<?= $p['quantity'] > 5 ? '#d1fae5' : ($p['quantity'] > 0 ? '#fef3c7' : '#fee2e2') ?>;color:<?= $p['quantity'] > 5 ? '#065f46' : ($p['quantity'] > 0 ? '#92400e' : '#991b1b') ?>;">
                                <?= $p['quantity'] ?> ширхэг
                            </span>
                        </td>
                        <td style="color:var(--success);font-weight:600;"><?= $p['unit_price'] ? number_format($p['unit_price']) . '₮' : '-' ?></td>
                        <td><?= clean($p['supplier'] ?? '-') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
