<?php
// Өгөгдлийн сантай холбогдох тохиргоо
// XAMPP дээр ажиллуулахад зориулсан

define('DB_HOST', 'localhost');
define('DB_USER', 'root');        // XAMPP-ийн default хэрэглэгч
define('DB_PASS', '');            // XAMPP-ийн default нууц үг (хоосон)
define('DB_NAME', 'dern_support');
define('SITE_NAME', 'Dern-Support');

define('SITE_URL', 'http://localhost:8080/dern-support');

// Нэвтрэх хуудас руу чиглүүлэх
function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: ' . SITE_URL . '/login.php');
        exit;
    }
}

// Өгөгдлийн сантай холбогдох
function getDB() {
    static $conn = null;
    if ($conn === null) {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        $conn->set_charset('utf8mb4');
        if ($conn->connect_error) {
            die('<div style="padding:20px;background:#fee;color:#c00;font-family:Arial;">
                <h2>Өгөгдлийн сантай холбогдох алдаа</h2>
                <p>XAMPP-ийн MySQL ажиллаж байгааг шалгана уу.</p>
                <p>Алдаа: ' . $conn->connect_error . '</p>
            </div>');
        }
    }
    return $conn;
}

// XSS-ээс хамгаалах
function clean($str) {
    return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}

// Session эхлүүлэх
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
