<?php
require_once __DIR__ . '/config.php';
?>
<!DOCTYPE html>
<html lang="mn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? clean($pageTitle) . ' | ' : '' ?>Dern-Support</title>
    <style>
* { margin: 0; padding: 0; box-sizing: border-box; }
:root {
    --primary: #1a56db; --primary-dark: #1341b0; --secondary: #f59e0b;
    --success: #10b981; --danger: #ef4444; --warning: #f59e0b;
    --dark: #1e293b; --gray: #64748b; --light: #f1f5f9;
    --white: #fff; --border: #e2e8f0;
    --shadow: 0 4px 6px -1px rgba(0,0,0,.1); --radius: 10px;
}
body { font-family: 'Segoe UI', Arial, sans-serif; background: var(--light); color: var(--dark); }
/* NAVBAR */
.navbar { background: var(--dark); position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 10px rgba(0,0,0,.3); }
.nav-container { max-width: 1200px; margin: 0 auto; padding: 0 20px; display: flex; align-items: center; justify-content: space-between; height: 64px; }
.nav-logo { color: #fff; text-decoration: none; font-size: 1.4rem; font-weight: 700; }
.nav-links { display: flex; align-items: center; gap: 4px; flex-wrap: wrap; }
.nav-links a { color: #cbd5e1; text-decoration: none; padding: 8px 13px; border-radius: 8px; font-size: 0.88rem; transition: all 0.2s; }
.nav-links a:hover { background: rgba(255,255,255,.1); color: #fff; }
.btn-nav-login { background: var(--primary) !important; color: #fff !important; }
.btn-nav-register { background: var(--secondary) !important; color: var(--dark) !important; font-weight: 700; }
.btn-nav-logout { background: rgba(239,68,68,.2) !important; color: #fca5a5 !important; }
/* MAIN */
.main-content { min-height: calc(100vh - 64px - 220px); }
/* HERO */
.hero { background: linear-gradient(135deg, #1e293b 0%, #1e3a5f 60%, #1a56db 100%); color: #fff; padding: 80px 20px; text-align: center; }
.hero h1 { font-size: 2.6rem; margin-bottom: 16px; line-height: 1.2; }
.hero h1 span { color: var(--secondary); }
.hero p { font-size: 1.1rem; color: #94a3b8; max-width: 580px; margin: 0 auto 36px; line-height: 1.7; }
.hero-btns { display: flex; gap: 14px; justify-content: center; flex-wrap: wrap; }
/* BUTTONS */
.btn { display: inline-flex; align-items: center; gap: 7px; padding: 11px 22px; border-radius: 8px; font-size: 0.95rem; font-weight: 600; cursor: pointer; text-decoration: none; border: none; transition: all 0.2s; line-height: 1; }
.btn-primary { background: var(--primary); color: #fff; }
.btn-primary:hover { background: var(--primary-dark); transform: translateY(-1px); box-shadow: 0 4px 12px rgba(26,86,219,.4); }
.btn-secondary { background: transparent; color: #fff; border: 2px solid rgba(255,255,255,.3); }
.btn-secondary:hover { background: rgba(255,255,255,.1); }
.btn-success { background: var(--success); color: #fff; }
.btn-danger { background: var(--danger); color: #fff; }
.btn-sm { padding: 6px 13px; font-size: 0.82rem; }
.btn-full { width: 100%; justify-content: center; padding: 13px; }
/* SECTIONS */
.section { padding: 60px 20px; }
.container { max-width: 1200px; margin: 0 auto; }
.section-title { text-align: center; margin-bottom: 44px; }
.section-title h2 { font-size: 2rem; color: var(--dark); margin-bottom: 10px; }
.section-title p { color: var(--gray); font-size: 1rem; }
/* CARDS */
.cards-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 24px; }
.card { background: #fff; border-radius: var(--radius); padding: 28px; box-shadow: var(--shadow); transition: transform 0.2s, box-shadow 0.2s; border: 1px solid var(--border); }
.card:hover { transform: translateY(-4px); box-shadow: 0 12px 24px rgba(0,0,0,.12); }
.card-icon { width: 54px; height: 54px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.6rem; margin-bottom: 18px; }
.icon-blue { background: #dbeafe; }
.icon-green { background: #d1fae5; }
.icon-yellow { background: #fef3c7; }
.icon-red { background: #fee2e2; }
.card h3 { font-size: 1.08rem; margin-bottom: 9px; color: var(--dark); }
.card p { color: var(--gray); font-size: 0.91rem; line-height: 1.65; }
/* STATS */
.stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 20px; margin-bottom: 32px; }
.stat-card { background: #fff; border-radius: var(--radius); padding: 22px 20px; box-shadow: var(--shadow); display: flex; align-items: center; gap: 16px; border: 1px solid var(--border); }
.stat-icon { width: 52px; height: 52px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.6rem; flex-shrink: 0; }
.stat-info h3 { font-size: 2rem; font-weight: 700; color: var(--dark); line-height: 1; }
.stat-info p { color: var(--gray); font-size: 0.82rem; margin-top: 4px; }
/* FORMS */
.form-container { max-width: 520px; margin: 40px auto; background: #fff; border-radius: var(--radius); padding: 40px; box-shadow: var(--shadow); border: 1px solid var(--border); }
.form-container h2 { text-align: center; margin-bottom: 28px; font-size: 1.5rem; }
.form-group { margin-bottom: 20px; }
.form-group label { display: block; margin-bottom: 6px; font-weight: 600; font-size: 0.88rem; }
.form-group input, .form-group select, .form-group textarea { width: 100%; padding: 11px 14px; border: 2px solid var(--border); border-radius: 8px; font-size: 0.94rem; transition: border-color 0.2s; font-family: inherit; background: #fff; }
.form-group input:focus, .form-group select:focus, .form-group textarea:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(26,86,219,.08); }
.form-group textarea { resize: vertical; min-height: 100px; line-height: 1.6; }
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.form-link { text-align: center; margin-top: 18px; color: var(--gray); font-size: 0.9rem; }
.form-link a { color: var(--primary); text-decoration: none; font-weight: 600; }
/* ALERTS */
.alert { padding: 13px 17px; border-radius: 8px; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; font-size: 0.93rem; }
.alert-success { background: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; }
.alert-danger { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
.alert-info { background: #dbeafe; color: #1e40af; border: 1px solid #93c5fd; }
/* TABLE */
.table-container { background: #fff; border-radius: var(--radius); box-shadow: var(--shadow); overflow: hidden; border: 1px solid var(--border); }
.table-header { padding: 18px 22px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; gap: 12px; flex-wrap: wrap; }
.table-header h3 { font-size: 1rem; }
table { width: 100%; border-collapse: collapse; }
th { background: var(--light); padding: 11px 15px; text-align: left; font-size: 0.8rem; color: var(--gray); font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; border-bottom: 1px solid var(--border); }
td { padding: 13px 15px; border-bottom: 1px solid var(--border); font-size: 0.91rem; }
tr:last-child td { border: none; }
tbody tr:hover td { background: #f8fafc; }
/* BADGES */
.badge { display: inline-flex; padding: 3px 10px; border-radius: 20px; font-size: 0.77rem; font-weight: 700; }
.badge-pending { background: #fef3c7; color: #92400e; }
.badge-scheduled { background: #dbeafe; color: #1e40af; }
.badge-in_progress { background: #e0e7ff; color: #3730a3; }
.badge-completed { background: #d1fae5; color: #065f46; }
.badge-cancelled { background: #fee2e2; color: #991b1b; }
.badge-low { background: #d1fae5; color: #065f46; }
.badge-medium { background: #fef3c7; color: #92400e; }
.badge-high { background: #fee2e2; color: #991b1b; }
.badge-urgent { background: #dc2626; color: #fff; }
/* KNOWLEDGE BASE */
.kb-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
.kb-card { background: #fff; border-radius: var(--radius); padding: 22px; box-shadow: var(--shadow); border: 1px solid var(--border); border-left: 4px solid var(--primary); text-decoration: none; color: inherit; display: block; transition: transform 0.2s; }
.kb-card:hover { transform: translateY(-3px); }
.kb-card h3 { font-size: 1.02rem; margin-bottom: 8px; }
.kb-meta { display: flex; gap: 8px; align-items: center; margin-bottom: 10px; flex-wrap: wrap; }
.kb-category { background: var(--light); padding: 2px 10px; border-radius: 20px; font-size: 0.78rem; color: var(--gray); font-weight: 600; }
.difficulty-easy { border-left-color: var(--success) !important; }
.difficulty-medium { border-left-color: var(--warning) !important; }
.difficulty-hard { border-left-color: var(--danger) !important; }
/* PAGE HEADER */
.page-header { background: #fff; border-bottom: 1px solid var(--border); padding: 20px; }
.page-header-inner { max-width: 1200px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; gap: 12px; flex-wrap: wrap; }
.page-header h1 { font-size: 1.5rem; }
/* SEARCH */
.search-box { display: flex; gap: 10px; margin-bottom: 22px; }
.search-box input { flex: 1; padding: 10px 15px; border: 2px solid var(--border); border-radius: 8px; font-size: 0.93rem; font-family: inherit; }
.search-box input:focus { outline: none; border-color: var(--primary); }
/* FOOTER */
.footer { background: var(--dark); color: #94a3b8; padding: 50px 20px 0; margin-top: 60px; }
.footer-container { max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: repeat(auto-fit, minmax(190px, 1fr)); gap: 32px; padding-bottom: 36px; }
.footer-section h3, .footer-section h4 { color: #fff; margin-bottom: 14px; }
.footer-section a { display: block; color: #94a3b8; text-decoration: none; margin-bottom: 8px; font-size: 0.88rem; }
.footer-section a:hover { color: #fff; }
.footer-section p { font-size: 0.88rem; margin-bottom: 8px; line-height: 1.6; }
.footer-bottom { border-top: 1px solid #334155; padding: 18px 0; text-align: center; max-width: 1200px; margin: 0 auto; font-size: 0.83rem; }
/* RESPONSIVE */
@media (max-width: 768px) {
    .hero h1 { font-size: 1.9rem; }
    .form-row { grid-template-columns: 1fr; }
    .page-header-inner { flex-direction: column; align-items: flex-start; }
    table { display: block; overflow-x: auto; }
    .stats-grid { grid-template-columns: 1fr 1fr; }
}
    </style>
</head>
<body>
<nav class="navbar">
    <div class="nav-container">
        <a href="<?= SITE_URL ?>" class="nav-logo">
            🔧 Dern-Support
        </a>
        <div class="nav-links">
            <a href="<?= SITE_URL ?>">🏠 Нүүр</a>
            <a href="<?= SITE_URL ?>/knowledge.php">📚 Мэдлэгийн сан</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="<?= SITE_URL ?>/requests.php">🎫 Хүсэлтүүд</a>
                <a href="<?= SITE_URL ?>/dashboard.php">📊 Хяналтын самбар</a>
                <a href="<?= SITE_URL ?>/logout.php" class="btn-nav-logout">🚪 Гарах</a>
            <?php else: ?>
                <a href="<?= SITE_URL ?>/login.php" class="btn-nav-login">🔑 Нэвтрэх</a>
                <a href="<?= SITE_URL ?>/register.php" class="btn-nav-register">✨ Бүртгүүлэх</a>
            <?php endif; ?>
        </div>
    </div>
</nav>
<main class="main-content">
