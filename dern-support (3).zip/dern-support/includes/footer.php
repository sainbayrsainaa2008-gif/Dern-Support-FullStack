    </main>
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-section">
                <h3>🔧 Dern-Support</h3>
                <p>Таны компьютерийн найдвартай засварын үйлчилгээ</p>
            </div>
            <div class="footer-section">
                <h4>Холбоос</h4>
                <a href="<?= SITE_URL ?>">Нүүр хуудас</a>
                <a href="<?= SITE_URL ?>/knowledge.php">Мэдлэгийн сан</a>
                <a href="<?= SITE_URL ?>/register.php">Бүртгүүлэх</a>
            </div>
            <div class="footer-section">
                <h4>Холбоо барих</h4>
                <p>📞 +976 99001234</p>
                <p>✉️ info@dern-support.mn</p>
                <p>📍 Улаанбаатар, Монгол</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?= date('Y') ?> Dern-Support. Бүх эрх хуулиар хамгаалагдсан.</p>
        </div>
    </footer>
    <script src="<?= SITE_URL ?>/js/main.js"></script>
</body>
</html>
