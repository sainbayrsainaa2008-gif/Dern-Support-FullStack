-- =============================================
-- XAMPP phpMyAdmin дээр ажиллуулах SQL
-- =============================================

CREATE DATABASE IF NOT EXISTS programm
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE programm;

CREATE TABLE IF NOT EXISTS results (
    id        INT AUTO_INCREMENT PRIMARY KEY,
    name      VARCHAR(100) NOT NULL,
    level     VARCHAR(20)  NOT NULL,
    unit1     VARCHAR(20)  NOT NULL,
    unit3     VARCHAR(20)  NOT NULL,
    unit4     VARCHAR(20)  NOT NULL,
    unit6     VARCHAR(20)  NOT NULL,
    grade     VARCHAR(20)  NOT NULL,
    category  VARCHAR(100) NOT NULL,
    saved_at  DATETIME     DEFAULT CURRENT_TIMESTAMP
);

-- Туршилтын өгөгдөл
INSERT INTO results (name,level,unit1,unit3,unit4,unit6,grade,category) VALUES
('Болд Батаа',  'Level 3','distinction','distinction','distinction','distinction','distinction','You fall under category 1'),
('Нарантуяа',   'Level 3','merit','merit','merit','merit','merit','You fall under category 2'),
('Энхбаяр',     'Level 4','pass','pass','merit','pass','pass','You fall under category 3');

SELECT * FROM results;
