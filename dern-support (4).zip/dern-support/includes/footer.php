</main>
<footer>
  <div class="fgrid">
    <div class="fs">
      <h3>🔧 Dern-Support</h3>
      <p>Таны компьютерийн найдвартай засварын үйлчилгээ</p>
    </div>
    <div class="fs">
      <h4>Холбоос</h4>
      <a href="<?= SITE_URL ?>">Нүүр хуудас</a>
      <a href="<?= SITE_URL ?>/knowledge.php">Мэдлэгийн сан</a>
      <a href="<?= SITE_URL ?>/register.php">Бүртгүүлэх</a>
    </div>
    <div class="fs">
      <h4>Холбоо барих</h4>
      <p>📞 +976 99001234</p>
      <p>✉️ info@dern-support.mn</p>
      <p>📍 Улаанбаатар, Монгол</p>
    </div>
  </div>
  <div class="fbot">&copy; <?= date('Y') ?> Dern-Support. Бүх эрх хуулиар хамгаалагдсан.</div>
</footer>
</body>
</html>
