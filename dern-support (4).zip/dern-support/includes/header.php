<?php require_once __DIR__ . '/config.php'; ?>
<!DOCTYPE html>
<html lang="mn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($pageTitle) ? h($pageTitle) . ' | ' : '' ?>Dern-Support</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--p:#1a56db;--pd:#1341b0;--s:#f59e0b;--ok:#10b981;--err:#ef4444;--dk:#1e293b;--gr:#64748b;--lt:#f1f5f9;--bd:#e2e8f0;--sh:0 2px 8px rgba(0,0,0,.1);--r:10px}
body{font-family:'Segoe UI',Arial,sans-serif;background:var(--lt);color:var(--dk);min-height:100vh}
a{text-decoration:none}
/* NAV */
nav{background:var(--dk);position:sticky;top:0;z-index:99;box-shadow:0 2px 10px rgba(0,0,0,.4)}
.nc{max-width:1200px;margin:0 auto;padding:0 20px;display:flex;align-items:center;justify-content:space-between;height:62px}
.logo{color:#fff;font-size:1.3rem;font-weight:700}
.nl{display:flex;align-items:center;gap:4px;flex-wrap:wrap}
.nl a{color:#cbd5e1;padding:7px 12px;border-radius:7px;font-size:.86rem;transition:.2s}
.nl a:hover{background:rgba(255,255,255,.1);color:#fff}
.nl .ni{background:var(--p);color:#fff}
.nl .nr{background:var(--s);color:var(--dk);font-weight:700}
.nl .no{background:rgba(239,68,68,.2);color:#fca5a5}
/* MAIN */
main{min-height:calc(100vh - 62px - 180px)}
/* HERO */
.hero{background:linear-gradient(135deg,#1e293b,#1e3a5f 60%,#1a56db);color:#fff;padding:70px 20px;text-align:center}
.hero h1{font-size:2.4rem;margin-bottom:14px;line-height:1.2}
.hero h1 span{color:var(--s)}
.hero p{font-size:1.05rem;color:#94a3b8;max-width:560px;margin:0 auto 32px;line-height:1.7}
.hbtns{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
/* BTN */
.btn{display:inline-flex;align-items:center;gap:6px;padding:10px 20px;border-radius:8px;font-size:.93rem;font-weight:600;cursor:pointer;border:none;transition:.2s;line-height:1}
.bp{background:var(--p);color:#fff}
.bp:hover{background:var(--pd);transform:translateY(-1px);box-shadow:0 4px 12px rgba(26,86,219,.4)}
.bs{background:transparent;color:#fff;border:2px solid rgba(255,255,255,.3)}
.bs:hover{background:rgba(255,255,255,.1)}
.bg{background:var(--ok);color:#fff}
.bd2{background:var(--err);color:#fff}
.bsm{padding:5px 12px;font-size:.8rem}
.bfull{width:100%;justify-content:center;padding:12px}
/* SECTION */
.sec{padding:56px 20px}
.con{max-width:1200px;margin:0 auto}
.stit{text-align:center;margin-bottom:40px}
.stit h2{font-size:1.9rem;margin-bottom:8px}
.stit p{color:var(--gr)}
/* CARD */
.cgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:22px}
.card{background:#fff;border-radius:var(--r);padding:26px;box-shadow:var(--sh);border:1px solid var(--bd);transition:.2s}
.card:hover{transform:translateY(-3px);box-shadow:0 10px 24px rgba(0,0,0,.1)}
.cico{width:52px;height:52px;border-radius:11px;display:flex;align-items:center;justify-content:center;font-size:1.5rem;margin-bottom:16px}
.ib{background:#dbeafe}.ig{background:#d1fae5}.iy{background:#fef3c7}.ir{background:#fee2e2}
.card h3{font-size:1.05rem;margin-bottom:8px}
.card p{color:var(--gr);font-size:.9rem;line-height:1.6}
/* STAT */
.sgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(175px,1fr));gap:18px;margin-bottom:28px}
.scard{background:#fff;border-radius:var(--r);padding:20px;box-shadow:var(--sh);display:flex;align-items:center;gap:14px;border:1px solid var(--bd)}
.sico{width:50px;height:50px;border-radius:11px;display:flex;align-items:center;justify-content:center;font-size:1.5rem;flex-shrink:0}
.sinfo h3{font-size:1.9rem;font-weight:700;line-height:1}
.sinfo p{color:var(--gr);font-size:.8rem;margin-top:3px}
/* FORM */
.fcon{max-width:500px;margin:36px auto;background:#fff;border-radius:var(--r);padding:36px;box-shadow:var(--sh);border:1px solid var(--bd)}
.fcon h2{text-align:center;margin-bottom:26px;font-size:1.45rem}
.fg{margin-bottom:18px}
.fg label{display:block;margin-bottom:5px;font-weight:600;font-size:.86rem}
.fg input,.fg select,.fg textarea{width:100%;padding:10px 13px;border:2px solid var(--bd);border-radius:7px;font-size:.93rem;font-family:inherit;background:#fff;transition:.2s}
.fg input:focus,.fg select:focus,.fg textarea:focus{outline:none;border-color:var(--p);box-shadow:0 0 0 3px rgba(26,86,219,.08)}
.fg textarea{resize:vertical;min-height:90px;line-height:1.6}
.frow{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.flink{text-align:center;margin-top:16px;color:var(--gr);font-size:.88rem}
.flink a{color:var(--p);font-weight:600}
/* ALERT */
.al{padding:12px 16px;border-radius:8px;margin-bottom:18px;font-size:.91rem}
.aok{background:#d1fae5;color:#065f46;border:1px solid #a7f3d0}
.aer{background:#fee2e2;color:#991b1b;border:1px solid #fca5a5}
.ain{background:#dbeafe;color:#1e40af;border:1px solid #93c5fd}
/* TABLE */
.tcon{background:#fff;border-radius:var(--r);box-shadow:var(--sh);overflow:hidden;border:1px solid var(--bd)}
.thead{padding:16px 20px;border-bottom:1px solid var(--bd);display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap}
.thead h3{font-size:.97rem}
table{width:100%;border-collapse:collapse}
th{background:var(--lt);padding:10px 14px;text-align:left;font-size:.78rem;color:var(--gr);font-weight:700;text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid var(--bd)}
td{padding:12px 14px;border-bottom:1px solid var(--bd);font-size:.9rem}
tr:last-child td{border:none}
tbody tr:hover td{background:#f8fafc}
/* BADGE */
.b{display:inline-flex;padding:3px 9px;border-radius:20px;font-size:.75rem;font-weight:700}
.b-pending{background:#fef3c7;color:#92400e}
.b-scheduled{background:#dbeafe;color:#1e40af}
.b-in_progress{background:#e0e7ff;color:#3730a3}
.b-completed{background:#d1fae5;color:#065f46}
.b-cancelled{background:#fee2e2;color:#991b1b}
.b-low{background:#d1fae5;color:#065f46}
.b-medium{background:#fef3c7;color:#92400e}
.b-high{background:#fee2e2;color:#991b1b}
.b-urgent{background:#dc2626;color:#fff}
/* KB */
.kgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(290px,1fr));gap:18px}
.kcard{background:#fff;border-radius:var(--r);padding:20px;box-shadow:var(--sh);border:1px solid var(--bd);border-left:4px solid var(--p);transition:.2s;color:inherit;display:block}
.kcard:hover{transform:translateY(-3px)}
.kcard h3{font-size:1rem;margin-bottom:7px}
.kmeta{display:flex;gap:7px;align-items:center;margin-bottom:9px;flex-wrap:wrap}
.kcat{background:var(--lt);padding:2px 9px;border-radius:20px;font-size:.77rem;color:var(--gr);font-weight:600}
.de{border-left-color:var(--ok)!important}.dm{border-left-color:var(--s)!important}.dh{border-left-color:var(--err)!important}
/* PH */
.ph{background:#fff;border-bottom:1px solid var(--bd);padding:18px 20px}
.phi{max-width:1200px;margin:0 auto;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap}
.phi h1{font-size:1.45rem}
/* FOOTER */
footer{background:var(--dk);color:#94a3b8;padding:44px 20px 0;margin-top:56px}
.fgrid{max-width:1200px;margin:0 auto;display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:28px;padding-bottom:32px}
.fs h3,.fs h4{color:#fff;margin-bottom:12px}
.fs a{display:block;color:#94a3b8;margin-bottom:7px;font-size:.86rem}
.fs a:hover{color:#fff}
.fs p{font-size:.86rem;margin-bottom:7px;line-height:1.6}
.fbot{border-top:1px solid #334155;padding:16px 0;text-align:center;max-width:1200px;margin:0 auto;font-size:.82rem}
/* SEARCH */
.sb{display:flex;gap:9px;margin-bottom:20px}
.sb input{flex:1;padding:9px 14px;border:2px solid var(--bd);border-radius:7px;font-size:.92rem;font-family:inherit}
.sb input:focus{outline:none;border-color:var(--p)}
@media(max-width:768px){
  .hero h1{font-size:1.8rem}
  .frow{grid-template-columns:1fr}
  .phi{flex-direction:column;align-items:flex-start}
  table{display:block;overflow-x:auto}
  .sgrid{grid-template-columns:1fr 1fr}
}
@media(max-width:480px){
  .sgrid{grid-template-columns:1fr}
  .fcon{padding:22px 16px}
}
</style>
</head>
<body>
<nav>
  <div class="nc">
    <a href="<?= SITE_URL ?>" class="logo">🔧 Dern-Support</a>
    <div class="nl">
      <a href="<?= SITE_URL ?>">🏠 Нүүр</a>
      <a href="<?= SITE_URL ?>/knowledge.php">📚 Мэдлэгийн сан</a>
      <?php if (isset($_SESSION['user_id'])): ?>
        <a href="<?= SITE_URL ?>/requests.php">🎫 Хүсэлтүүд</a>
        <a href="<?= SITE_URL ?>/dashboard.php">📊 Самбар</a>
        <a href="<?= SITE_URL ?>/logout.php" class="no">🚪 Гарах</a>
      <?php else: ?>
        <a href="<?= SITE_URL ?>/login.php" class="ni">🔑 Нэвтрэх</a>
        <a href="<?= SITE_URL ?>/register.php" class="nr">✨ Бүртгүүлэх</a>
      <?php endif; ?>
    </div>
  </div>
</nav>
<main>
