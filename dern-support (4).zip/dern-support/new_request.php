<?php
$pageTitle = 'Шинэ хүсэлт';
require_once 'includes/config.php';
requireLogin();
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title    = trim($_POST['title'] ?? '');
    $desc     = trim($_POST['description'] ?? '');
    $device   = trim($_POST['device_type'] ?? '');
    $priority = trim($_POST['priority'] ?? 'medium');
    $date     = trim($_POST['scheduled_date'] ?? '') ?: null;
    $time     = trim($_POST['scheduled_time'] ?? '') ?: null;
    if (!$title || !$desc) {
        $err = 'Гарчиг болон тайлбарыг заавал оруулна уу.';
    } else {
        $db  = getDB();
        $uid = $_SESSION['user_id'];
        $st  = $db->prepare("INSERT INTO support_requests (user_id,title,description,device_type,priority,scheduled_date,scheduled_time) VALUES(?,?,?,?,?,?,?)");
        $st->bind_param('issssss', $uid, $title, $desc, $device, $priority, $date, $time);
        if ($st->execute()) { header('Location: ' . SITE_URL . '/view_request.php?id=' . $db->insert_id . '&new=1'); exit; }
        else { $err = 'Хүсэлт үүсгэхэд алдаа гарлаа.'; }
    }
}
require_once 'includes/header.php';
?>
<div class="ph"><div class="phi"><h1>➕ Шинэ засварын хүсэлт</h1><a href="<?= SITE_URL ?>/requests.php" class="btn" style="background:var(--bd);color:var(--dk)">← Буцах</a></div></div>
<div class="sec"><div class="con">
  <div class="fcon" style="max-width:650px">
    <?php if ($err): ?><div class="al aer">❗ <?= h($err) ?></div><?php endif; ?>
    <form method="POST">
      <div class="fg"><label>Хүсэлтийн гарчиг *</label><input type="text" name="title" placeholder="Жишээ: Компьютер асахгүй байна" required value="<?= h($_POST['title'] ?? '') ?>"></div>
      <div class="fg"><label>Тайлбар *</label><textarea name="description" rows="5" required placeholder="Асуудлаа дэлгэрэнгүй тайлбарлана уу..."><?= h($_POST['description'] ?? '') ?></textarea></div>
      <div class="frow">
        <div class="fg"><label>Тоног төхөөрөмж</label>
          <select name="device_type">
            <option value="">-- Сонгоно уу --</option>
            <option>Ширээний компьютер</option><option>Зөөврийн компьютер</option>
            <option>Принтер</option><option>Монитор</option>
            <option>Сервер</option><option>Сүлжээний тоног төхөөрөмж</option><option>Бусад</option>
          </select>
        </div>
        <div class="fg"><label>Яаралтай эсэх</label>
          <select name="priority">
            <option value="low">Бага</option>
            <option value="medium" selected>Дунд</option>
            <option value="high">Өндөр</option>
            <option value="urgent">Яаралтай</option>
          </select>
        </div>
      </div>
      <div style="background:var(--lt);border-radius:8px;padding:18px;margin-bottom:18px">
        <h4 style="margin-bottom:12px">📅 Цаг товлох (заавал биш)</h4>
        <div class="frow">
          <div class="fg" style="margin:0"><label>Өдөр</label><input type="date" name="scheduled_date" min="<?= date('Y-m-d') ?>"></div>
          <div class="fg" style="margin:0"><label>Цаг</label><input type="time" name="scheduled_time"></div>
        </div>
      </div>
      <div class="al ain" style="margin-bottom:18px">ℹ️ Хүсэлт илгээсний дараа манай мэргэжилтэн тантай холбоо барина.</div>
      <button type="submit" class="btn bp bfull">📨 Хүсэлт илгээх</button>
    </form>
  </div>
</div></div>
<?php require_once 'includes/footer.php'; ?>
