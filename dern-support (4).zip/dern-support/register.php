<?php
$pageTitle = 'Бүртгүүлэх';
require_once 'includes/config.php';
if (isset($_SESSION['user_id'])) { header('Location: ' . SITE_URL . '/dashboard.php'); exit; }
$err = ''; $ok = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type    = trim($_POST['account_type'] ?? 'individual');
    $company = trim($_POST['company_name'] ?? '');
    $fname   = trim($_POST['first_name'] ?? '');
    $lname   = trim($_POST['last_name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $phone   = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $pass    = $_POST['password'] ?? '';
    $pass2   = $_POST['password2'] ?? '';
    if (!$fname || !$lname || !$email || !$pass) {
        $err = 'Бүх заавал талбаруудыг бөглөнө үү.';
    } elseif ($pass !== $pass2) {
        $err = 'Нууц үгнүүд таарахгүй байна.';
    } elseif (strlen($pass) < 6) {
        $err = 'Нууц үг хамгийн багадаа 6 тэмдэгт байх ёстой.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $err = 'И-мэйл хаяг буруу байна.';
    } else {
        $db = getDB();
        $ch = $db->prepare("SELECT id FROM users WHERE email=?");
        $ch->bind_param('s', $email); $ch->execute();
        if ($ch->get_result()->num_rows > 0) {
            $err = 'Энэ и-мэйл аль хэдийн бүртгэгдсэн байна.';
        } else {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $st = $db->prepare("INSERT INTO users (account_type,first_name,last_name,company_name,email,phone,address,password) VALUES(?,?,?,?,?,?,?,?)");
            $st->bind_param('ssssssss', $type, $fname, $lname, $company, $email, $phone, $address, $hash);
            if ($st->execute()) { $ok = 'Бүртгэл амжилттай! Та одоо нэвтэрч болно.'; }
            else { $err = 'Бүртгэл амжилтгүй боллоо.'; }
        }
    }
}
require_once 'includes/header.php';
?>
<div class="fcon" style="max-width:580px">
  <h2>✨ Бүртгүүлэх</h2>
  <?php if ($err): ?><div class="al aer">❗ <?= h($err) ?></div><?php endif; ?>
  <?php if ($ok): ?><div class="al aok">✅ <?= h($ok) ?> <a href="<?= SITE_URL ?>/login.php">Нэвтрэх</a></div><?php endif; ?>
  <form method="POST">
    <div class="fg">
      <label>Аккаунтын төрөл *</label>
      <select name="account_type" onchange="document.getElementById('cg').style.display=this.value=='business'?'block':'none'">
        <option value="individual">Хувь хүн</option>
        <option value="business">Бизнес / Байгууллага</option>
      </select>
    </div>
    <div class="fg" id="cg" style="display:none">
      <label>Байгууллагын нэр</label>
      <input type="text" name="company_name" placeholder="Байгууллагын нэр">
    </div>
    <div class="frow">
      <div class="fg"><label>Нэр *</label><input type="text" name="first_name" required value="<?= h($_POST['first_name'] ?? '') ?>"></div>
      <div class="fg"><label>Овог *</label><input type="text" name="last_name" required value="<?= h($_POST['last_name'] ?? '') ?>"></div>
    </div>
    <div class="fg"><label>И-мэйл *</label><input type="email" name="email" required value="<?= h($_POST['email'] ?? '') ?>"></div>
    <div class="fg"><label>Утас</label><input type="tel" name="phone" value="<?= h($_POST['phone'] ?? '') ?>"></div>
    <div class="fg"><label>Хаяг</label><textarea name="address"><?= h($_POST['address'] ?? '') ?></textarea></div>
    <div class="frow">
      <div class="fg"><label>Нууц үг *</label><input type="password" name="password" required></div>
      <div class="fg"><label>Давтах *</label><input type="password" name="password2" required></div>
    </div>
    <button type="submit" class="btn bp bfull">✨ Бүртгүүлэх</button>
  </form>
  <div class="flink">Аль хэдийн бүртгэлтэй юу? <a href="<?= SITE_URL ?>/login.php">Нэвтрэх</a></div>
</div>
<?php require_once 'includes/footer.php'; ?>
