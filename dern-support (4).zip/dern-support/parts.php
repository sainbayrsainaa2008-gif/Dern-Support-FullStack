<?php
$pageTitle = 'Нөөц эд анги';
require_once 'includes/config.php';
requireLogin();
$db   = getDB();
$srch = trim($_GET['search'] ?? '');
if ($srch) {
    $st = $db->prepare("SELECT * FROM spare_parts WHERE name LIKE ? OR category LIKE ? OR part_number LIKE ? ORDER BY category,name");
    $s  = "%$srch%"; $st->bind_param('sss',$s,$s,$s); $st->execute();
    $parts = $st->get_result()->fetch_all(MYSQLI_ASSOC);
} else {
    $parts = $db->query("SELECT * FROM spare_parts ORDER BY category,name")->fetch_all(MYSQLI_ASSOC);
}
require_once 'includes/header.php';
?>
<div class="ph"><div class="phi"><h1>⚙️ Нөөц эд ангиуд</h1></div></div>
<div class="sec"><div class="con">
  <form method="GET" style="display:flex;gap:9px;margin-bottom:22px">
    <input type="text" name="search" placeholder="Эд ангийн нэр, ангилал хайх..." value="<?= h($srch) ?>" style="flex:1;padding:9px 14px;border:2px solid var(--bd);border-radius:7px;font-size:.92rem;font-family:inherit">
    <button type="submit" class="btn bp">🔍 Хайх</button>
    <?php if ($srch): ?><a href="<?= SITE_URL ?>/parts.php" class="btn" style="background:var(--bd);color:var(--dk)">✕</a><?php endif; ?>
  </form>
  <div class="tcon">
    <div class="thead"><h3>Нөөцийн жагсаалт</h3><span style="color:var(--gr);font-size:.88rem">Нийт: <?= count($parts) ?> эд анги</span></div>
    <table><thead><tr><th>Нэр</th><th>Дугаар</th><th>Ангилал</th><th>Тоо</th><th>Үнэ</th><th>Нийлүүлэгч</th></tr></thead>
    <tbody>
    <?php if (empty($parts)): ?>
      <tr><td colspan="6" style="text-align:center;color:var(--gr);padding:40px">Үр дүн олдсонгүй</td></tr>
    <?php else: ?>
      <?php foreach ($parts as $p):
        $qcol = $p['quantity']>5 ? '#d1fae5:#065f46' : ($p['quantity']>0 ? '#fef3c7:#92400e' : '#fee2e2:#991b1b');
        [$qbg,$qfg] = explode(':', $qcol);
      ?>
      <tr>
        <td><strong><?= h($p['name']) ?></strong></td>
        <td style="font-family:monospace;color:var(--gr);font-size:.85rem"><?= h($p['part_number'] ?? '-') ?></td>
        <td><?= h($p['category'] ?? '-') ?></td>
        <td><span class="b" style="background:<?= $qbg ?>;color:<?= $qfg ?>"><?= $p['quantity'] ?> ш</span></td>
        <td style="color:var(--ok);font-weight:600"><?= $p['unit_price'] ? number_format($p['unit_price']).'₮' : '-' ?></td>
        <td><?= h($p['supplier'] ?? '-') ?></td>
      </tr>
      <?php endforeach; ?>
    <?php endif; ?>
    </tbody></table>
  </div>
</div></div>
<?php require_once 'includes/footer.php'; ?>
