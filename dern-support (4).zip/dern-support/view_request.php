<?php
$pageTitle = 'Хүсэлтийн дэлгэрэнгүй';
require_once 'includes/config.php';
requireLogin();
$db  = getDB();
$uid = $_SESSION['user_id'];
$id  = intval($_GET['id'] ?? 0);
$st  = $db->prepare("SELECT * FROM support_requests WHERE id=? AND user_id=?");
$st->bind_param('ii', $id, $uid); $st->execute();
$r   = $st->get_result()->fetch_assoc();
if (!$r) { header('Location: ' . SITE_URL . '/requests.php'); exit; }
$smn = ['pending'=>'Хүлээгдэж буй','scheduled'=>'Товлосон','in_progress'=>'Хийгдэж байна','completed'=>'Дууссан','cancelled'=>'Цуцлагдсан'];
$pmn = ['low'=>'Бага','medium'=>'Дунд','high'=>'Өндөр','urgent'=>'Яаралтай'];
$scl = ['pending'=>'#f59e0b','scheduled'=>'#3b82f6','in_progress'=>'#8b5cf6','completed'=>'#10b981','cancelled'=>'#ef4444'];
require_once 'includes/header.php';
?>
<div class="ph"><div class="phi"><h1>🎫 Хүсэлт #<?= $r['id'] ?></h1><a href="<?= SITE_URL ?>/requests.php" class="btn" style="background:var(--bd);color:var(--dk)">← Буцах</a></div></div>
<div class="sec"><div class="con" style="max-width:760px">
  <?php if (isset($_GET['new'])): ?><div class="al aok">✅ Хүсэлт амжилттай илгээгдлээ! Манай мэргэжилтэн тантай удахгүй холбоо барина.</div><?php endif; ?>
  <div style="background:#fff;border-radius:var(--r);box-shadow:var(--sh);overflow:hidden;border:1px solid var(--bd)">
    <div style="background:<?= $scl[$r['status']] ?>;padding:15px 22px;display:flex;justify-content:space-between;align-items:center">
      <span style="color:#fff;font-weight:700;font-size:1.08rem"><?= h($smn[$r['status']] ?? $r['status']) ?></span>
      <span style="color:rgba(255,255,255,.8);font-size:.88rem"><?= date('Y-m-d H:i', strtotime($r['created_at'])) ?></span>
    </div>
    <div style="padding:26px">
      <h2 style="margin-bottom:18px"><?= h($r['title']) ?></h2>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;background:var(--lt);border-radius:8px;padding:16px;margin-bottom:22px">
        <div><p style="font-size:.76rem;color:var(--gr);margin-bottom:3px">ТОНОГ ТӨХӨӨРӨМЖ</p><p style="font-weight:600"><?= h($r['device_type'] ?: 'Тодорхойгүй') ?></p></div>
        <div><p style="font-size:.76rem;color:var(--gr);margin-bottom:3px">ЯАРАЛТАЙ ЭСЭХ</p><span class="b b-<?= h($r['priority']) ?>"><?= h($pmn[$r['priority']] ?? '') ?></span></div>
        <?php if ($r['estimated_cost']): ?>
          <div><p style="font-size:.76rem;color:var(--gr);margin-bottom:3px">ҮНИЙН САНАЛ</p><p style="font-weight:600;color:var(--ok)"><?= number_format($r['estimated_cost']) ?>₮</p></div>
        <?php endif; ?>
        <?php if ($r['scheduled_date']): ?>
          <div><p style="font-size:.76rem;color:var(--gr);margin-bottom:3px">ТОВЛОСОН ЦАГ</p><p style="font-weight:600">📅 <?= h($r['scheduled_date']) ?><?= $r['scheduled_time'] ? ' '.substr($r['scheduled_time'],0,5) : '' ?></p></div>
        <?php endif; ?>
      </div>
      <div style="margin-bottom:20px">
        <h4 style="margin-bottom:9px;color:var(--gr)">Тайлбар</h4>
        <div style="background:var(--lt);border-radius:8px;padding:15px;line-height:1.7"><?= nl2br(h($r['description'])) ?></div>
      </div>
      <!-- Progress -->
      <h4 style="margin-bottom:14px">Хүсэлтийн явц</h4>
      <?php
      $steps = ['pending','scheduled','in_progress','completed'];
      $slbls = ['Хүлээгдэж буй','Товлосон','Хийгдэж байна','Дууссан'];
      $cur   = array_search($r['status'], $steps); if ($cur===false) $cur=-1;
      ?>
      <div style="display:flex;position:relative">
        <?php foreach ($steps as $i=>$st2):
          $done2 = $i <= $cur; ?>
          <div style="flex:1;text-align:center;position:relative">
            <div style="width:30px;height:30px;border-radius:50%;margin:0 auto 7px;display:flex;align-items:center;justify-content:center;font-size:.8rem;font-weight:700;background:<?= $done2?'var(--p)':'var(--bd)' ?>;color:<?= $done2?'#fff':'var(--gr)' ?>">
              <?= $done2 ? '✓' : ($i+1) ?>
            </div>
            <p style="font-size:.72rem;color:<?= $done2?'var(--p)':'var(--gr)' ?>;font-weight:<?= $done2?'700':'400' ?>"><?= $slbls[$i] ?></p>
            <?php if ($i < count($steps)-1): ?>
              <div style="position:absolute;top:15px;left:50%;width:100%;height:2px;background:<?= $i<$cur?'var(--p)':'var(--bd)' ?>"></div>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
      <?php if ($r['status']==='pending'): ?>
        <div style="margin-top:22px;padding-top:18px;border-top:1px solid var(--bd);text-align:right">
          <a href="<?= SITE_URL ?>/delete_request.php?id=<?= $r['id'] ?>" class="btn bd2 bsm" onclick="return confirm('Хүсэлт цуцлахдаа итгэлтэй байна уу?')">✕ Хүсэлт цуцлах</a>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div></div>
<?php require_once 'includes/footer.php'; ?>
