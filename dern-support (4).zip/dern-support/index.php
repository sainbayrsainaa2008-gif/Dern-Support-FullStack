<?php
$pageTitle = 'Нүүр хуудас';
require_once 'includes/header.php';
$db = getDB();
$r1 = $db->query("SELECT COUNT(*) c FROM support_requests")->fetch_assoc()['c'];
$r2 = $db->query("SELECT COUNT(*) c FROM support_requests WHERE status='completed'")->fetch_assoc()['c'];
$r3 = $db->query("SELECT COUNT(*) c FROM users")->fetch_assoc()['c'];
$r4 = $db->query("SELECT COUNT(*) c FROM knowledge_base")->fetch_assoc()['c'];
?>

<div class="hero">
  <div class="con">
    <h1>Тавтай морил, <span>Dern-Support</span>-д</h1>
    <p>Таны компьютер, лаптоп болон бусад тоног төхөөрөмжийн найдвартай засварын үйлчилгээ. Хурдан, найдвартай, хямд.</p>
    <div class="hbtns">
      <?php if (!isset($_SESSION['user_id'])): ?>
        <a href="<?= SITE_URL ?>/register.php" class="btn bp">✨ Бүртгүүлэх</a>
        <a href="<?= SITE_URL ?>/login.php" class="btn bs">🔑 Нэвтрэх</a>
      <?php else: ?>
        <a href="<?= SITE_URL ?>/new_request.php" class="btn bp">➕ Хүсэлт гаргах</a>
        <a href="<?= SITE_URL ?>/dashboard.php" class="btn bs">📊 Хяналтын самбар</a>
      <?php endif; ?>
      <a href="<?= SITE_URL ?>/knowledge.php" class="btn bs">📚 Мэдлэгийн сан</a>
    </div>
  </div>
</div>

<div class="sec" style="background:#fff;padding:36px 20px">
  <div class="con">
    <div class="sgrid">
      <div class="scard"><div class="sico ib">🎫</div><div class="sinfo"><h3><?= $r1 ?></h3><p>Нийт хүсэлт</p></div></div>
      <div class="scard"><div class="sico ig">✅</div><div class="sinfo"><h3><?= $r2 ?></h3><p>Дууссан засвар</p></div></div>
      <div class="scard"><div class="sico iy">👥</div><div class="sinfo"><h3><?= $r3 ?></h3><p>Бүртгэлтэй хэрэглэгч</p></div></div>
      <div class="scard"><div class="sico ir">📚</div><div class="sinfo"><h3><?= $r4 ?></h3><p>Мэдлэгийн нийтлэл</p></div></div>
    </div>
  </div>
</div>

<div class="sec">
  <div class="con">
    <div class="stit"><h2>Бидний үйлчилгээ</h2><p>Мэргэжлийн техникийн тусламжийг хурдан, найдвартай хүргэнэ</p></div>
    <div class="cgrid">
      <div class="card"><div class="cico ib">🖥️</div><h3>Компьютерийн засвар</h3><p>Ширээний болон зөөврийн компьютерийн тоног төхөөрөмж, программ хангамжийн бүх төрлийн засвар</p></div>
      <div class="card"><div class="cico ig">🏢</div><h3>Бизнесийн дэмжлэг</h3><p>Бизнесийн байршилд очиж үйлчилгээ үзүүлэх. Сүлжээ, сервер болон ажлын компьютерийн засвар</p></div>
      <div class="card"><div class="cico iy">📖</div><h3>Мэдлэгийн сан</h3><p>Нийтлэг асуудлуудыг өөрөө шийдвэрлэх зөвлөмж, заавар болон шийдлүүд</p></div>
      <div class="card"><div class="cico ir">⚡</div><h3>Яаралтай засвар</h3><p>Яаралтай тохиолдолд 24 цагийн дотор хариу өгч, засварыг хурдан гүйцэтгэнэ</p></div>
    </div>
  </div>
</div>

<div class="sec" style="background:#fff">
  <div class="con">
    <div class="stit"><h2>Хэрхэн ажилладаг вэ?</h2></div>
    <div class="cgrid">
      <div class="card" style="text-align:center"><div class="cico ib" style="margin:0 auto 16px;font-size:1.3rem;font-weight:700">1</div><h3>Бүртгүүлэх</h3><p>Хувь хүн эсвэл бизнесийн аккаунт үүсгэнэ</p></div>
      <div class="card" style="text-align:center"><div class="cico iy" style="margin:0 auto 16px;font-size:1.3rem;font-weight:700">2</div><h3>Хүсэлт гаргах</h3><p>Асуудлаа тайлбарлаж, засварын хүсэлт илгээнэ</p></div>
      <div class="card" style="text-align:center"><div class="cico ig" style="margin:0 auto 16px;font-size:1.3rem;font-weight:700">3</div><h3>Захиалга авах</h3><p>Манай мэргэжилтэн тохиромжтой цагийг товлоно</p></div>
      <div class="card" style="text-align:center"><div class="cico ir" style="margin:0 auto 16px;font-size:1.3rem;font-weight:700">4</div><h3>Засвар дуусгах</h3><p>Мэргэжилтэн засварыг гүйцэтгэж, тайлагнана</p></div>
    </div>
  </div>
</div>

<?php require_once 'includes/footer.php'; ?>
