<?php
$pageTitle = 'Нэвтрэх';
require_once 'includes/config.php';
if (isset($_SESSION['user_id'])) { header('Location: ' . SITE_URL . '/dashboard.php'); exit; }
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';
    if (!$email || !$pass) {
        $err = 'И-мэйл болон нууц үгээ оруулна уу.';
    } else {
        $db = getDB();
        $st = $db->prepare("SELECT * FROM users WHERE email=?");
        $st->bind_param('s', $email);
        $st->execute();
        $u = $st->get_result()->fetch_assoc();
        if ($u && password_verify($pass, $u['password'])) {
            $_SESSION['user_id']    = $u['id'];
            $_SESSION['user_name']  = $u['first_name'] . ' ' . $u['last_name'];
            $_SESSION['user_email'] = $u['email'];
            $_SESSION['acct_type']  = $u['account_type'];
            header('Location: ' . SITE_URL . '/dashboard.php'); exit;
        } else {
            $err = 'И-мэйл эсвэл нууц үг буруу байна.';
        }
    }
}
require_once 'includes/header.php';
?>
<div class="fcon">
  <h2>🔑 Нэвтрэх</h2>
  <?php if ($err): ?><div class="al aer">❗ <?= h($err) ?></div><?php endif; ?>
  <form method="POST">
    <div class="fg"><label>И-мэйл *</label><input type="email" name="email" required value="<?= h($_POST['email'] ?? '') ?>"></div>
    <div class="fg"><label>Нууц үг *</label><input type="password" name="password" required></div>
    <button type="submit" class="btn bp bfull">🔑 Нэвтрэх</button>
  </form>
  <div style="margin-top:14px;padding:12px;background:var(--lt);border-radius:8px;font-size:.85rem;color:var(--gr)">
    <strong>Туршилтын аккаунт:</strong><br>И-мэйл: admin@dern.mn &nbsp;|&nbsp; Нууц үг: admin123
  </div>
  <div class="flink">Бүртгэлгүй юу? <a href="<?= SITE_URL ?>/register.php">Бүртгүүлэх</a></div>
</div>
<?php require_once 'includes/footer.php'; ?>
