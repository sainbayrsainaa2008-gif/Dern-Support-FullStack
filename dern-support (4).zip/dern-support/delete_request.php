<?php
require_once 'includes/config.php';
requireLogin();
$db  = getDB();
$uid = $_SESSION['user_id'];
$id  = intval($_GET['id'] ?? 0);
$st  = $db->prepare("DELETE FROM support_requests WHERE id=? AND user_id=? AND status='pending'");
$st->bind_param('ii', $id, $uid);
$st->execute();
header('Location: ' . SITE_URL . '/requests.php');
exit;
