<?php
$pageTitle = 'Засварын хүсэлтүүд';
require_once 'includes/config.php';
requireLogin();
$db  = getDB();
$uid = $_SESSION['user_id'];
$st  = $db->prepare("SELECT * FROM support_requests WHERE user_id=? ORDER BY created_at DESC");
$st->bind_param('i', $uid); $st->execute();
$reqs = $st->get_result()->fetch_all(MYSQLI_ASSOC);
$smn = ['pending'=>'Хүлээгдэж буй','scheduled'=>'Товлосон','in_progress'=>'Хийгдэж байна','completed'=>'Дууссан','cancelled'=>'Цуцлагдсан'];
$pmn = ['low'=>'Бага','medium'=>'Дунд','high'=>'Өндөр','urgent'=>'Яаралтай'];
require_once 'includes/header.php';
?>
<div class="ph"><div class="phi"><h1>🎫 Засварын хүсэлтүүд</h1><a href="<?= SITE_URL ?>/new_request.php" class="btn bp">➕ Шинэ хүсэлт</a></div></div>
<div class="sec"><div class="con">
  <div class="tcon">
    <div class="thead">
      <div class="sb" style="margin:0;flex:1;max-width:380px"><input type="text" id="si" placeholder="Хайх..."></div>
      <span style="color:var(--gr);font-size:.88rem">Нийт: <?= count($reqs) ?></span>
    </div>
    <?php if (empty($reqs)): ?>
      <div style="padding:60px;text-align:center;color:var(--gr)">
        <div style="font-size:3.5rem;margin-bottom:14px">📥</div>
        <h3 style="margin-bottom:8px">Хүсэлт байхгүй байна</h3>
        <a href="<?= SITE_URL ?>/new_request.php" class="btn bp" style="margin-top:14px;display:inline-flex">➕ Шинэ хүсэлт гаргах</a>
      </div>
    <?php else: ?>
      <table id="dt"><thead><tr><th>#</th><th>Гарчиг</th><th>Тоног төхөөрөмж</th><th>Тэргүүлэх</th><th>Төлөв</th><th>Үнэ</th><th>Огноо</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($reqs as $r): ?>
        <tr>
          <td><?= $r['id'] ?></td>
          <td><strong><?= h($r['title']) ?></strong></td>
          <td><?= h($r['device_type'] ?? '-') ?></td>
          <td><span class="b b-<?= h($r['priority']) ?>"><?= h($pmn[$r['priority']] ?? '') ?></span></td>
          <td><span class="b b-<?= h($r['status']) ?>"><?= h($smn[$r['status']] ?? '') ?></span></td>
          <td><?= $r['estimated_cost'] ? number_format($r['estimated_cost']).'₮' : '-' ?></td>
          <td><?= date('Y-m-d', strtotime($r['created_at'])) ?></td>
          <td style="display:flex;gap:6px">
            <a href="<?= SITE_URL ?>/view_request.php?id=<?= $r['id'] ?>" class="btn bp bsm">👁</a>
            <?php if ($r['status']==='pending'): ?>
              <a href="<?= SITE_URL ?>/delete_request.php?id=<?= $r['id'] ?>" class="btn bd2 bsm" onclick="return confirm('Цуцлахдаа итгэлтэй байна уу?')">🗑️</a>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody></table>
    <?php endif; ?>
  </div>
</div></div>
<script>
document.getElementById('si')&&document.getElementById('si').addEventListener('keyup',function(){
  var f=this.value.toLowerCase();
  document.querySelectorAll('#dt tbody tr').forEach(function(r){r.style.display=r.textContent.toLowerCase().includes(f)?'':'none'});
});
</script>
<?php require_once 'includes/footer.php'; ?>
