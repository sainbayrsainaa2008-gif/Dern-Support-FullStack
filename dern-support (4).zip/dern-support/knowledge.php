<?php
$pageTitle = 'Мэдлэгийн сан';
require_once 'includes/config.php';
$db   = getDB();
$cat  = trim($_GET['category'] ?? '');
$srch = trim($_GET['search'] ?? '');
$aid  = intval($_GET['id'] ?? 0);

if ($aid) {
    $db->query("UPDATE knowledge_base SET views=views+1 WHERE id=$aid");
    $art = $db->query("SELECT * FROM knowledge_base WHERE id=$aid")->fetch_assoc();
} else {
    $sql = "SELECT * FROM knowledge_base WHERE 1=1";
    $par = []; $ty = '';
    if ($cat)  { $sql .= " AND category=?"; $par[] = $cat; $ty .= 's'; }
    if ($srch) { $sql .= " AND (title LIKE ? OR problem_description LIKE ? OR solution LIKE ?)"; $s="%$srch%"; $par[]=$s;$par[]=$s;$par[]=$s; $ty.='sss'; }
    $sql .= " ORDER BY views DESC, created_at DESC";
    $st = $db->prepare($sql);
    if ($par) $st->bind_param($ty, ...$par);
    $st->execute();
    $arts = $st->get_result()->fetch_all(MYSQLI_ASSOC);
    $cats = $db->query("SELECT DISTINCT category FROM knowledge_base ORDER BY category")->fetch_all(MYSQLI_ASSOC);
}
$dmn = ['easy'=>'Хялбар','medium'=>'Дунд','hard'=>'Хэцүү'];
require_once 'includes/header.php';
?>
<div class="ph"><div class="phi"><h1>📚 Мэдлэгийн сан</h1></div></div>
<div class="sec"><div class="con">
<?php if ($aid && !empty($art)): ?>
  <div style="margin-bottom:16px"><a href="<?= SITE_URL ?>/knowledge.php" style="color:var(--p)">← Буцах</a></div>
  <div style="background:#fff;border-radius:var(--r);box-shadow:var(--sh);padding:30px;border:1px solid var(--bd);border-left:4px solid var(--p)" class="<?= in_array($art['difficulty'],['easy','medium','hard'])?'d'.substr($art['difficulty'],0,1):'' ?>">
    <div class="kmeta" style="display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap">
      <span class="kcat" style="background:var(--lt);padding:2px 10px;border-radius:20px;font-size:.78rem;color:var(--gr);font-weight:600"><?= h($art['category']) ?></span>
      <span class="b" style="background:var(--lt);color:var(--gr)"><?= h($dmn[$art['difficulty']] ?? '') ?></span>
      <span style="color:var(--gr);font-size:.83rem">👁 <?= $art['views'] ?> удаа харсан</span>
    </div>
    <h2 style="margin-bottom:20px"><?= h($art['title']) ?></h2>
    <div style="background:#fee2e2;border-radius:8px;padding:18px;margin-bottom:18px">
      <h4 style="color:#991b1b;margin-bottom:9px">⚠️ Асуудал</h4>
      <p><?= nl2br(h($art['problem_description'])) ?></p>
    </div>
    <div style="background:#d1fae5;border-radius:8px;padding:18px">
      <h4 style="color:#065f46;margin-bottom:9px">✅ Шийдэл</h4>
      <p><?= nl2br(h($art['solution'])) ?></p>
    </div>
    <div style="margin-top:22px;padding-top:18px;border-top:1px solid var(--bd);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
      <span style="color:var(--gr);font-size:.88rem">Асуудал шийдэгдсэнгүй юу?</span>
      <a href="<?= SITE_URL ?>/<?= isset($_SESSION['user_id'])?'new_request.php':'register.php' ?>" class="btn bp bsm">🎧 Мэргэжилтэнд хандах</a>
    </div>
  </div>
<?php else: ?>
  <form method="GET" style="display:flex;gap:9px;margin-bottom:26px;flex-wrap:wrap">
    <input type="text" name="search" placeholder="Хайх..." value="<?= h($srch) ?>" style="flex:1;min-width:180px;padding:9px 14px;border:2px solid var(--bd);border-radius:7px;font-size:.92rem;font-family:inherit">
    <select name="category" style="padding:9px 13px;border:2px solid var(--bd);border-radius:7px;font-size:.92rem">
      <option value="">Бүх ангилал</option>
      <?php foreach ($cats as $c): ?>
        <option value="<?= h($c['category']) ?>" <?= $cat===$c['category']?'selected':'' ?>><?= h($c['category']) ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn bp">🔍 Хайх</button>
    <?php if ($srch||$cat): ?><a href="<?= SITE_URL ?>/knowledge.php" class="btn" style="background:var(--bd);color:var(--dk)">✕</a><?php endif; ?>
  </form>
  <?php if (empty($arts)): ?>
    <div style="text-align:center;padding:60px;color:var(--gr)"><div style="font-size:3rem;margin-bottom:14px">🔍</div><p>Хайлтын үр дүн олдсонгүй</p></div>
  <?php else: ?>
    <p style="margin-bottom:14px;color:var(--gr);font-size:.88rem">📋 <?= count($arts) ?> нийтлэл олдлоо</p>
    <div class="kgrid">
      <?php foreach ($arts as $a): ?>
        <a href="<?= SITE_URL ?>/knowledge.php?id=<?= $a['id'] ?>" class="kcard <?= 'de'==='d'.substr($a['difficulty']??'',0,1)?'de':('dm'==='d'.substr($a['difficulty']??'',0,1)?'dm':'dh') ?>
        <?php if($a['difficulty']==='easy') echo 'de'; elseif($a['difficulty']==='medium') echo 'dm'; else echo 'dh'; ?>">
          <div class="kmeta">
            <span class="kcat"><?= h($a['category']) ?></span>
            <span style="font-size:.78rem;color:var(--gr)"><?= h($dmn[$a['difficulty']] ?? '') ?></span>
          </div>
          <h3><?= h($a['title']) ?></h3>
          <p style="color:var(--gr);font-size:.88rem;margin-top:7px;line-height:1.5"><?= mb_substr(h($a['problem_description']),0,100) ?>...</p>
          <div style="margin-top:11px;display:flex;justify-content:space-between;align-items:center">
            <span style="color:var(--p);font-size:.84rem;font-weight:600">Шийдлийг харах →</span>
            <span style="color:var(--gr);font-size:.8rem">👁 <?= $a['views'] ?></span>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
<?php endif; ?>
</div></div>
<?php require_once 'includes/footer.php'; ?>
