<?php
$pageTitle = 'Хяналтын самбар';
require_once 'includes/config.php';
requireLogin();
$db  = getDB();
$uid = $_SESSION['user_id'];
$st  = $db->prepare("SELECT COUNT(*) c FROM support_requests WHERE user_id=?"); $st->bind_param('i',$uid); $st->execute(); $total = $st->get_result()->fetch_assoc()['c'];
$st  = $db->prepare("SELECT COUNT(*) c FROM support_requests WHERE user_id=? AND status='completed'"); $st->bind_param('i',$uid); $st->execute(); $done = $st->get_result()->fetch_assoc()['c'];
$st  = $db->prepare("SELECT COUNT(*) c FROM support_requests WHERE user_id=? AND status='pending'"); $st->bind_param('i',$uid); $st->execute(); $pend = $st->get_result()->fetch_assoc()['c'];
$st  = $db->prepare("SELECT * FROM support_requests WHERE user_id=? ORDER BY created_at DESC LIMIT 5"); $st->bind_param('i',$uid); $st->execute(); $reqs = $st->get_result()->fetch_all(MYSQLI_ASSOC);
$smn = ['pending'=>'Хүлээгдэж буй','scheduled'=>'Товлосон','in_progress'=>'Хийгдэж байна','completed'=>'Дууссан','cancelled'=>'Цуцлагдсан'];
$pmn = ['low'=>'Бага','medium'=>'Дунд','high'=>'Өндөр','urgent'=>'Яаралтай'];
require_once 'includes/header.php';
?>
<div class="ph"><div class="phi"><h1>👋 Сайн байна уу, <?= h($_SESSION['user_name']) ?>!</h1><a href="<?= SITE_URL ?>/new_request.php" class="btn bp">➕ Шинэ хүсэлт</a></div></div>
<div class="sec"><div class="con">
  <div class="sgrid">
    <div class="scard"><div class="sico ib">🎫</div><div class="sinfo"><h3><?= $total ?></h3><p>Нийт хүсэлт</p></div></div>
    <div class="scard"><div class="sico iy">⏳</div><div class="sinfo"><h3><?= $pend ?></h3><p>Хүлээгдэж буй</p></div></div>
    <div class="scard"><div class="sico ig">✅</div><div class="sinfo"><h3><?= $done ?></h3><p>Дууссан</p></div></div>
    <div class="scard"><div class="sico" style="background:#f3e8ff">👤</div><div class="sinfo"><h3 style="font-size:1rem"><?= $_SESSION['acct_type']==='business'?'Бизнес':'Хувь хүн' ?></h3><p>Аккаунт</p></div></div>
  </div>
  <div class="tcon">
    <div class="thead"><h3>Сүүлийн хүсэлтүүд</h3><a href="<?= SITE_URL ?>/requests.php" class="btn bp bsm">📋 Бүгдийг харах</a></div>
    <?php if (empty($reqs)): ?>
      <div style="padding:50px;text-align:center;color:var(--gr)">
        <div style="font-size:3rem;margin-bottom:12px">📥</div>
        <p>Одоогоор хүсэлт байхгүй байна.</p>
        <a href="<?= SITE_URL ?>/new_request.php" class="btn bp" style="margin-top:14px;display:inline-flex">➕ Шинэ хүсэлт</a>
      </div>
    <?php else: ?>
      <table><thead><tr><th>Гарчиг</th><th>Тэргүүлэх</th><th>Төлөв</th><th>Огноо</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($reqs as $r): ?>
        <tr>
          <td><strong><?= h($r['title']) ?></strong></td>
          <td><span class="b b-<?= h($r['priority']) ?>"><?= h($pmn[$r['priority']] ?? $r['priority']) ?></span></td>
          <td><span class="b b-<?= h($r['status']) ?>"><?= h($smn[$r['status']] ?? $r['status']) ?></span></td>
          <td><?= date('Y-m-d', strtotime($r['created_at'])) ?></td>
          <td><a href="<?= SITE_URL ?>/view_request.php?id=<?= $r['id'] ?>" class="btn bp bsm">👁 Харах</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody></table>
    <?php endif; ?>
  </div>
  <div class="cgrid" style="margin-top:24px">
    <a href="<?= SITE_URL ?>/new_request.php" class="card" style="cursor:pointer"><div class="cico ib">➕</div><h3>Засварын хүсэлт</h3><p>Компьютерийн засварын хүсэлт гаргах, цаг товлох</p></a>
    <a href="<?= SITE_URL ?>/knowledge.php" class="card" style="cursor:pointer"><div class="cico ig">📚</div><h3>Мэдлэгийн сан</h3><p>Нийтлэг асуудлуудын шийдлийг хайх</p></a>
    <a href="<?= SITE_URL ?>/parts.php" class="card" style="cursor:pointer"><div class="cico iy">⚙️</div><h3>Нөөц эд анги</h3><p>Нөөцийн эд ангиудын жагсаалт харах</p></a>
  </div>
</div></div>
<?php require_once 'includes/footer.php'; ?>
