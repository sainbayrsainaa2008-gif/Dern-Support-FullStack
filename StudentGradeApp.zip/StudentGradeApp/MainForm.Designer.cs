namespace StudentGradeApp
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        // ── Header панел ──────────────────────────────────────
        private Panel panelHeader;
        private Label lblTitle;
        private Label lblSubtitle;
        private PictureBox picLogo;

        // ── Табууд ────────────────────────────────────────────
        private TabControl tabMain;
        private TabPage tabGrade;
        private TabPage tabRecords;

        // ── Оюутны мэдээлэл оруулах хэсэг ───────────────────
        private GroupBox grpStudentInfo;
        private Label lblName;
        private TextBox txtName;
        private Label lblLevel;
        private ComboBox cmbLevel;

        // ── Нэгжийн дүн ───────────────────────────────────────
        private GroupBox grpUnits;
        private Label lblUnit1;
        private RadioButton rdoU1Pass, rdoU1Merit, rdoU1Distinction, rdoU1Refer;
        private Label lblUnit3;
        private RadioButton rdoU3Pass, rdoU3Merit, rdoU3Distinction, rdoU3Refer;
        private Label lblUnit4;
        private RadioButton rdoU4Pass, rdoU4Merit, rdoU4Distinction, rdoU4Refer;
        private Label lblUnit6;
        private RadioButton rdoU6Pass, rdoU6Merit, rdoU6Distinction, rdoU6Refer;

        // ── Үр дүн ────────────────────────────────────────────
        private GroupBox grpResult;
        private Label lblGradeResult;
        private Label lblCategoryResult;
        private Label lblGradeValue;
        private Label lblCategoryValue;

        // ── Товчлуурууд ───────────────────────────────────────
        private Button btnCalculate;
        private Button btnSave;
        private Button btnClear;

        // ── Бүртгэлийн таб ────────────────────────────────────
        private DataGridView dgvStudents;
        private Button btnRefresh;
        private Button btnDelete;
        private Label lblRecordCount;
        private Panel panelRecordTop;

        // ── Доод хэсэг ────────────────────────────────────────
        private Panel panelStatus;
        private Label lblStatus;
        private Label lblDbStatus;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // ── Form тохиргоо ──────────────────────────────────
            this.Text = "American University in Dubai — Student Grade Classifier";
            this.Size = new Size(1050, 750);
            this.MinimumSize = new Size(900, 650);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(245, 247, 250);
            this.Font = new Font("Segoe UI", 9f);

            // ═══════════════════════════════════════════════════
            // HEADER
            // ═══════════════════════════════════════════════════
            panelHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 80,
                BackColor = Color.FromArgb(0, 51, 102)
            };

            lblTitle = new Label
            {
                Text = "🎓  Student Grade & Scholarship Classifier",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 18f, FontStyle.Bold),
                Location = new Point(20, 12),
                AutoSize = true
            };

            lblSubtitle = new Label
            {
                Text = "American University in Dubai  |  BTEC International Level 3",
                ForeColor = Color.FromArgb(180, 210, 255),
                Font = new Font("Segoe UI", 10f),
                Location = new Point(23, 50),
                AutoSize = true
            };

            panelHeader.Controls.AddRange(new Control[] { lblTitle, lblSubtitle });

            // ═══════════════════════════════════════════════════
            // STATUS BAR
            // ═══════════════════════════════════════════════════
            panelStatus = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 28,
                BackColor = Color.FromArgb(230, 235, 245)
            };

            lblStatus = new Label
            {
                Text = "Бэлэн",
                Location = new Point(10, 5),
                AutoSize = true,
                ForeColor = Color.FromArgb(60, 60, 60)
            };

            lblDbStatus = new Label
            {
                Text = "● DB: Холбогдоогүй",
                Location = new Point(900, 5),
                AutoSize = true,
                ForeColor = Color.OrangeRed
            };

            panelStatus.Controls.AddRange(new Control[] { lblStatus, lblDbStatus });

            // ═══════════════════════════════════════════════════
            // TAB CONTROL
            // ═══════════════════════════════════════════════════
            tabMain = new TabControl
            {
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 10f),
                Padding = new Point(15, 5)
            };

            tabGrade = new TabPage { Text = "  📝 Дүн Оруулах  ", BackColor = Color.FromArgb(245, 247, 250) };
            tabRecords = new TabPage { Text = "  📋 Бүртгэл  ", BackColor = Color.FromArgb(245, 247, 250) };

            // ═══════════════════════════════════════════════════
            // TAB 1 — GRADE INPUT
            // ═══════════════════════════════════════════════════
            BuildGradeTab();

            // ═══════════════════════════════════════════════════
            // TAB 2 — RECORDS
            // ═══════════════════════════════════════════════════
            BuildRecordsTab();

            tabMain.TabPages.AddRange(new TabPage[] { tabGrade, tabRecords });

            // ═══════════════════════════════════════════════════
            // FORM ASSEMBLY
            // ═══════════════════════════════════════════════════
            this.Controls.Add(tabMain);
            this.Controls.Add(panelHeader);
            this.Controls.Add(panelStatus);

            this.ResumeLayout(false);
        }

        // ────────────────────────────────────────────────────────
        private void BuildGradeTab()
        {
            var panel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(15) };

            // Student Info GroupBox
            grpStudentInfo = CreateGroup("👤  Оюутны мэдээлэл", new Rectangle(10, 10, 480, 100));

            lblName = new Label { Text = "Нэр:", Location = new Point(15, 30), AutoSize = true };
            txtName = new TextBox
            {
                Location = new Point(120, 27),
                Width = 200,
                Font = new Font("Segoe UI", 10f),
                BorderStyle = BorderStyle.FixedSingle
            };

            lblLevel = new Label { Text = "Түвшин:", Location = new Point(340, 30), AutoSize = true };
            cmbLevel = new ComboBox
            {
                Location = new Point(340, 50),
                Width = 120,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10f)
            };
            cmbLevel.Items.AddRange(new object[] { "Level 2", "Level 3", "Level 4", "Level 5" });
            cmbLevel.SelectedIndex = 1;

            grpStudentInfo.Controls.AddRange(new Control[] { lblName, txtName, lblLevel, cmbLevel });

            // Units GroupBox
            grpUnits = CreateGroup("📚  Нэгжийн дүн оруулах", new Rectangle(10, 120, 680, 310));

            // Unit headers
            string[] headers = { "PASS", "MERIT", "DISTINCTION", "REFER" };
            int[] hx = { 175, 270, 365, 475 };
            for (int i = 0; i < headers.Length; i++)
            {
                var lbl = new Label
                {
                    Text = headers[i],
                    Location = new Point(hx[i], 25),
                    AutoSize = true,
                    Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                    ForeColor = i == 3 ? Color.Crimson : Color.FromArgb(0, 80, 160)
                };
                grpUnits.Controls.Add(lbl);
            }

            // Unit rows
            (rdoU1Pass, rdoU1Merit, rdoU1Distinction, rdoU1Refer) = AddUnitRow(grpUnits, "Unit 1 — Information Technology:", 60);
            (rdoU3Pass, rdoU3Merit, rdoU3Distinction, rdoU3Refer) = AddUnitRow(grpUnits, "Unit 3 — Website Development:", 120);
            (rdoU4Pass, rdoU4Merit, rdoU4Distinction, rdoU4Refer) = AddUnitRow(grpUnits, "Unit 4 — Social Media in Business:", 180);
            (rdoU6Pass, rdoU6Merit, rdoU6Distinction, rdoU6Refer) = AddUnitRow(grpUnits, "Unit 6 — Programming:", 240);

            // Result GroupBox
            grpResult = CreateGroup("🏆  Дүнгийн үр дүн", new Rectangle(700, 10, 310, 200));

            lblGradeResult = new Label { Text = "Эцсийн дүн:", Location = new Point(15, 40), AutoSize = true };
            lblGradeValue = new Label
            {
                Text = "—",
                Location = new Point(15, 65),
                Size = new Size(280, 50),
                Font = new Font("Segoe UI", 22f, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 100, 50),
                TextAlign = ContentAlignment.MiddleCenter
            };

            lblCategoryResult = new Label { Text = "Ангилал:", Location = new Point(15, 120), AutoSize = true };
            lblCategoryValue = new Label
            {
                Text = "—",
                Location = new Point(15, 140),
                Size = new Size(280, 45),
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 60, 130),
                TextAlign = ContentAlignment.MiddleCenter
            };

            grpResult.Controls.AddRange(new Control[] {
                lblGradeResult, lblGradeValue, lblCategoryResult, lblCategoryValue
            });

            // Buttons
            btnCalculate = CreateButton("🔍  Тооцоолох", new Rectangle(10, 440), Color.FromArgb(0, 120, 215));
            btnSave = CreateButton("💾  Хадгалах", new Rectangle(170, 440), Color.FromArgb(16, 124, 16));
            btnClear = CreateButton("🗑  Цэвэрлэх", new Rectangle(330, 440), Color.FromArgb(150, 50, 50));

            btnSave.Enabled = false;

            btnCalculate.Click += BtnCalculate_Click;
            btnSave.Click += BtnSave_Click;
            btnClear.Click += BtnClear_Click;

            panel.Controls.AddRange(new Control[] {
                grpStudentInfo, grpUnits, grpResult, btnCalculate, btnSave, btnClear
            });

            tabGrade.Controls.Add(panel);
        }

        // ────────────────────────────────────────────────────────
        private void BuildRecordsTab()
        {
            panelRecordTop = new Panel
            {
                Dock = DockStyle.Top,
                Height = 50,
                BackColor = Color.FromArgb(235, 240, 250),
                Padding = new Padding(10, 8, 10, 8)
            };

            btnRefresh = CreateButton("🔄  Шинэчлэх", new Rectangle(10, 8), Color.FromArgb(0, 120, 215));
            btnRefresh.Width = 130;
            btnDelete = CreateButton("🗑  Устгах", new Rectangle(155, 8), Color.FromArgb(200, 50, 50));
            btnDelete.Width = 110;

            lblRecordCount = new Label
            {
                Text = "Нийт: 0 бүртгэл",
                Location = new Point(290, 15),
                AutoSize = true,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 60, 130)
            };

            panelRecordTop.Controls.AddRange(new Control[] { btnRefresh, btnDelete, lblRecordCount });

            dgvStudents = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                Font = new Font("Segoe UI", 9.5f),
                GridColor = Color.FromArgb(220, 225, 235),
                ColumnHeadersHeight = 36,
                RowTemplate = { Height = 32 },
                AlternatingRowsDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(240, 245, 255)
                }
            };
            dgvStudents.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            dgvStudents.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(0, 51, 102);
            dgvStudents.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            btnRefresh.Click += BtnRefresh_Click;
            btnDelete.Click += BtnDelete_Click;

            tabRecords.Controls.Add(dgvStudents);
            tabRecords.Controls.Add(panelRecordTop);
        }

        // ────────────────────────────────────────────────────────
        // Helper methods
        // ────────────────────────────────────────────────────────
        private GroupBox CreateGroup(string title, Rectangle bounds)
        {
            return new GroupBox
            {
                Text = title,
                Location = bounds.Location,
                Size = bounds.Size,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 51, 102),
                BackColor = Color.White,
                Padding = new Padding(10)
            };
        }

        private Button CreateButton(string text, Rectangle bounds, Color backColor)
        {
            return new Button
            {
                Text = text,
                Location = bounds.Location,
                Size = new Size(145, 40),
                BackColor = backColor,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                Cursor = Cursors.Hand,
                FlatAppearance = { BorderSize = 0 }
            };
        }

        private (RadioButton pass, RadioButton merit, RadioButton distinction, RadioButton refer)
            AddUnitRow(GroupBox parent, string labelText, int y)
        {
            var lbl = new Label
            {
                Text = labelText,
                Location = new Point(15, y + 4),
                Width = 300,
                Font = new Font("Segoe UI", 9.5f)
            };

            var rdoP = new RadioButton { Text = "", Location = new Point(190, y), Width = 60 };
            var rdoM = new RadioButton { Text = "", Location = new Point(285, y), Width = 60 };
            var rdoD = new RadioButton { Text = "", Location = new Point(380, y), Width = 60 };
            var rdoR = new RadioButton { Text = "", Location = new Point(490, y), Width = 60, ForeColor = Color.Crimson };
            rdoP.Checked = true;

            parent.Controls.AddRange(new Control[] { lbl, rdoP, rdoM, rdoD, rdoR });
            return (rdoP, rdoM, rdoD, rdoR);
        }
    }
}
