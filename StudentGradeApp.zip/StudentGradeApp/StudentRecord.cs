namespace StudentGradeApp
{
    /// <summary>
    /// Оюутны дүнгийн мэдээллийн загвар
    /// </summary>
    public class StudentRecord
    {
        public int Id { get; set; }
        public string StudentName { get; set; } = "";
        public string Level { get; set; } = "";
        public string Unit1 { get; set; } = "";   // Information Technology
        public string Unit3 { get; set; } = "";   // Website Development
        public string Unit4 { get; set; } = "";   // Social Media in Business
        public string Unit6 { get; set; } = "";   // Programming
        public string FinalGrade { get; set; } = "";
        public string Category { get; set; } = "";
        public DateTime SubmissionDate { get; set; }

        /// <summary>
        /// Дүн тооцоолох логик — Ibtisam-ийн хийсэнтэй адил
        /// DISTINCTION > MERIT > PASS > REFER
        /// </summary>
        public static (string grade, string category) CalculateGrade(
            string u1, string u3, string u4, string u6)
        {
            var units = new[] { u1, u3, u4, u6 };

            // Хэрэв ямар нэг нэгжид REFER байвал дүн тооцохгүй
            if (units.Any(u => u == "REFER"))
                return ("REFER", "Тэнцэхгүй - Scholarship/Internship эрхгүй");

            // Бүгд DISTINCTION бол
            if (units.All(u => u == "DISTINCTION"))
                return ("DISTINCTION", "Category 1 - Тэнцлээ");

            // Бүгд MERIT буюу дээш бол
            if (units.All(u => u == "MERIT" || u == "DISTINCTION"))
                return ("MERIT", "Category 2 - Тэнцлээ");

            // Бүгд PASS буюу дээш бол
            if (units.All(u => u == "PASS" || u == "MERIT" || u == "DISTINCTION"))
                return ("PASS", "Category 3 - Тэнцлээ");

            return ("REFER", "Тэнцэхгүй - Scholarship/Internship эрхгүй");
        }
    }
}
