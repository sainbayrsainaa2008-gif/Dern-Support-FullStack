-- ============================================================
--  Student Grade Classifier — XAMPP MySQL Setup Script
--  Энэ файлыг phpMyAdmin дээр ажиллуулна
-- ============================================================

-- 1. Database үүсгэ
CREATE DATABASE IF NOT EXISTS student_grade_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE student_grade_db;

-- 2. Оюутны дүнгийн хүснэгт үүсгэ
CREATE TABLE IF NOT EXISTS students (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    student_name    VARCHAR(100)    NOT NULL COMMENT 'Оюутны нэр',
    student_level   VARCHAR(20)     NOT NULL COMMENT 'Судлалын түвшин',
    unit1_it        VARCHAR(20)     NOT NULL COMMENT 'Unit 1 - Information Technology',
    unit3_web       VARCHAR(20)     NOT NULL COMMENT 'Unit 3 - Website Development',
    unit4_social    VARCHAR(20)     NOT NULL COMMENT 'Unit 4 - Social Media in Business',
    unit6_prog      VARCHAR(20)     NOT NULL COMMENT 'Unit 6 - Programming',
    final_grade     VARCHAR(30)     NOT NULL COMMENT 'Эцсийн дүн: DISTINCTION/MERIT/PASS/REFER',
    category        VARCHAR(60)     NOT NULL COMMENT 'Ангилал: Category 1/2/3 эсвэл Тэнцэхгүй',
    submission_date DATETIME        DEFAULT CURRENT_TIMESTAMP COMMENT 'Оруулсан огноо'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Туршилтын өгөгдөл
INSERT INTO students (student_name, student_level, unit1_it, unit3_web, unit4_social, unit6_prog, final_grade, category)
VALUES
    ('Баяр Дорж',     'Level 3', 'DISTINCTION', 'DISTINCTION', 'DISTINCTION', 'DISTINCTION', 'DISTINCTION', 'Category 1 - Тэнцлээ'),
    ('Сарнай Болд',   'Level 3', 'MERIT',       'MERIT',       'MERIT',       'MERIT',       'MERIT',       'Category 2 - Тэнцлээ'),
    ('Энхбат Гомбо',  'Level 2', 'PASS',        'PASS',        'MERIT',       'PASS',        'PASS',        'Category 3 - Тэнцлээ'),
    ('Оюунаа Лхамаа', 'Level 3', 'PASS',        'REFER',       'MERIT',       'PASS',        'REFER',       'Тэнцэхгүй - Scholarship/Internship эрхгүй');

-- 4. Шалгах query
SELECT 
    id,
    student_name    AS 'Нэр',
    student_level   AS 'Түвшин',
    final_grade     AS 'Дүн',
    category        AS 'Ангилал',
    submission_date AS 'Огноо'
FROM students
ORDER BY submission_date DESC;
