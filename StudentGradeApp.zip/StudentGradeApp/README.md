# 🎓 Student Grade & Scholarship Classifier
**Visual Studio 2022 · Windows Forms · .NET 8 · XAMPP MySQL**

---

## 📋 Програмын тухай
Ibtisam Waheed-ийн BTEC Unit 4 Programming дүн оруулах програмын дэвшилтэт хувилбар.
- Оюутны 4 нэгжийн дүн оруулж DISTINCTION / MERIT / PASS / REFER тооцоолно
- Scholarship/Internship ангилал автоматаар тодорхойлно
- MySQL database-д хадгалж бүртгэл хөтөлнө

---

## ⚙️ Суулгах заавар

### 1. XAMPP тохируулах
1. [XAMPP](https://www.apachefriends.org/) татаж суулгана
2. XAMPP Control Panel → **MySQL** → Start
3. Хөтөч дээр `http://localhost/phpmyadmin` нээнэ
4. **SQL** таб → `setup_database.sql` файлын агуулгыг хуулж ажиллуулна

### 2. Visual Studio 2022 тохируулах
1. Visual Studio 2022 нээнэ
2. `StudentGradeApp.csproj` файлыг нээнэ
3. NuGet Package Manager → `MySql.Data` суулгана (эсвэл автоматаар суугдана)
4. **F5** дарж ажиллуулна

### 3. Database холболт өөрчлөх (шаардлагатай бол)
`DatabaseHelper.cs` файлд:
```csharp
private static string connectionString =
    "Server=localhost;Port=3306;Database=student_grade_db;Uid=root;Pwd=;";
```
- `Pwd=` — XAMPP-ийн MySQL нууц үг (ихэнхдээ хоосон)
- `Port=3306` — анхдагч порт

---

## 🏗️ Файлын бүтэц
```
StudentGradeApp/
├── StudentGradeApp.csproj    ← Проектийн файл
├── Program.cs                ← Entry point
├── MainForm.cs               ← Гол логик (event handlers)
├── MainForm.Designer.cs      ← UI зохион байгуулалт
├── StudentRecord.cs          ← Дүн тооцоолох загвар
├── DatabaseHelper.cs         ← MySQL CRUD операцууд
├── setup_database.sql        ← Database үүсгэх скрипт
└── README.md                 ← Энэ файл
```

---

## 📊 Дүн тооцоолох логик

| Бүх нэгжийн дүн        | Эцсийн дүн    | Ангилал     |
|-------------------------|---------------|-------------|
| Бүгд DISTINCTION        | DISTINCTION   | Category 1  |
| Бүгд MERIT+ DISTINCTION | MERIT         | Category 2  |
| Бүгд PASS+дээш          | PASS          | Category 3  |
| Аль нэгэнд REFER байвал | REFER         | Тэнцэхгүй  |

---

## 🗄️ Database хүснэгтийн бүтэц

| Багана          | Төрөл       | Тайлбар                    |
|-----------------|-------------|----------------------------|
| id              | INT (PK)    | Автомат дугаар             |
| student_name    | VARCHAR(100)| Оюутны нэр                 |
| student_level   | VARCHAR(20) | Level 2–5                  |
| unit1_it        | VARCHAR(20) | Unit 1 дүн                 |
| unit3_web       | VARCHAR(20) | Unit 3 дүн                 |
| unit4_social    | VARCHAR(20) | Unit 4 дүн                 |
| unit6_prog      | VARCHAR(20) | Unit 6 дүн                 |
| final_grade     | VARCHAR(30) | Эцсийн дүн                 |
| category        | VARCHAR(60) | Ангилал                    |
| submission_date | DATETIME    | Оруулсан огноо             |

---

## 👩‍💻 Технологийн стэк
- **UI**: Windows Forms (.NET 8)
- **IDE**: Visual Studio 2022
- **Database**: MySQL 8 (XAMPP)
- **Connector**: MySql.Data NuGet package
- **Хэл**: C# 12
