namespace StudentGradeApp
{
    public partial class MainForm : Form
    {
        private StudentRecord? _currentResult = null;

        public MainForm()
        {
            InitializeComponent();
            this.Load += MainForm_Load;
        }

        // ═══════════════════════════════════════════════════════
        // FORM LOAD
        // ═══════════════════════════════════════════════════════
        private void MainForm_Load(object? sender, EventArgs e)
        {
            try
            {
                DatabaseHelper.InitializeDatabase();

                if (DatabaseHelper.TestConnection())
                {
                    lblDbStatus.Text = "● DB: Холбогдсон";
                    lblDbStatus.ForeColor = Color.FromArgb(0, 150, 50);
                    SetStatus("MySQL database холбогдлоо ✓");
                    LoadRecords();
                }
                else
                {
                    lblDbStatus.Text = "● DB: Алдаа";
                    lblDbStatus.ForeColor = Color.Crimson;
                    SetStatus("⚠ XAMPP MySQL ажиллаж байгаа эсэхийг шалгана уу!");
                }
            }
            catch (Exception ex)
            {
                lblDbStatus.Text = "● DB: Алдаа";
                lblDbStatus.ForeColor = Color.Crimson;
                MessageBox.Show(
                    $"Database холбогдоход алдаа гарлаа:\n\n{ex.Message}\n\n" +
                    "XAMPP-ийн MySQL ажиллаж байгаа эсэхийг шалгана уу.",
                    "Database Алдаа",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
            }
        }

        // ═══════════════════════════════════════════════════════
        // CALCULATE BUTTON
        // ═══════════════════════════════════════════════════════
        private void BtnCalculate_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Оюутны нэр оруулна уу!", "Анхаар", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtName.Focus();
                return;
            }

            string u1 = GetUnitGrade(rdoU1Pass, rdoU1Merit, rdoU1Distinction, rdoU1Refer);
            string u3 = GetUnitGrade(rdoU3Pass, rdoU3Merit, rdoU3Distinction, rdoU3Refer);
            string u4 = GetUnitGrade(rdoU4Pass, rdoU4Merit, rdoU4Distinction, rdoU4Refer);
            string u6 = GetUnitGrade(rdoU6Pass, rdoU6Merit, rdoU6Distinction, rdoU6Refer);

            var (grade, category) = StudentRecord.CalculateGrade(u1, u3, u4, u6);

            // Дүнг харуулах
            lblGradeValue.Text = grade;
            lblCategoryValue.Text = category;

            // Өнгө
            lblGradeValue.ForeColor = grade switch
            {
                "DISTINCTION" => Color.FromArgb(0, 130, 50),
                "MERIT"       => Color.FromArgb(0, 80, 160),
                "PASS"        => Color.FromArgb(130, 100, 0),
                _             => Color.Crimson
            };

            // Ангилалын хязгаарын өнгө
            grpResult.BackColor = grade switch
            {
                "DISTINCTION" => Color.FromArgb(235, 255, 240),
                "MERIT"       => Color.FromArgb(235, 245, 255),
                "PASS"        => Color.FromArgb(255, 252, 230),
                _             => Color.FromArgb(255, 235, 235)
            };

            _currentResult = new StudentRecord
            {
                StudentName = txtName.Text.Trim(),
                Level       = cmbLevel.SelectedItem?.ToString() ?? "Level 3",
                Unit1       = u1,
                Unit3       = u3,
                Unit4       = u4,
                Unit6       = u6,
                FinalGrade  = grade,
                Category    = category
            };

            btnSave.Enabled = true;
            SetStatus($"Тооцоолол дуусав: {txtName.Text} → {grade}");
        }

        // ═══════════════════════════════════════════════════════
        // SAVE BUTTON
        // ═══════════════════════════════════════════════════════
        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (_currentResult == null) return;

            if (DatabaseHelper.SaveStudent(_currentResult))
            {
                MessageBox.Show(
                    $"✅ Амжилттай хадгалагдлаа!\n\n" +
                    $"Оюутан: {_currentResult.StudentName}\n" +
                    $"Дүн: {_currentResult.FinalGrade}\n" +
                    $"Ангилал: {_currentResult.Category}",
                    "Хадгалагдлаа",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
                SetStatus($"Хадгалагдлаа: {_currentResult.StudentName}");
                btnSave.Enabled = false;
                LoadRecords();
            }
        }

        // ═══════════════════════════════════════════════════════
        // CLEAR BUTTON
        // ═══════════════════════════════════════════════════════
        private void BtnClear_Click(object? sender, EventArgs e)
        {
            txtName.Clear();
            cmbLevel.SelectedIndex = 1;

            rdoU1Pass.Checked = true;
            rdoU3Pass.Checked = true;
            rdoU4Pass.Checked = true;
            rdoU6Pass.Checked = true;

            lblGradeValue.Text = "—";
            lblGradeValue.ForeColor = Color.FromArgb(0, 100, 50);
            lblCategoryValue.Text = "—";
            grpResult.BackColor = Color.White;

            btnSave.Enabled = false;
            _currentResult = null;
            SetStatus("Цэвэрлэгдлээ");
        }

        // ═══════════════════════════════════════════════════════
        // REFRESH RECORDS
        // ═══════════════════════════════════════════════════════
        private void BtnRefresh_Click(object? sender, EventArgs e) => LoadRecords();

        private void LoadRecords()
        {
            var students = DatabaseHelper.GetAllStudents();

            dgvStudents.DataSource = students.Select(s => new
            {
                ID        = s.Id,
                Нэр       = s.StudentName,
                Түвшин    = s.Level,
                Unit1_IT  = s.Unit1,
                Unit3_Web = s.Unit3,
                Unit4_Soc = s.Unit4,
                Unit6_Prog= s.Unit6,
                Дүн       = s.FinalGrade,
                Ангилал   = s.Category,
                Огноо     = s.SubmissionDate.ToString("yyyy-MM-dd HH:mm")
            }).ToList();

            lblRecordCount.Text = $"Нийт: {students.Count} бүртгэл";

            // Дүнгийн баганын өнгө
            foreach (DataGridViewRow row in dgvStudents.Rows)
            {
                var grade = row.Cells["Дүн"]?.Value?.ToString();
                row.DefaultCellStyle.ForeColor = grade switch
                {
                    "DISTINCTION" => Color.FromArgb(0, 130, 50),
                    "MERIT"       => Color.FromArgb(0, 80, 160),
                    "PASS"        => Color.FromArgb(130, 100, 0),
                    _             => Color.Crimson
                };
            }
        }

        // ═══════════════════════════════════════════════════════
        // DELETE RECORD
        // ═══════════════════════════════════════════════════════
        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (dgvStudents.SelectedRows.Count == 0)
            {
                MessageBox.Show("Устгах бүртгэл сонгоно уу!", "Анхаар", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var row = dgvStudents.SelectedRows[0];
            int id = Convert.ToInt32(row.Cells["ID"].Value);
            string name = row.Cells["Нэр"].Value?.ToString() ?? "";

            var result = MessageBox.Show(
                $"'{name}' оюутны бүртгэлийг устгах уу?",
                "Баталгаажуулах",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                if (DatabaseHelper.DeleteStudent(id))
                {
                    SetStatus($"Устгагдлаа: {name}");
                    LoadRecords();
                }
            }
        }

        // ═══════════════════════════════════════════════════════
        // HELPERS
        // ═══════════════════════════════════════════════════════
        private string GetUnitGrade(RadioButton pass, RadioButton merit, RadioButton distinction, RadioButton refer)
        {
            if (distinction.Checked) return "DISTINCTION";
            if (merit.Checked)       return "MERIT";
            if (refer.Checked)       return "REFER";
            return "PASS";
        }

        private void SetStatus(string msg)
        {
            lblStatus.Text = $"[{DateTime.Now:HH:mm:ss}]  {msg}";
        }
    }
}
