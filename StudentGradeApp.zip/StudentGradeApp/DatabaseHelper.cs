using MySql.Data.MySqlClient;

namespace StudentGradeApp
{
    public static class DatabaseHelper
    {
        // ⚙️ XAMPP MySQL холболтын тохиргоо
        private static string connectionString =
            "Server=localhost;Port=3306;Database=student_grade_db;Uid=root;Pwd=;";

        public static MySqlConnection GetConnection()
        {
            return new MySqlConnection(connectionString);
        }

        /// <summary>
        /// Database болон хүснэгт автоматаар үүсгэнэ (XAMPP дээр ажиллуулахад шаардлагатай)
        /// </summary>
        public static void InitializeDatabase()
        {
            // Эхлээд database-гүйгээр холбогдоно
            string rootConn = "Server=localhost;Port=3306;Uid=root;Pwd=;";
            using var conn = new MySqlConnection(rootConn);
            conn.Open();

            // Database үүсгэ
            var createDb = new MySqlCommand(
                "CREATE DATABASE IF NOT EXISTS student_grade_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;",
                conn);
            createDb.ExecuteNonQuery();

            conn.ChangeDatabase("student_grade_db");

            // Students хүснэгт үүсгэ
            string createTable = @"
                CREATE TABLE IF NOT EXISTS students (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    student_name VARCHAR(100) NOT NULL,
                    student_level VARCHAR(20) NOT NULL,
                    unit1_it VARCHAR(20) NOT NULL,
                    unit3_web VARCHAR(20) NOT NULL,
                    unit4_social VARCHAR(20) NOT NULL,
                    unit6_prog VARCHAR(20) NOT NULL,
                    final_grade VARCHAR(30) NOT NULL,
                    category VARCHAR(20) NOT NULL,
                    submission_date DATETIME DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB;
            ";
            new MySqlCommand(createTable, conn).ExecuteNonQuery();
        }

        /// <summary>
        /// Оюутны мэдээлэл хадгалах
        /// </summary>
        public static bool SaveStudent(StudentRecord record)
        {
            try
            {
                using var conn = GetConnection();
                conn.Open();

                string query = @"
                    INSERT INTO students 
                        (student_name, student_level, unit1_it, unit3_web, unit4_social, unit6_prog, final_grade, category)
                    VALUES 
                        (@name, @level, @unit1, @unit3, @unit4, @unit6, @grade, @category)";

                using var cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@name", record.StudentName);
                cmd.Parameters.AddWithValue("@level", record.Level);
                cmd.Parameters.AddWithValue("@unit1", record.Unit1);
                cmd.Parameters.AddWithValue("@unit3", record.Unit3);
                cmd.Parameters.AddWithValue("@unit4", record.Unit4);
                cmd.Parameters.AddWithValue("@unit6", record.Unit6);
                cmd.Parameters.AddWithValue("@grade", record.FinalGrade);
                cmd.Parameters.AddWithValue("@category", record.Category);

                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Database алдаа: {ex.Message}", "Алдаа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /// <summary>
        /// Бүх оюутны бүртгэл авах
        /// </summary>
        public static List<StudentRecord> GetAllStudents()
        {
            var list = new List<StudentRecord>();
            try
            {
                using var conn = GetConnection();
                conn.Open();
                string query = "SELECT * FROM students ORDER BY submission_date DESC";
                using var cmd = new MySqlCommand(query, conn);
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(new StudentRecord
                    {
                        Id = reader.GetInt32("id"),
                        StudentName = reader.GetString("student_name"),
                        Level = reader.GetString("student_level"),
                        Unit1 = reader.GetString("unit1_it"),
                        Unit3 = reader.GetString("unit3_web"),
                        Unit4 = reader.GetString("unit4_social"),
                        Unit6 = reader.GetString("unit6_prog"),
                        FinalGrade = reader.GetString("final_grade"),
                        Category = reader.GetString("category"),
                        SubmissionDate = reader.GetDateTime("submission_date")
                    });
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Өгөгдөл татах алдаа: {ex.Message}", "Алдаа", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return list;
        }

        /// <summary>
        /// Оюутны бүртгэл устгах
        /// </summary>
        public static bool DeleteStudent(int id)
        {
            try
            {
                using var conn = GetConnection();
                conn.Open();
                var cmd = new MySqlCommand("DELETE FROM students WHERE id = @id", conn);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Устгах алдаа: {ex.Message}", "Алдаа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /// <summary>
        /// Холболт шалгах
        /// </summary>
        public static bool TestConnection()
        {
            try
            {
                using var conn = GetConnection();
                conn.Open();
                return true;
            }
            catch { return false; }
        }
    }
}
