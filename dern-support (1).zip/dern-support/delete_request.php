<?php
require_once 'includes/config.php';
requireLogin();
$db = getDB();
$uid = $_SESSION['user_id'];
$id = intval($_GET['id'] ?? 0);

$stmt = $db->prepare("DELETE FROM support_requests WHERE id=? AND user_id=? AND status='pending'");
$stmt->bind_param('ii', $id, $uid);
$stmt->execute();

header('Location: ' . SITE_URL . '/requests.php');
exit;
?>
