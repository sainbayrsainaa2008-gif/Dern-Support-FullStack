<?php
$pageTitle = 'Хүсэлтийн дэлгэрэнгүй';
require_once 'includes/config.php';
requireLogin();
$db = getDB();
$uid = $_SESSION['user_id'];
$id = intval($_GET['id'] ?? 0);

$stmt = $db->prepare("SELECT * FROM support_requests WHERE id=? AND user_id=?");
$stmt->bind_param('ii', $id, $uid);
$stmt->execute();
$req = $stmt->get_result()->fetch_assoc();

if (!$req) { header('Location: ' . SITE_URL . '/requests.php'); exit; }

$statusMn = ['pending'=>'Хүлээгдэж буй','scheduled'=>'Товлосон','in_progress'=>'Хийгдэж байна','completed'=>'Дууссан','cancelled'=>'Цуцлагдсан'];
$priorityMn = ['low'=>'Бага','medium'=>'Дунд','high'=>'Өндөр','urgent'=>'Яаралтай'];
$statusColor = ['pending'=>'#f59e0b','scheduled'=>'#3b82f6','in_progress'=>'#8b5cf6','completed'=>'#10b981','cancelled'=>'#ef4444'];

require_once 'includes/header.php';
?>

<div class="page-header">
    <div class="page-header-inner">
        <h1><i class="fas fa-ticket-alt"></i> Хүсэлт #<?= $req['id'] ?></h1>
        <a href="requests.php" class="btn btn-secondary" style="background:var(--border);color:var(--dark);"><i class="fas fa-arrow-left"></i> Буцах</a>
    </div>
</div>

<div class="section">
    <div class="container" style="max-width:800px;">
        <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success"><i class="fas fa-check-circle"></i> Хүсэлт амжилттай илгээгдлээ! Манай мэргэжилтэн тантай удахгүй холбоо барина.</div>
        <?php endif; ?>

        <div style="background:var(--white);border-radius:var(--radius);box-shadow:var(--shadow);overflow:hidden;">
            <!-- Статус баар -->
            <div style="background:<?= $statusColor[$req['status']] ?>;padding:16px 24px;display:flex;justify-content:space-between;align-items:center;">
                <span style="color:#fff;font-weight:700;font-size:1.1rem;"><?= $statusMn[$req['status']] ?></span>
                <span style="color:rgba(255,255,255,.8);font-size:0.9rem;"><?= date('Y оны m сарын d', strtotime($req['created_at'])) ?></span>
            </div>

            <div style="padding:28px;">
                <h2 style="margin-bottom:20px;"><?= clean($req['title']) ?></h2>

                <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:24px;background:var(--light);border-radius:8px;padding:16px;">
                    <div>
                        <p style="font-size:0.8rem;color:var(--gray);margin-bottom:4px;">ТОНОГ ТӨХӨӨРӨМЖ</p>
                        <p style="font-weight:600;"><?= clean($req['device_type'] ?? 'Тодорхойгүй') ?></p>
                    </div>
                    <div>
                        <p style="font-size:0.8rem;color:var(--gray);margin-bottom:4px;">ЯАРАЛТАЙ ЭСЭХ</p>
                        <span class="badge badge-<?= $req['priority'] ?>"><?= $priorityMn[$req['priority']] ?></span>
                    </div>
                    <?php if ($req['estimated_cost']): ?>
                    <div>
                        <p style="font-size:0.8rem;color:var(--gray);margin-bottom:4px;">ҮНИЙН САНАЛ</p>
                        <p style="font-weight:600;color:var(--success);"><?= number_format($req['estimated_cost']) ?>₮</p>
                    </div>
                    <?php endif; ?>
                    <?php if ($req['scheduled_date']): ?>
                    <div>
                        <p style="font-size:0.8rem;color:var(--gray);margin-bottom:4px;">ТОВЛОСОН ЦАГ</p>
                        <p style="font-weight:600;"><?= date('Y-м-d', strtotime($req['scheduled_date'])) ?><?= $req['scheduled_time'] ? ' ' . substr($req['scheduled_time'], 0, 5) : '' ?></p>
                    </div>
                    <?php endif; ?>
                </div>

                <div style="margin-bottom:20px;">
                    <h4 style="margin-bottom:10px;color:var(--gray);">Тайлбар</h4>
                    <div style="background:var(--light);border-radius:8px;padding:16px;line-height:1.7;"><?= nl2br(clean($req['description'])) ?></div>
                </div>

                <!-- Явц -->
                <div>
                    <h4 style="margin-bottom:14px;">Хүсэлтийн явц</h4>
                    <div style="display:flex;gap:0;position:relative;">
                        <?php
                        $steps = ['pending','scheduled','in_progress','completed'];
                        $stepLabels = ['Хүлээгдэж буй','Товлосон','Хийгдэж байна','Дууссан'];
                        $currentStep = array_search($req['status'], $steps);
                        if ($currentStep === false) $currentStep = -1;
                        foreach ($steps as $i => $step):
                            $done = $i <= $currentStep;
                        ?>
                        <div style="flex:1;text-align:center;position:relative;">
                            <div style="width:32px;height:32px;border-radius:50%;margin:0 auto 8px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.85rem;background:<?= $done ? 'var(--primary)' : 'var(--border)' ?>;color:<?= $done ? '#fff' : 'var(--gray)' ?>;">
                                <?= $done ? '<i class="fas fa-check" style="font-size:.7rem;"></i>' : ($i+1) ?>
                            </div>
                            <p style="font-size:0.75rem;color:<?= $done ? 'var(--primary)' : 'var(--gray)' ?>;font-weight:<?= $done ? '600' : '400' ?>;"><?= $stepLabels[$i] ?></p>
                            <?php if ($i < count($steps)-1): ?>
                            <div style="position:absolute;top:16px;left:50%;width:100%;height:2px;background:<?= $i < $currentStep ? 'var(--primary)' : 'var(--border)' ?>;z-index:0;"></div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <?php if ($req['status'] === 'pending'): ?>
                <div style="margin-top:24px;padding-top:20px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;">
                    <a href="delete_request.php?id=<?= $req['id'] ?>" class="btn btn-danger btn-sm btn-delete"><i class="fas fa-times"></i> Хүсэлт цуцлах</a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
