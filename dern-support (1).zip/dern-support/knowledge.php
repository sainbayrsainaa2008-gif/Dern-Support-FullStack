<?php
$pageTitle = 'Мэдлэгийн сан';
require_once 'includes/config.php';
$db = getDB();

$category = clean($_GET['category'] ?? '');
$search = clean($_GET['search'] ?? '');

$sql = "SELECT * FROM knowledge_base WHERE 1=1";
$params = []; $types = '';

if ($category) { $sql .= " AND category=?"; $params[] = $category; $types .= 's'; }
if ($search) { $sql .= " AND (title LIKE ? OR problem_description LIKE ? OR solution LIKE ?)"; $s = "%$search%"; $params[] = $s; $params[] = $s; $params[] = $s; $types .= 'sss'; }
$sql .= " ORDER BY views DESC, created_at DESC";

$stmt = $db->prepare($sql);
if ($params) { $stmt->bind_param($types, ...$params); }
$stmt->execute();
$articles = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Ангиллуудыг авах
$cats = $db->query("SELECT DISTINCT category FROM knowledge_base ORDER BY category")->fetch_all(MYSQLI_ASSOC);

$diffMn = ['easy'=>'Хялбар','medium'=>'Дунд','hard'=>'Хэцүү'];

require_once 'includes/header.php';

// Нийтлэлийн views нэмэх
if (isset($_GET['id'])) {
    $aid = intval($_GET['id']);
    $db->query("UPDATE knowledge_base SET views = views + 1 WHERE id=$aid");
    $art = $db->query("SELECT * FROM knowledge_base WHERE id=$aid")->fetch_assoc();
}
?>

<div class="page-header">
    <div class="page-header-inner">
        <h1><i class="fas fa-book"></i> Мэдлэгийн сан</h1>
    </div>
</div>

<div class="section">
    <div class="container">

        <?php if (isset($art) && $art): ?>
        <!-- Нийтлэлийн дэлгэрэнгүй -->
        <div style="margin-bottom:20px;">
            <a href="knowledge.php" style="color:var(--primary);text-decoration:none;"><i class="fas fa-arrow-left"></i> Буцах</a>
        </div>
        <div style="background:var(--white);border-radius:var(--radius);box-shadow:var(--shadow);padding:32px;" class="difficulty-<?= $art['difficulty'] ?>" style="border-left:4px solid;">
            <div style="display:flex;gap:10px;align-items:center;margin-bottom:16px;flex-wrap:wrap;">
                <span class="kb-category"><?= clean($art['category']) ?></span>
                <span class="badge" style="background:var(--light);color:var(--gray);"><?= $diffMn[$art['difficulty']] ?></span>
                <span style="color:var(--gray);font-size:0.85rem;"><i class="fas fa-eye"></i> <?= $art['views'] ?> удаа харсан</span>
            </div>
            <h2 style="margin-bottom:20px;"><?= clean($art['title']) ?></h2>

            <div style="background:#fee2e2;border-radius:8px;padding:20px;margin-bottom:20px;">
                <h4 style="color:#991b1b;margin-bottom:10px;"><i class="fas fa-exclamation-triangle"></i> Асуудал</h4>
                <p><?= nl2br(clean($art['problem_description'])) ?></p>
            </div>
            <div style="background:#d1fae5;border-radius:8px;padding:20px;">
                <h4 style="color:#065f46;margin-bottom:10px;"><i class="fas fa-check-circle"></i> Шийдэл</h4>
                <p><?= nl2br(clean($art['solution'])) ?></p>
            </div>

            <div style="margin-top:24px;padding-top:20px;border-top:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;">
                <span style="color:var(--gray);font-size:0.85rem;">Асуудал шийдэгдсэнгүй юу?</span>
                <a href="<?= isset($_SESSION['user_id']) ? 'new_request.php' : 'register.php' ?>" class="btn btn-primary btn-sm"><i class="fas fa-headset"></i> Мэргэжилтэнд хандах</a>
            </div>
        </div>

        <?php else: ?>
        <!-- Жагсаалт -->
        <form method="GET" style="display:flex;gap:10px;margin-bottom:28px;flex-wrap:wrap;">
            <input type="text" name="search" placeholder="Хайх..." value="<?= $search ?>" style="flex:1;min-width:200px;padding:10px 16px;border:2px solid var(--border);border-radius:8px;font-size:.95rem;">
            <select name="category" style="padding:10px 14px;border:2px solid var(--border);border-radius:8px;font-size:.95rem;">
                <option value="">Бүх ангилал</option>
                <?php foreach ($cats as $c): ?>
                <option value="<?= clean($c['category']) ?>" <?= $category === $c['category'] ? 'selected' : '' ?>><?= clean($c['category']) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Хайх</button>
            <?php if ($search || $category): ?>
            <a href="knowledge.php" class="btn" style="background:var(--border);color:var(--dark);"><i class="fas fa-times"></i> Цэвэрлэх</a>
            <?php endif; ?>
        </form>

        <?php if (empty($articles)): ?>
        <div style="text-align:center;padding:60px;color:var(--gray);">
            <i class="fas fa-search" style="font-size:3rem;display:block;margin-bottom:16px;opacity:.3;"></i>
            <p>Хайлтын үр дүн олдсонгүй</p>
        </div>
        <?php else: ?>
        <div style="margin-bottom:12px;color:var(--gray);font-size:0.9rem;"><i class="fas fa-list"></i> <?= count($articles) ?> нийтлэл олдлоо</div>
        <div class="kb-grid">
            <?php foreach ($articles as $a): ?>
            <a href="knowledge.php?id=<?= $a['id'] ?>" style="text-decoration:none;" class="kb-card difficulty-<?= $a['difficulty'] ?>">
                <div class="kb-meta">
                    <span class="kb-category"><?= clean($a['category']) ?></span>
                    <span style="font-size:0.8rem;color:var(--gray);"><?= $diffMn[$a['difficulty']] ?></span>
                </div>
                <h3><?= clean($a['title']) ?></h3>
                <p style="color:var(--gray);font-size:0.9rem;margin-top:8px;line-height:1.5;"><?= mb_substr(clean($a['problem_description']), 0, 100) ?>...</p>
                <div style="margin-top:12px;display:flex;justify-content:space-between;align-items:center;">
                    <span style="color:var(--primary);font-size:0.85rem;font-weight:600;">Шийдлийг харах →</span>
                    <span style="color:var(--gray);font-size:0.8rem;"><i class="fas fa-eye"></i> <?= $a['views'] ?></span>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
