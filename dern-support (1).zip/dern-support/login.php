<?php
$pageTitle = 'Нэвтрэх';
require_once 'includes/config.php';

if (isset($_SESSION['user_id'])) { header('Location: ' . SITE_URL . '/dashboard.php'); exit; }

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = getDB();
    $email = clean($_POST['email'] ?? '');
    $pass = $_POST['password'] ?? '';

    if (!$email || !$pass) {
        $error = 'И-мэйл болон нууц үгээ оруулна уу.';
    } else {
        $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if ($user && password_verify($pass, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['account_type'] = $user['account_type'];
            header('Location: ' . SITE_URL . '/dashboard.php');
            exit;
        } else {
            $error = 'И-мэйл эсвэл нууц үг буруу байна.';
        }
    }
}

require_once 'includes/header.php';
?>

<div class="form-container">
    <h2><i class="fas fa-sign-in-alt" style="color:var(--primary)"></i> Нэвтрэх</h2>
    <?php if ($error): ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= $error ?></div><?php endif; ?>

    <form method="POST" id="mainForm">
        <div class="form-group">
            <label>И-мэйл хаяг *</label>
            <input type="email" name="email" placeholder="example@email.com" required value="<?= clean($_POST['email'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Нууц үг *</label>
            <input type="password" name="password" placeholder="Нууц үгээ оруулна уу" required>
        </div>
        <button type="submit" class="btn btn-primary btn-full"><i class="fas fa-sign-in-alt"></i> Нэвтрэх</button>
    </form>

    <div class="form-link" style="margin-top:12px;">
        <p style="color:var(--gray);font-size:0.85rem;margin-top:10px;padding:10px;background:var(--light);border-radius:8px;">
            <strong>Туршилтын аккаунт:</strong><br>
            И-мэйл: admin@dern.mn<br>
            Нууц үг: admin123
        </p>
    </div>
    <div class="form-link">Бүртгэлгүй юу? <a href="register.php">Бүртгүүлэх</a></div>
</div>

<?php require_once 'includes/footer.php'; ?>
