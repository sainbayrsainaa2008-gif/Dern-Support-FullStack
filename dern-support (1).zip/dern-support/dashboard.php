<?php
$pageTitle = 'Хяналтын самбар';
require_once 'includes/config.php';
requireLogin();
$db = getDB();
$uid = $_SESSION['user_id'];

// Хэрэглэгчийн статистик
$r = $db->prepare("SELECT COUNT(*) as c FROM support_requests WHERE user_id=?"); $r->bind_param('i',$uid); $r->execute();
$total = $r->get_result()->fetch_assoc()['c'];

$r = $db->prepare("SELECT COUNT(*) as c FROM support_requests WHERE user_id=? AND status='completed'"); $r->bind_param('i',$uid); $r->execute();
$done = $r->get_result()->fetch_assoc()['c'];

$r = $db->prepare("SELECT COUNT(*) as c FROM support_requests WHERE user_id=? AND status='pending'"); $r->bind_param('i',$uid); $r->execute();
$pending = $r->get_result()->fetch_assoc()['c'];

// Сүүлийн хүсэлтүүд
$r = $db->prepare("SELECT * FROM support_requests WHERE user_id=? ORDER BY created_at DESC LIMIT 5"); $r->bind_param('i',$uid); $r->execute();
$requests = $r->get_result()->fetch_all(MYSQLI_ASSOC);

$statusMn = ['pending'=>'Хүлээгдэж буй','scheduled'=>'Товлосон','in_progress'=>'Хийгдэж байна','completed'=>'Дууссан','cancelled'=>'Цуцлагдсан'];
$priorityMn = ['low'=>'Бага','medium'=>'Дунд','high'=>'Өндөр','urgent'=>'Яаралтай'];

require_once 'includes/header.php';
?>

<div class="page-header">
    <div class="page-header-inner">
        <h1><i class="fas fa-tachometer-alt"></i> Сайн байна уу, <?= clean($_SESSION['user_name']) ?>!</h1>
        <a href="new_request.php" class="btn btn-primary"><i class="fas fa-plus"></i> Шинэ хүсэлт</a>
    </div>
</div>

<div class="section">
    <div class="container">
        <!-- Статистик -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon icon-blue"><i class="fas fa-ticket-alt"></i></div>
                <div class="stat-info"><h3><?= $total ?></h3><p>Нийт хүсэлт</p></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon icon-yellow"><i class="fas fa-hourglass-half"></i></div>
                <div class="stat-info"><h3><?= $pending ?></h3><p>Хүлээгдэж буй</p></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon icon-green"><i class="fas fa-check-circle"></i></div>
                <div class="stat-info"><h3><?= $done ?></h3><p>Дууссан</p></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background:#f3e8ff;color:#7c3aed;"><i class="fas fa-user"></i></div>
                <div class="stat-info">
                    <h3 style="font-size:1rem;"><?= $_SESSION['account_type'] === 'business' ? 'Бизнес' : 'Хувь хүн' ?></h3>
                    <p>Аккаунтын төрөл</p>
                </div>
            </div>
        </div>

        <!-- Сүүлийн хүсэлтүүд -->
        <div class="table-container">
            <div class="table-header">
                <h3>Сүүлийн хүсэлтүүд</h3>
                <a href="requests.php" class="btn btn-primary btn-sm"><i class="fas fa-list"></i> Бүгдийг харах</a>
            </div>
            <?php if (empty($requests)): ?>
                <div style="padding:40px;text-align:center;color:var(--gray);">
                    <i class="fas fa-inbox" style="font-size:3rem;margin-bottom:12px;display:block;opacity:.3;"></i>
                    <p>Одоогоор хүсэлт байхгүй байна.</p>
                    <a href="new_request.php" class="btn btn-primary" style="margin-top:16px;"><i class="fas fa-plus"></i> Шинэ хүсэлт үүсгэх</a>
                </div>
            <?php else: ?>
                <table>
                    <thead>
                        <tr><th>Гарчиг</th><th>Тэргүүлэх</th><th>Төлөв</th><th>Огноо</th><th>Үйлдэл</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($requests as $req): ?>
                        <tr>
                            <td><?= clean($req['title']) ?></td>
                            <td><span class="badge badge-<?= $req['priority'] ?>"><?= $priorityMn[$req['priority']] ?></span></td>
                            <td><span class="badge badge-<?= $req['status'] ?>"><?= $statusMn[$req['status']] ?></span></td>
                            <td><?= date('Y-м-d', strtotime($req['created_at'])) ?></td>
                            <td><a href="view_request.php?id=<?= $req['id'] ?>" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i></a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Хурдан холбоос -->
        <div class="cards-grid" style="margin-top:28px;">
            <a href="new_request.php" class="card" style="text-decoration:none;cursor:pointer;">
                <div class="card-icon icon-blue"><i class="fas fa-plus-circle"></i></div>
                <h3>Засварын хүсэлт</h3>
                <p>Компьютерийн засварын хүсэлт гаргах, цаг товлох</p>
            </a>
            <a href="knowledge.php" class="card" style="text-decoration:none;cursor:pointer;">
                <div class="card-icon icon-green"><i class="fas fa-book"></i></div>
                <h3>Мэдлэгийн сан</h3>
                <p>Нийтлэг асуудлуудын шийдлийг хайх</p>
            </a>
            <a href="parts.php" class="card" style="text-decoration:none;cursor:pointer;">
                <div class="card-icon icon-yellow"><i class="fas fa-cogs"></i></div>
                <h3>Нөөц эд анги</h3>
                <p>Нөөцийн эд ангиудын жагсаалт харах</p>
            </a>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
