<?php
require_once __DIR__ . '/config.php';
?>
<!DOCTYPE html>
<html lang="mn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? clean($pageTitle) . ' | ' : '' ?>Dern-Support</title>
    <link rel="stylesheet" href="<?= SITE_URL ?>/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
    /* Font Awesome буусан тохиолдолд fallback icon */
    .fas, .fa { font-family: Arial, sans-serif !important; }
    </style>
</head>
<body>
<nav class="navbar">
    <div class="nav-container">
        <a href="<?= SITE_URL ?>" class="nav-logo">
            <i class="fas fa-tools"></i> Dern-Support
        </a>
        <div class="nav-links">
            <a href="<?= SITE_URL ?>"><i class="fas fa-home"></i> Нүүр</a>
            <a href="<?= SITE_URL ?>/knowledge.php"><i class="fas fa-book"></i> Мэдлэгийн сан</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="<?= SITE_URL ?>/requests.php"><i class="fas fa-ticket-alt"></i> Хүсэлтүүд</a>
                <a href="<?= SITE_URL ?>/dashboard.php"><i class="fas fa-tachometer-alt"></i> Хяналтын самбар</a>
                <a href="<?= SITE_URL ?>/logout.php" class="btn-nav-logout"><i class="fas fa-sign-out-alt"></i> Гарах</a>
            <?php else: ?>
                <a href="<?= SITE_URL ?>/login.php" class="btn-nav-login"><i class="fas fa-sign-in-alt"></i> Нэвтрэх</a>
                <a href="<?= SITE_URL ?>/register.php" class="btn-nav-register"><i class="fas fa-user-plus"></i> Бүртгүүлэх</a>
            <?php endif; ?>
        </div>
    </div>
</nav>
<main class="main-content">
