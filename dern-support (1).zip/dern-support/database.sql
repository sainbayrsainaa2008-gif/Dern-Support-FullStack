-- Dern-Support вэбсайтын өгөгдлийн сан
-- XAMPP дээр phpMyAdmin-аар ажиллуулна

CREATE DATABASE IF NOT EXISTS dern_support CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dern_support;

-- Хэрэглэгчийн хүснэгт (бизнес болон хувь хүн)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    account_type ENUM('business', 'individual') NOT NULL,
    company_name VARCHAR(100),
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Засварын хүсэлтийн хүснэгт
CREATE TABLE IF NOT EXISTS support_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    device_type VARCHAR(50),
    status ENUM('pending', 'scheduled', 'in_progress', 'completed', 'cancelled') DEFAULT 'pending',
    priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
    estimated_cost DECIMAL(10,2),
    scheduled_date DATE,
    scheduled_time TIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Мэдлэгийн сан
CREATE TABLE IF NOT EXISTS knowledge_base (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(50) NOT NULL,
    title VARCHAR(150) NOT NULL,
    problem_description TEXT NOT NULL,
    solution TEXT NOT NULL,
    difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'medium',
    views INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Нөөц эд ангиудын хүснэгт
CREATE TABLE IF NOT EXISTS spare_parts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    part_number VARCHAR(50),
    category VARCHAR(50),
    quantity INT DEFAULT 0,
    unit_price DECIMAL(10,2),
    supplier VARCHAR(100),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Мэдлэгийн санд жишээ өгөгдөл оруулах
INSERT INTO knowledge_base (category, title, problem_description, solution, difficulty) VALUES
('Тоног төхөөрөмж', 'Компьютер асахгүй байна', 'Компьютер товч дарахад ямар ч хариу өгөхгүй, дэлгэц хар байна', 'Цахилгааны кабель шалгаж, батарей (зөөврийн бол) авч дахин тавина. Цахилгаан хангамжийн нэгж эвдэрсэн байж болно.', 'easy'),
('Программ хангамж', 'Windows удаан ажиллаж байна', 'Компьютер маш удаан ажиллаж, програмууд удаан нээгддэг', 'Disk Cleanup ажиллуулж, startup программуудыг цэгцлэх, вирус шалгах, RAM шалгах.', 'medium'),
('Сүлжээ', 'Интернэт холбогдохгүй байна', 'WiFi харагдахгүй эсвэл холбогдсон боловч интернэт ажиллахгүй', 'Router дахин эхлүүлэх, IP тохиргоо шалгах, сүлжээний драйвер шинэчлэх.', 'medium'),
('Тоног төхөөрөмж', 'Laptop дулаарч байна', 'Зөөврийн компьютер хэт дулаарч, автоматаар унтардаг', 'Агааржуулагч цэвэрлэх, дулаан дамжуулах пастаа солих, хөргөгч дэр ашиглах.', 'medium'),
('Программ хангамж', 'Вирус эсвэл malware илэрсэн', 'Компьютер ер бусын ажиллаж, санамсаргүй popup гарч ирдэг', 'Antivirus программаар бүрэн шалгалт хийх, Windows Defender ашиглах, сэжигтэй програм устгах.', 'hard');

-- Нөөц эд ангид жишээ өгөгдөл
INSERT INTO spare_parts (name, part_number, category, quantity, unit_price, supplier) VALUES
('RAM DDR4 8GB', 'RAM-DD4-8G', 'Санах ой', 15, 35000, 'TechParts MN'),
('SSD 256GB', 'SSD-256-SAT', 'Хатуу диск', 8, 75000, 'StorageWorld'),
('Laptop батарей (Universal)', 'BAT-UNI-LT', 'Цахилгаан', 12, 45000, 'PowerParts'),
('HDMI кабель 1.5м', 'CAB-HDMI-15', 'Кабель', 30, 8000, 'TechParts MN'),
('Дулаан пастаа', 'PST-THRM-5G', 'Хөргөлт', 25, 5000, 'CoolTech');

-- Жишээ хэрэглэгч (нууц үг: admin123)
INSERT INTO users (account_type, first_name, last_name, email, phone, password) VALUES
('business', 'Бат', 'Болд', 'admin@dern.mn', '99001234', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');
