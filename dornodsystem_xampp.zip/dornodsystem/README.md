# Дорнод аймгийн Цахим Шилжилт — XAMPP Суулгах Заавар

## 📁 Файлын бүтэц

```
dornodsystem/
├── index.php              ← Гол вебсайт (энд нэвтрэнэ)
├── database.sql           ← MySQL мэдээллийн сан үүсгэх
├── includes/
│   └── db.php             ← Мэдээллийн сантай холболт
└── api/
    ├── submit_application.php  ← Өргөдөл илгээх
    ├── check_status.php        ← Статус шалгах
    ├── login.php               ← Нэвтрэх
    ├── logout.php              ← Гарах
    ├── get_data.php            ← Мэдээлэл авах
    └── contact.php             ← Холбоо барих
```

---

## ⚙️ XAMPP дээр суулгах алхмууд

### 1. Файлуудыг хуулах
Энэ `dornodsystem` хавтасыг дараах замд хуулна уу:
```
C:\xampp\htdocs\dornodsystem\
```

### 2. XAMPP эхлүүлэх
- XAMPP Control Panel нээнэ
- **Apache** → Start
- **MySQL** → Start

### 3. Мэдээллийн сан үүсгэх
Браузераар нэвтрэнэ: [http://localhost/phpmyadmin](http://localhost/phpmyadmin)

- Дээд цэсний **"Import"** таб дарна
- **"Choose File"** → `database.sql` файлыг сонгоно
- **"Go"** товч дарна
- ✅ `dornodsystem` мэдээллийн сан автоматаар үүснэ

### 4. Вебсайт нээх
Браузерт дараах хаягийг бичнэ:
```
http://localhost/dornodsystem/
```

---

## 🔧 Тохиргоо

### Мэдээллийн сангийн нууц үг байвал:
`includes/db.php` файлд засна:
```php
define('DB_PASS', 'таны_нууц_үг');
```

---

## 🗄️ Мэдээллийн сангийн хүснэгтүүд

| Хүснэгт | Тайлбар |
|---------|---------|
| `users` | Иргэн болон ажилтны бүртгэл |
| `services` | Үйлчилгээний жагсаалт |
| `applications` | Иргэдийн өргөдлүүд |
| `news` | Мэдээ, зарлал |
| `contact_messages` | Холбоо барих мэдэгдлүүд |
| `stats` | Статистик тоо |

---

## 🌐 API Endpoint-үүд

| Endpoint | Method | Тайлбар |
|----------|--------|---------|
| `api/submit_application.php` | POST | Өргөдөл илгээх |
| `api/check_status.php?q=...` | GET | Статус шалгах |
| `api/login.php` | POST | Нэвтрэх |
| `api/logout.php` | GET | Гарах |
| `api/get_data.php?type=services` | GET | Үйлчилгээнүүд |
| `api/get_data.php?type=news` | GET | Мэдээнүүд |
| `api/get_data.php?type=stats` | GET | Статистик |
| `api/contact.php` | POST | Холбоо барих |

---

## 👤 Admin нэвтрэх

phpMyAdmin: [http://localhost/phpmyadmin](http://localhost/phpmyadmin)
- Хэрэглэгч: `root`
- Нууц үг: (хоосон)

---

## 📝 Тэмдэглэл

- Иргэд **регистр + утасны дугаараар** нэвтэрнэ (нууц үг шаарддаггүй)
- Шинэ иргэн анх нэвтрэхэд автоматаар бүртгэгдэнэ
- Өргөдөл бүрт **APP-ЖЖЖЖ-НННNN** дугаар олгогдоно
- phpMyAdmin-аар бүх мэдээллийг харах боломжтой
