<?php session_start(); ?>
<!DOCTYPE html>
<html lang="mn">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Дорнод аймгийн Цахим шилжилт, үйлчилгээний хэлтэс</title>
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700&family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --blue-dark: #0a1628;
      --blue-mid: #0d2b5e;
      --blue-accent: #1565c0;
      --blue-light: #1976d2;
      --orange: #ff6d00;
      --orange-light: #ff9100;
      --gold: #ffd600;
      --white: #ffffff;
      --gray-light: #f0f4f8;
      --gray: #90a4ae;
      --text: #1a237e;
      --card-shadow: 0 4px 24px rgba(21,101,192,0.13);
      --green: #43a047;
    }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Noto Sans', 'Roboto', sans-serif;
      background: var(--gray-light);
      color: var(--blue-dark);
      min-height: 100vh;
    }

    /* HEADER */
    header {
      background: linear-gradient(135deg, var(--blue-dark) 60%, var(--blue-mid) 100%);
      padding: 0;
      position: sticky;
      top: 0;
      z-index: 100;
      box-shadow: 0 2px 16px rgba(0,0,0,0.3);
    }
    .header-top {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 40px;
      border-bottom: 1px solid rgba(255,255,255,0.08);
    }
    .logo-area {
      display: flex;
      align-items: center;
      gap: 16px;
      cursor: pointer;
    }
    .logo-globe {
      width: 54px; height: 54px;
      background: radial-gradient(circle at 35% 35%, #1e88e5, #0a1628);
      border-radius: 50%;
      border: 2px solid var(--orange);
      display: flex; align-items: center; justify-content: center;
      font-size: 28px;
      box-shadow: 0 0 18px rgba(255,109,0,0.4);
    }
    .logo-text h1 { color: var(--white); font-size: 15px; font-weight: 700; letter-spacing: 0.5px; line-height: 1.2; }
    .logo-text span { color: var(--orange-light); font-size: 11px; font-weight: 400; }
    .header-right { display: flex; align-items: center; gap: 14px; }
    .header-right a { color: var(--gray); font-size: 13px; text-decoration: none; transition: color 0.2s; cursor: pointer; }
    .header-right a:hover { color: var(--orange-light); }
    .btn-login {
      background: var(--orange); color: white !important;
      padding: 7px 20px; border-radius: 20px;
      font-weight: 600; font-size: 13px !important;
      transition: background 0.2s !important;
    }
    .btn-login:hover { background: var(--orange-light) !important; }

    nav {
      display: flex; align-items: center;
      padding: 0 40px; gap: 4px;
      overflow-x: auto;
    }
    nav a {
      color: rgba(255,255,255,0.75);
      text-decoration: none; font-size: 13px;
      padding: 12px 16px;
      border-bottom: 3px solid transparent;
      transition: all 0.2s; white-space: nowrap; cursor: pointer;
    }
    nav a:hover, nav a.active { color: var(--white); border-bottom-color: var(--orange); }

    /* PAGES */
    .page { display: none; }
    .page.active { display: block; }

    /* HERO */
    .hero {
      background: linear-gradient(120deg, var(--blue-dark) 0%, var(--blue-mid) 50%, var(--blue-accent) 100%);
      padding: 60px 40px 50px;
      text-align: center;
      position: relative; overflow: hidden;
    }
    .hero::before {
      content: '';
      position: absolute; top: -80px; right: -80px;
      width: 320px; height: 320px;
      background: radial-gradient(circle, rgba(255,145,0,0.18) 0%, transparent 70%);
      border-radius: 50%;
    }
    .hero-badge {
      display: inline-block;
      background: rgba(255,109,0,0.15);
      border: 1px solid var(--orange);
      color: var(--orange-light);
      font-size: 12px; padding: 4px 16px;
      border-radius: 20px; margin-bottom: 18px; letter-spacing: 1px;
    }
    .hero h2 { color: var(--white); font-size: 32px; font-weight: 700; line-height: 1.3; margin-bottom: 14px; }
    .hero p { color: var(--gray); font-size: 15px; max-width: 540px; margin: 0 auto 28px; line-height: 1.7; }
    .hero-search {
      display: flex; max-width: 520px; margin: 0 auto;
      border-radius: 32px; overflow: hidden;
      box-shadow: 0 4px 24px rgba(0,0,0,0.25);
    }
    .hero-search input { flex: 1; padding: 14px 22px; border: none; outline: none; font-size: 14px; background: rgba(255,255,255,0.97); font-family: inherit; }
    .hero-search button {
      background: var(--orange); color: white; border: none;
      padding: 14px 28px; font-size: 14px; font-weight: 600;
      cursor: pointer; transition: background 0.2s; font-family: inherit;
    }
    .hero-search button:hover { background: var(--orange-light); }

    /* STATS BAR */
    .stats-bar {
      background: var(--white);
      display: flex; justify-content: center; gap: 0;
      box-shadow: 0 2px 10px rgba(21,101,192,0.08);
    }
    .stat-item { flex: 1; max-width: 200px; text-align: center; padding: 18px 10px; border-right: 1px solid #e3eaf3; }
    .stat-item:last-child { border-right: none; }
    .stat-num { color: var(--blue-accent); font-size: 22px; font-weight: 700; }
    .stat-label { color: var(--gray); font-size: 11px; margin-top: 2px; }

    /* SECTION */
    .section { padding: 40px 40px 20px; }
    .section-title { font-size: 20px; font-weight: 700; color: var(--blue-dark); margin-bottom: 6px; }
    .section-sub { color: var(--gray); font-size: 13px; margin-bottom: 24px; }

    /* CATEGORIES */
    .categories-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 16px; }
    .cat-card {
      background: var(--white); border-radius: 14px; padding: 22px 14px;
      text-align: center; cursor: pointer; transition: all 0.2s;
      box-shadow: var(--card-shadow); border: 1.5px solid transparent;
      text-decoration: none; display: block;
    }
    .cat-card:hover { border-color: var(--blue-light); transform: translateY(-3px); box-shadow: 0 8px 28px rgba(21,101,192,0.18); }
    .cat-icon { font-size: 32px; margin-bottom: 10px; display: block; }
    .cat-name { color: var(--blue-dark); font-size: 12px; font-weight: 600; line-height: 1.4; }
    .cat-count { color: var(--gray); font-size: 11px; margin-top: 4px; }

    /* SERVICES */
    .services-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; }
    .service-card {
      background: var(--white); border-radius: 14px; padding: 22px;
      box-shadow: var(--card-shadow); cursor: pointer; transition: all 0.2s;
      border-left: 4px solid var(--blue-light); text-decoration: none; display: block;
    }
    .service-card:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(21,101,192,0.18); }
    .service-card.orange { border-left-color: var(--orange); }
    .service-card.green { border-left-color: #43a047; }
    .service-card.purple { border-left-color: #7b1fa2; }
    .service-card.red { border-left-color: #e53935; }
    .service-card.teal { border-left-color: #00897b; }
    .service-header { display: flex; align-items: flex-start; gap: 14px; margin-bottom: 10px; }
    .service-icon { font-size: 26px; flex-shrink: 0; }
    .service-title { color: var(--blue-dark); font-size: 14px; font-weight: 700; line-height: 1.4; }
    .service-desc { color: var(--gray); font-size: 12px; line-height: 1.6; margin-bottom: 12px; }
    .service-meta { display: flex; gap: 14px; margin-bottom: 10px; }
    .service-badge {
      font-size: 10px; padding: 3px 10px; border-radius: 20px; font-weight: 600;
    }
    .badge-free { background: #e8f5e9; color: #2e7d32; }
    .badge-paid { background: #fff3e0; color: #e65100; }
    .badge-days { background: #e3f2fd; color: #1565c0; }
    .service-footer { display: flex; align-items: center; justify-content: space-between; }
    .service-dept { font-size: 11px; color: var(--blue-light); font-weight: 500; }
    .service-btn {
      background: var(--blue-accent); color: white;
      padding: 5px 14px; border-radius: 20px; font-size: 11px;
      font-weight: 600; border: none; cursor: pointer; transition: background 0.2s; font-family: inherit;
    }
    .service-btn:hover { background: var(--blue-dark); }

    /* NEWS */
    .news-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 16px; }
    .news-card {
      background: var(--white); border-radius: 14px; overflow: hidden;
      box-shadow: var(--card-shadow); cursor: pointer; transition: all 0.2s;
    }
    .news-card:hover { transform: translateY(-3px); }
    .news-img {
      background: linear-gradient(135deg, var(--blue-mid), var(--blue-accent));
      height: 100px; display: flex; align-items: center; justify-content: center; font-size: 40px;
    }
    .news-body { padding: 16px; }
    .news-tag {
      display: inline-block; background: rgba(21,101,192,0.1);
      color: var(--blue-accent); font-size: 10px; padding: 3px 10px;
      border-radius: 20px; font-weight: 600; margin-bottom: 8px;
    }
    .news-tag.orange-tag { background: rgba(255,109,0,0.1); color: var(--orange); }
    .news-tag.green-tag { background: rgba(67,160,71,0.1); color: #43a047; }
    .news-title { color: var(--blue-dark); font-size: 13px; font-weight: 700; line-height: 1.5; margin-bottom: 6px; }
    .news-date { color: var(--gray); font-size: 11px; }

    /* QUICK ACCESS */
    .quick-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 12px; }
    .quick-card {
      background: var(--white); border-radius: 12px; padding: 16px;
      text-align: center; box-shadow: var(--card-shadow); cursor: pointer;
      transition: all 0.2s; border: 1.5px solid transparent; text-decoration: none; display: block;
    }
    .quick-card:hover { border-color: var(--orange); transform: translateY(-2px); }
    .quick-icon { font-size: 24px; margin-bottom: 8px; }
    .quick-title { color: var(--blue-dark); font-size: 12px; font-weight: 600; }

    /* PAGE HERO */
    .page-hero {
      background: linear-gradient(120deg, var(--blue-dark) 0%, var(--blue-mid) 60%, var(--blue-accent) 100%);
      padding: 40px 40px 35px; color: white;
    }
    .page-hero h2 { font-size: 24px; font-weight: 700; margin-bottom: 8px; }
    .page-hero p { color: rgba(255,255,255,0.65); font-size: 14px; }
    .breadcrumb { font-size: 12px; color: rgba(255,255,255,0.5); margin-bottom: 12px; }
    .breadcrumb span { color: var(--orange-light); }

    /* FILTER BAR */
    .filter-bar {
      background: var(--white); padding: 16px 40px;
      display: flex; gap: 10px; flex-wrap: wrap;
      box-shadow: 0 2px 8px rgba(21,101,192,0.07); align-items: center;
    }
    .filter-btn {
      padding: 7px 16px; border-radius: 20px; border: 1.5px solid #d0dce8;
      font-size: 12px; cursor: pointer; background: white;
      font-weight: 500; transition: all 0.2s; color: var(--blue-dark); font-family: inherit;
    }
    .filter-btn.active, .filter-btn:hover { background: var(--blue-accent); color: white; border-color: var(--blue-accent); }
    .filter-search {
      margin-left: auto; display: flex; gap: 8px;
    }
    .filter-search input {
      padding: 7px 14px; border: 1.5px solid #d0dce8; border-radius: 20px;
      font-size: 12px; outline: none; font-family: inherit;
    }
    .filter-search input:focus { border-color: var(--blue-light); }

    /* CONTACT PAGE */
    .contact-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
    .contact-card {
      background: var(--white); border-radius: 14px; padding: 28px;
      box-shadow: var(--card-shadow);
    }
    .contact-card h3 { font-size: 16px; font-weight: 700; color: var(--blue-dark); margin-bottom: 20px; display: flex; align-items: center; gap: 8px; }
    .dept-list { display: flex; flex-direction: column; gap: 14px; }
    .dept-item {
      display: flex; align-items: flex-start; gap: 14px;
      padding: 14px; border-radius: 10px; background: var(--gray-light);
      transition: background 0.2s; cursor: pointer;
    }
    .dept-item:hover { background: #e3eaf3; }
    .dept-icon { font-size: 28px; flex-shrink: 0; }
    .dept-name { font-size: 13px; font-weight: 700; color: var(--blue-dark); margin-bottom: 4px; }
    .dept-info { font-size: 12px; color: var(--gray); line-height: 1.6; }
    .dept-info span { display: block; }

    .contact-form-card {
      background: var(--white); border-radius: 14px; padding: 28px;
      box-shadow: var(--card-shadow);
    }
    .contact-form-card h3 { font-size: 16px; font-weight: 700; color: var(--blue-dark); margin-bottom: 20px; }

    /* MAP PLACEHOLDER */
    .map-placeholder {
      background: linear-gradient(135deg, #1565c0 0%, #0a1628 100%);
      border-radius: 14px; height: 200px;
      display: flex; align-items: center; justify-content: center;
      color: white; font-size: 14px; flex-direction: column; gap: 8px;
      margin-bottom: 16px;
    }
    .map-placeholder .map-icon { font-size: 40px; }

    /* HELP PAGE */
    .faq-list { display: flex; flex-direction: column; gap: 10px; }
    .faq-item {
      background: var(--white); border-radius: 12px;
      box-shadow: var(--card-shadow); overflow: hidden;
    }
    .faq-q {
      padding: 16px 20px; cursor: pointer; display: flex;
      justify-content: space-between; align-items: center;
      font-size: 14px; font-weight: 600; color: var(--blue-dark);
      transition: background 0.2s;
    }
    .faq-q:hover { background: #f0f4f8; }
    .faq-a {
      padding: 0 20px; max-height: 0; overflow: hidden;
      transition: max-height 0.3s ease, padding 0.3s;
      font-size: 13px; color: var(--gray); line-height: 1.7;
    }
    .faq-a.open { max-height: 200px; padding: 12px 20px 16px; }
    .faq-toggle { font-size: 18px; transition: transform 0.2s; }
    .faq-toggle.open { transform: rotate(45deg); }

    .help-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px; margin-bottom: 32px; }
    .help-card {
      background: var(--white); border-radius: 14px; padding: 24px;
      box-shadow: var(--card-shadow); text-align: center; cursor: pointer;
      transition: all 0.2s;
    }
    .help-card:hover { transform: translateY(-3px); box-shadow: 0 8px 28px rgba(21,101,192,0.18); }
    .help-card .hc-icon { font-size: 36px; margin-bottom: 12px; }
    .help-card .hc-title { font-size: 14px; font-weight: 700; color: var(--blue-dark); margin-bottom: 6px; }
    .help-card .hc-desc { font-size: 12px; color: var(--gray); line-height: 1.5; }

    /* REPORT / DASHBOARD PAGE */
    .dashboard-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 16px; margin-bottom: 28px; }
    .dash-card {
      background: var(--white); border-radius: 14px; padding: 22px;
      box-shadow: var(--card-shadow); border-top: 4px solid var(--blue-accent);
    }
    .dash-card.orange { border-top-color: var(--orange); }
    .dash-card.green { border-top-color: var(--green); }
    .dash-card.purple { border-top-color: #7b1fa2; }
    .dash-num { font-size: 28px; font-weight: 700; color: var(--blue-dark); }
    .dash-label { font-size: 12px; color: var(--gray); margin-top: 4px; }
    .dash-change { font-size: 11px; color: var(--green); margin-top: 6px; font-weight: 600; }

    .chart-card { background: var(--white); border-radius: 14px; padding: 24px; box-shadow: var(--card-shadow); margin-bottom: 16px; }
    .chart-title { font-size: 15px; font-weight: 700; color: var(--blue-dark); margin-bottom: 20px; }

    .bar-chart { display: flex; align-items: flex-end; gap: 12px; height: 160px; }
    .bar-col { display: flex; flex-direction: column; align-items: center; flex: 1; gap: 6px; }
    .bar { width: 100%; border-radius: 6px 6px 0 0; background: var(--blue-accent); transition: all 0.3s; cursor: pointer; position: relative; }
    .bar:hover { background: var(--orange); }
    .bar-label { font-size: 10px; color: var(--gray); text-align: center; }
    .bar-val { font-size: 10px; font-weight: 700; color: var(--blue-dark); }

    .table-card { background: var(--white); border-radius: 14px; padding: 24px; box-shadow: var(--card-shadow); overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; }
    th {
      background: var(--gray-light); color: var(--blue-dark);
      font-size: 12px; font-weight: 700; padding: 10px 14px;
      text-align: left; white-space: nowrap;
    }
    td { padding: 10px 14px; font-size: 12px; color: var(--blue-dark); border-bottom: 1px solid #e3eaf3; }
    tr:last-child td { border-bottom: none; }
    tr:hover td { background: #f7faff; }
    .status-badge {
      display: inline-block; padding: 3px 10px; border-radius: 20px;
      font-size: 10px; font-weight: 600;
    }
    .s-irsen { background: #fff3e0; color: #e65100; }
    .s-havalj { background: #e3f2fd; color: #1565c0; }
    .s-batalgaa { background: #e8f5e9; color: #2e7d32; }
    .s-duussen { background: #f3e5f5; color: #6a1b9a; }

    /* ACCOUNT / DANS PAGE */
    .account-hero {
      background: linear-gradient(120deg, var(--blue-dark), var(--blue-accent));
      padding: 40px; display: flex; align-items: center; gap: 24px; color: white;
    }
    .account-avatar {
      width: 80px; height: 80px; border-radius: 50%;
      background: linear-gradient(135deg, var(--orange), var(--blue-light));
      display: flex; align-items: center; justify-content: center;
      font-size: 36px; border: 3px solid rgba(255,255,255,0.3);
    }
    .account-name { font-size: 20px; font-weight: 700; margin-bottom: 4px; }
    .account-reg { font-size: 13px; color: rgba(255,255,255,0.65); }
    .account-tabs { display: flex; gap: 0; background: var(--white); border-bottom: 2px solid #e3eaf3; }
    .acc-tab {
      padding: 14px 24px; font-size: 13px; font-weight: 600;
      cursor: pointer; border-bottom: 3px solid transparent; margin-bottom: -2px;
      color: var(--gray); transition: all 0.2s;
    }
    .acc-tab.active, .acc-tab:hover { color: var(--blue-accent); border-bottom-color: var(--blue-accent); }
    .acc-panel { display: none; padding: 28px 40px; }
    .acc-panel.active { display: block; }

    .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px; }
    .info-item { background: var(--gray-light); border-radius: 10px; padding: 14px 16px; }
    .info-label { font-size: 11px; color: var(--gray); margin-bottom: 4px; font-weight: 600; letter-spacing: 0.5px; }
    .info-val { font-size: 14px; font-weight: 600; color: var(--blue-dark); }

    .timeline { display: flex; flex-direction: column; gap: 0; }
    .tl-item { display: flex; gap: 16px; position: relative; }
    .tl-left { display: flex; flex-direction: column; align-items: center; width: 32px; flex-shrink: 0; }
    .tl-dot {
      width: 32px; height: 32px; border-radius: 50%;
      background: var(--blue-accent); color: white;
      display: flex; align-items: center; justify-content: center;
      font-size: 14px; z-index: 1; flex-shrink: 0;
    }
    .tl-dot.orange { background: var(--orange); }
    .tl-dot.green { background: var(--green); }
    .tl-line { width: 2px; flex: 1; background: #e3eaf3; margin: 2px 0; min-height: 20px; }
    .tl-content {
      background: var(--white); border-radius: 12px; padding: 14px 18px;
      box-shadow: var(--card-shadow); margin-bottom: 12px; flex: 1;
    }
    .tl-title { font-size: 13px; font-weight: 700; color: var(--blue-dark); margin-bottom: 4px; }
    .tl-date { font-size: 11px; color: var(--gray); }

    /* LOGIN PANEL */
    .login-section {
      min-height: 60vh; display: flex; align-items: center; justify-content: center;
      padding: 40px;
    }
    .login-card {
      background: var(--white); border-radius: 20px; padding: 40px;
      max-width: 420px; width: 100%; box-shadow: 0 20px 60px rgba(21,101,192,0.15);
    }
    .login-card h3 { font-size: 22px; font-weight: 700; color: var(--blue-dark); margin-bottom: 6px; }
    .login-card p { color: var(--gray); font-size: 13px; margin-bottom: 28px; }
    .login-logo { text-align: center; margin-bottom: 24px; font-size: 48px; }
    .btn-primary {
      width: 100%; padding: 12px; background: var(--blue-accent); color: white;
      border: none; border-radius: 12px; font-size: 14px; font-weight: 700;
      cursor: pointer; transition: background 0.2s; font-family: inherit;
    }
    .btn-primary:hover { background: var(--blue-dark); }
    .btn-orange {
      width: 100%; padding: 12px; background: var(--orange); color: white;
      border: none; border-radius: 12px; font-size: 14px; font-weight: 700;
      cursor: pointer; transition: background 0.2s; margin-top: 10px; font-family: inherit;
    }
    .btn-orange:hover { background: var(--orange-light); }
    .login-divider { text-align: center; color: var(--gray); font-size: 12px; margin: 16px 0; position: relative; }
    .login-divider::before, .login-divider::after {
      content: ''; position: absolute; top: 50%; width: 40%; height: 1px; background: #e3eaf3;
    }
    .login-divider::before { left: 0; }
    .login-divider::after { right: 0; }

    /* FOOTER */
    footer { background: var(--blue-dark); color: rgba(255,255,255,0.7); padding: 40px; margin-top: 40px; }
    .footer-grid { display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 30px; margin-bottom: 30px; }
    .footer-logo { display: flex; align-items: center; gap: 12px; margin-bottom: 14px; }
    .footer-logo-globe {
      width: 40px; height: 40px;
      background: radial-gradient(circle at 35% 35%, #1e88e5, #0a1628);
      border-radius: 50%; border: 2px solid var(--orange);
      display: flex; align-items: center; justify-content: center; font-size: 20px;
    }
    .footer-logo-text { color: var(--white); font-size: 13px; font-weight: 700; }
    .footer-desc { font-size: 12px; line-height: 1.7; color: rgba(255,255,255,0.5); }
    .footer-col h4 { color: var(--white); font-size: 13px; margin-bottom: 14px; }
    .footer-col ul { list-style: none; }
    .footer-col ul li { margin-bottom: 8px; }
    .footer-col ul li a {
      color: rgba(255,255,255,0.55); text-decoration: none;
      font-size: 12px; transition: color 0.2s; cursor: pointer;
    }
    .footer-col ul li a:hover { color: var(--orange-light); }
    .footer-bottom {
      border-top: 1px solid rgba(255,255,255,0.08); padding-top: 20px;
      display: flex; justify-content: space-between; align-items: center; font-size: 11px;
    }
    .footer-contact { background: rgba(255,255,255,0.05); border-radius: 10px; padding: 12px 16px; margin-top: 14px; font-size: 12px; }
    .footer-contact p { margin-bottom: 4px; }

    /* MODAL */
    .modal-overlay {
      display: none; position: fixed; inset: 0;
      background: rgba(0,0,0,0.5); z-index: 1000;
      align-items: center; justify-content: center;
    }
    .modal-overlay.active { display: flex; }
    .modal {
      background: var(--white); border-radius: 20px; padding: 32px;
      max-width: 460px; width: 90%; box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      max-height: 90vh; overflow-y: auto;
    }
    .modal h3 { font-size: 18px; color: var(--blue-dark); margin-bottom: 6px; }
    .modal p { color: var(--gray); font-size: 13px; margin-bottom: 20px; }
    .form-group { margin-bottom: 16px; }
    .form-group label { display: block; font-size: 12px; font-weight: 600; color: var(--blue-dark); margin-bottom: 6px; }
    .form-group input, .form-group select, .form-group textarea {
      width: 100%; padding: 10px 14px; border: 1.5px solid #d0dce8;
      border-radius: 10px; font-size: 13px; outline: none;
      transition: border-color 0.2s; font-family: inherit;
    }
    .form-group input:focus, .form-group select:focus, .form-group textarea:focus { border-color: var(--blue-light); }
    .form-group textarea { resize: vertical; height: 80px; }
    .modal-btns { display: flex; gap: 10px; justify-content: flex-end; margin-top: 8px; }
    .btn-cancel {
      padding: 9px 22px; border-radius: 20px; border: 1.5px solid #d0dce8;
      background: white; font-size: 13px; cursor: pointer; color: var(--gray); font-family: inherit;
    }
    .btn-submit {
      padding: 9px 22px; border-radius: 20px; border: none;
      background: var(--blue-accent); color: white; font-size: 13px;
      font-weight: 600; cursor: pointer; transition: background 0.2s; font-family: inherit;
    }
    .btn-submit:hover { background: var(--blue-dark); }

    .toast {
      position: fixed; bottom: 30px; right: 30px;
      background: #43a047; color: white;
      padding: 14px 24px; border-radius: 12px;
      font-size: 14px; font-weight: 600;
      box-shadow: 0 4px 20px rgba(0,0,0,0.2);
      z-index: 2000; display: none;
      animation: slideIn 0.3s ease;
    }
    @keyframes slideIn {
      from { transform: translateX(100px); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }

    .section-divider { height: 1px; background: #e3eaf3; margin: 0 40px; }

    /* Progress bar */
    .progress-wrap { margin-bottom: 20px; }
    .progress-label { display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 12px; color: var(--blue-dark); font-weight: 600; }
    .progress-bar { height: 10px; background: #e3eaf3; border-radius: 10px; overflow: hidden; }
    .progress-fill { height: 100%; border-radius: 10px; background: var(--blue-accent); }
    .progress-fill.orange { background: var(--orange); }
    .progress-fill.green { background: var(--green); }

    @media (max-width: 768px) {
      .header-top { padding: 10px 16px; }
      .hero { padding: 40px 16px 30px; }
      .hero h2 { font-size: 22px; }
      .section { padding: 30px 16px 16px; }
      .footer-grid { grid-template-columns: 1fr; }
      footer { padding: 30px 16px; }
      .stats-bar { flex-wrap: wrap; }
      nav { padding: 0 16px; }
      .contact-grid { grid-template-columns: 1fr; }
      .info-grid { grid-template-columns: 1fr; }
      .filter-bar { padding: 12px 16px; }
      .page-hero { padding: 30px 16px; }
      .account-hero { padding: 24px 16px; }
      .acc-panel { padding: 20px 16px; }
      .login-section { padding: 20px; }
    }
  </style>
</head>
<body>

<!-- HEADER -->
<header>
  <div class="header-top">
    <div class="logo-area" onclick="showPage('home')">
      <div class="logo-globe">🌐</div>
      <div class="logo-text">
        <h1>Дорнод аймгийн Цахим шилжилт</h1>
        <span>Үйлчилгээний хэлтэс • Торийн цахим үйлчилгээ</span>
      </div>
    </div>
    <div class="header-right">
      <a onclick="setLang('mn')" id="lang-mn" style="color:var(--orange-light)">Монгол</a>
      <a onclick="setLang('en')" id="lang-en">English</a>
      <a class="btn-login" onclick="showPage('account')">🔐 Нэвтрэх</a>
    </div>
  </div>
  <nav>
    <a onclick="showPage('home')" id="nav-home" class="active">🏠 Нүүр</a>
    <a onclick="showPage('services')" id="nav-services">📋 Үйлчилгээнүүд</a>
    <a onclick="showPage('news')" id="nav-news">📰 Мэдэгдэл</a>
    <a onclick="showPage('report')" id="nav-report">📊 Тайлан</a>
    <a onclick="showPage('account')" id="nav-account">🗂️ Дансны мэдээлэл</a>
    <a onclick="showPage('contact')" id="nav-contact">📞 Холбоо барих</a>
    <a onclick="showPage('help')" id="nav-help">❓ Тусламж</a>
  </nav>
</header>

<!-- ============================================================ -->
<!-- PAGE: HOME -->
<!-- ============================================================ -->
<div class="page active" id="page-home">
  <section class="hero">
    <div class="hero-badge">🇲🇳 МОНГОЛ УЛСЫН ЕРӨНХИЙ САЙДЫН ИВЭЭЛ ДОР</div>
    <h2>Цахимд ч Найз байя<br>Үндэсний нөлөөллийн аян</h2>
    <p>Дорнод аймгийн бүх иргэдэд зориулсан цахим засгийн газрын үйлчилгээг нэг дороос авна уу</p>
    <div class="hero-search">
      <input type="text" id="homeSearch" placeholder="Үйлчилгээ хайх... (жишээ: иргэний үнэмлэх, газар, хүн амын бүртгэл)">
      <button onclick="doSearch()">🔍 Хайх</button>
    </div>
  </section>

  <div class="stats-bar">
    <div class="stat-item"><div class="stat-num">47+</div><div class="stat-label">Үйлчилгээний төрөл</div></div>
    <div class="stat-item"><div class="stat-num">2,000+</div><div class="stat-label">Бүртгэгдсэн иргэд</div></div>
    <div class="stat-item"><div class="stat-num">12</div><div class="stat-label">Хэлтэс, байгууллага</div></div>
    <div class="stat-item"><div class="stat-num">24/7</div><div class="stat-label">Онлайн үйлчилгээ</div></div>
    <div class="stat-item"><div class="stat-num">98%</div><div class="stat-label">Хэрэглэгчийн сэтгэл ханамж</div></div>
  </div>

  <section class="section">
    <div class="section-title">📂 Үйлчилгээний ангилал</div>
    <div class="section-sub">Хэрэгтэй үйлчилгээгээ ангиллаас сонгоно уу</div>
    <div class="categories-grid">
      <a class="cat-card" onclick="showServicesFiltered('irged')">
        <span class="cat-icon">👤</span><div class="cat-name">Иргэний бүртгэл</div><div class="cat-count">12 үйлчилгээ</div>
      </a>
      <a class="cat-card" onclick="showServicesFiltered('gazar')">
        <span class="cat-icon">🗺️</span><div class="cat-name">Газрын харилцаа</div><div class="cat-count">8 үйлчилгээ</div>
      </a>
      <a class="cat-card" onclick="showServicesFiltered('tatvar')">
        <span class="cat-icon">💰</span><div class="cat-name">Татвар & Санхүү</div><div class="cat-count">9 үйлчилгээ</div>
      </a>
      <a class="cat-card" onclick="showServicesFiltered('bolov')">
        <span class="cat-icon">🎓</span><div class="cat-name">Боловсрол</div><div class="cat-count">6 үйлчилгээ</div>
      </a>
      <a class="cat-card" onclick="showServicesFiltered('eruel')">
        <span class="cat-icon">🏥</span><div class="cat-name">Эрүүл мэнд</div><div class="cat-count">7 үйлчилгээ</div>
      </a>
      <a class="cat-card" onclick="showServicesFiltered('aaan')">
        <span class="cat-icon">🏢</span><div class="cat-name">Бизнес & ААН</div><div class="cat-count">10 үйлчилгээ</div>
      </a>
      <a class="cat-card" onclick="showServicesFiltered('halams')">
        <span class="cat-icon">🤝</span><div class="cat-name">Нийгмийн халамж</div><div class="cat-count">8 үйлчилгээ</div>
      </a>
      <a class="cat-card" onclick="showServicesFiltered('teever')">
        <span class="cat-icon">🚗</span><div class="cat-name">Тээвэр & ЗХА</div><div class="cat-count">5 үйлчилгээ</div>
      </a>
    </div>
  </section>

  <section class="section">
    <div class="section-title">⭐ Түгээмэл үйлчилгээнүүд</div>
    <div class="section-sub">Хамгийн их хэрэглэгддэг цахим үйлчилгээнүүд</div>
    <div class="services-grid">
      <a class="service-card" onclick="openModal('Иргэний үнэмлэх шинэчлэх', 'IU-001')">
        <div class="service-header"><span class="service-icon">🪪</span><div class="service-title">Иргэний үнэмлэх шинэчлэх</div></div>
        <div class="service-desc">Иргэний үнэмлэхийн хугацаа дуусмагц цахимаар шинэчлэх өргөдөл гаргах боломжтой.</div>
        <div class="service-meta"><span class="service-badge badge-paid">💵 5,000₮</span><span class="service-badge badge-days">⏱️ 5 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🏛️ ИТА</span><button class="service-btn" onclick="event.stopPropagation(); openModal('Иргэний үнэмлэх шинэчлэх','IU-001')">Өргөдөл →</button></div>
      </a>
      <a class="service-card orange" onclick="openModal('Газрын гэрчилгээ авах', 'GH-001')">
        <div class="service-header"><span class="service-icon">📜</span><div class="service-title">Газрын гэрчилгээ авах</div></div>
        <div class="service-desc">Газрын кадастрын мэдээлэл үзэх, гэрчилгээ авах, шилжүүлэх цахим үйлчилгээ.</div>
        <div class="service-meta"><span class="service-badge badge-paid">💵 10,000₮</span><span class="service-badge badge-days">⏱️ 10 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🗺️ Газрын харилцаа</span><button class="service-btn" onclick="event.stopPropagation(); openModal('Газрын гэрчилгээ авах','GH-001')">Өргөдөл →</button></div>
      </a>
      <a class="service-card green" onclick="openModal('Эмнэлэгт цаг авах', 'EM-001')">
        <div class="service-header"><span class="service-icon">🏥</span><div class="service-title">Эмнэлэгт цаг авах</div></div>
        <div class="service-desc">Дорнод аймгийн төрийн эмнэлгүүдэд онлайнаар цаг авч, дараалалгүй үйлчлүүлнэ.</div>
        <div class="service-meta"><span class="service-badge badge-free">✅ Үнэгүй</span><span class="service-badge badge-days">⏱️ Тэр өдрөө</span></div>
        <div class="service-footer"><span class="service-dept">🏥 Эрүүл мэнд</span><button class="service-btn" onclick="event.stopPropagation(); openModal('Эмнэлэгт цаг авах','EM-001')">Цаг авах →</button></div>
      </a>
      <a class="service-card purple" onclick="openModal('Компани бүртгэл', 'AA-001')">
        <div class="service-header"><span class="service-icon">🏢</span><div class="service-title">Компани бүртгэл</div></div>
        <div class="service-desc">Шинэ компани, ХХК болон аж ахуйн нэгж бүртгүүлэх онлайн үйлчилгээ.</div>
        <div class="service-meta"><span class="service-badge badge-free">✅ Үнэгүй</span><span class="service-badge badge-days">⏱️ 5 хоног</span></div>
        <div class="service-footer"><span class="service-dept">💼 ААН</span><button class="service-btn" onclick="event.stopPropagation(); openModal('Компани бүртгэл','AA-001')">Бүртгүүлэх →</button></div>
      </a>
      <a class="service-card" onclick="openModal('Жолооны үнэмлэх', 'ZH-002')">
        <div class="service-header"><span class="service-icon">🪪</span><div class="service-title">Жолооны үнэмлэх</div></div>
        <div class="service-desc">Жолооны үнэмлэх авах болон шинэчлэх онлайн хүсэлт илгээх.</div>
        <div class="service-meta"><span class="service-badge badge-paid">💵 10,000₮</span><span class="service-badge badge-days">⏱️ 10 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🚦 ЗХА</span><button class="service-btn" onclick="event.stopPropagation(); openModal('Жолооны үнэмлэх','ZH-002')">Өргөдөл →</button></div>
      </a>
      <a class="service-card teal" onclick="openModal('Нийгмийн даатгал', 'NH-001')">
        <div class="service-header"><span class="service-icon">🛡️</span><div class="service-title">Нийгмийн даатгал</div></div>
        <div class="service-desc">Нийгмийн даатгалын дэвтэр харах, шимтгэл тооцоолох, мэдэгдэл авах.</div>
        <div class="service-meta"><span class="service-badge badge-free">✅ Үнэгүй</span><span class="service-badge badge-days">⏱️ 1 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🤝 Халамж</span><button class="service-btn" onclick="event.stopPropagation(); openModal('Нийгмийн даатгал','NH-001')">Үзэх →</button></div>
      </a>
    </div>
  </section>

  <section class="section">
    <div class="section-title">⚡ Хурдан хандалт</div>
    <div class="section-sub">Нэг дороос хурдан хандах боломжтой</div>
    <div class="quick-grid">
      <a class="quick-card" onclick="openModal('Өргөдлийн статус шалгах', 'STATUS')"><div class="quick-icon">🔍</div><div class="quick-title">Өргөдлийн статус шалгах</div></a>
      <a class="quick-card" onclick="openModal('Торгуулийн мэдээлэл', 'FINE')"><div class="quick-icon">🚦</div><div class="quick-title">Торгуулийн мэдээлэл</div></a>
      <a class="quick-card" onclick="openModal('Татварын тайлан', 'TV-001')"><div class="quick-icon">📊</div><div class="quick-title">Татварын тайлан</div></a>
      <a class="quick-card" onclick="openModal('Хүүхдийн мөнгө', 'NH-001')"><div class="quick-icon">👶</div><div class="quick-title">Хүүхдийн мөнгө</div></a>
      <a class="quick-card" onclick="openModal('Тэтгэвэр мэдэгдэл', 'NH-002')"><div class="quick-icon">👴</div><div class="quick-title">Тэтгэвэр мэдэгдэл</div></a>
      <a class="quick-card" onclick="openModal('Сургуульд бүртгэх', 'BL-001')"><div class="quick-icon">🎒</div><div class="quick-title">Сургуульд бүртгэх</div></a>
    </div>
  </section>

  <section class="section">
    <div class="section-title">📰 Мэдэгдэл & Мэдээ</div>
    <div class="section-sub">Дорнод аймгийн цахим засаглалын сүүлийн мэдээнүүд</div>
    <div class="news-grid">
      <div class="news-card" onclick="showPage('news')">
        <div class="news-img">💻</div>
        <div class="news-body">
          <span class="news-tag orange-tag">ШИНЭ</span>
          <div class="news-title">DRONCON 2025 аймгийн өсвөр үеийн "ХУРЛАН" клубийн 13 тамирчин оролцлоо</div>
          <div class="news-date">📅 2025 оны 5 дугаар сар</div>
        </div>
      </div>
      <div class="news-card" onclick="showPage('news')">
        <div class="news-img">📱</div>
        <div class="news-body">
          <span class="news-tag">МЭДЭГДЭЛ</span>
          <div class="news-title">Цахим үйлчилгээний шинэ функцүүд нэмэгдлээ — иргэний бүртгэл онлайн боломжтой боллоо</div>
          <div class="news-date">📅 2025 оны 4 дүгээр сар</div>
        </div>
      </div>
      <div class="news-card" onclick="showPage('news')">
        <div class="news-img">🌐</div>
        <div class="news-body">
          <span class="news-tag green-tag">АЯН</span>
          <div class="news-title">Цахимд ч Найз байя — Үндэсний нөлөөллийн аян Дорнод аймагт идэвхтэй явагдаж байна</div>
          <div class="news-date">📅 2025 оны 3 дугаар сар</div>
        </div>
      </div>
    </div>
  </section>
</div>

<!-- ============================================================ -->
<!-- PAGE: SERVICES -->
<!-- ============================================================ -->
<div class="page" id="page-services">
  <div class="page-hero">
    <div class="breadcrumb">🏠 Нүүр → <span>Үйлчилгээнүүд</span></div>
    <h2>📋 Бүх үйлчилгээнүүд</h2>
    <p>Дорнод аймгийн цахим засгийн газрын бүх үйлчилгээний жагсаалт</p>
  </div>
  <div class="filter-bar">
    <button class="filter-btn active" onclick="filterServices('all', this)">🌐 Бүгд</button>
    <button class="filter-btn" onclick="filterServices('irged', this)">👤 Иргэний бүртгэл</button>
    <button class="filter-btn" onclick="filterServices('gazar', this)">🗺️ Газар</button>
    <button class="filter-btn" onclick="filterServices('tatvar', this)">💰 Татвар</button>
    <button class="filter-btn" onclick="filterServices('eruel', this)">🏥 Эрүүл мэнд</button>
    <button class="filter-btn" onclick="filterServices('bolov', this)">🎓 Боловсрол</button>
    <button class="filter-btn" onclick="filterServices('halams', this)">🤝 Халамж</button>
    <button class="filter-btn" onclick="filterServices('teever', this)">🚗 Тээвэр</button>
    <button class="filter-btn" onclick="filterServices('aaan', this)">🏢 ААН</button>
    <div class="filter-search">
      <input type="text" placeholder="🔍 Хайх..." id="svcSearch" oninput="searchServices()">
    </div>
  </div>
  <section class="section">
    <div class="services-grid" id="allServicesGrid">
      <!-- irged -->
      <a class="service-card" data-cat="irged" onclick="openModal('Иргэний үнэмлэх шинэчлэх','IU-001')">
        <div class="service-header"><span class="service-icon">🪪</span><div class="service-title">Иргэний үнэмлэх шинэчлэх</div></div>
        <div class="service-desc">Иргэний үнэмлэхийн хугацаа дуусмагц цахимаар шинэчлэх.</div>
        <div class="service-meta"><span class="service-badge badge-paid">💵 5,000₮</span><span class="service-badge badge-days">⏱️ 5 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🏛️ ИТА</span><button class="service-btn" onclick="event.stopPropagation();openModal('Иргэний үнэмлэх шинэчлэх','IU-001')">Өргөдөл →</button></div>
      </a>
      <a class="service-card" data-cat="irged" onclick="openModal('Төрсний гэрчилгээ авах','IU-002')">
        <div class="service-header"><span class="service-icon">👶</span><div class="service-title">Төрсний гэрчилгээ авах</div></div>
        <div class="service-desc">Шинээр төрсөн хүүхдийн бүртгэл, гэрчилгээ авах.</div>
        <div class="service-meta"><span class="service-badge badge-free">✅ Үнэгүй</span><span class="service-badge badge-days">⏱️ 3 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🏛️ ИТА</span><button class="service-btn" onclick="event.stopPropagation();openModal('Төрсний гэрчилгээ авах','IU-002')">Өргөдөл →</button></div>
      </a>
      <a class="service-card" data-cat="irged" onclick="openModal('Гэрлэлтийн гэрчилгээ','IU-003')">
        <div class="service-header"><span class="service-icon">💑</span><div class="service-title">Гэрлэлтийн гэрчилгээ</div></div>
        <div class="service-desc">Гэрлэлт бүртгэх болон гэрчилгээ авах цахим үйлчилгээ.</div>
        <div class="service-meta"><span class="service-badge badge-free">✅ Үнэгүй</span><span class="service-badge badge-days">⏱️ 3 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🏛️ ИТА</span><button class="service-btn" onclick="event.stopPropagation();openModal('Гэрлэлтийн гэрчилгээ','IU-003')">Өргөдөл →</button></div>
      </a>
      <a class="service-card" data-cat="irged" onclick="openModal('Шилжих бүртгэл','IU-004')">
        <div class="service-header"><span class="service-icon">🏠</span><div class="service-title">Шилжих бүртгэл</div></div>
        <div class="service-desc">Оршин суугаа хаяг шилжүүлэх цахим үйлчилгээ.</div>
        <div class="service-meta"><span class="service-badge badge-paid">💵 500₮</span><span class="service-badge badge-days">⏱️ 5 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🏛️ ИТА</span><button class="service-btn" onclick="event.stopPropagation();openModal('Шилжих бүртгэл','IU-004')">Өргөдөл →</button></div>
      </a>
      <!-- gazar -->
      <a class="service-card orange" data-cat="gazar" onclick="openModal('Газрын гэрчилгээ авах','GH-001')">
        <div class="service-header"><span class="service-icon">📜</span><div class="service-title">Газрын гэрчилгээ авах</div></div>
        <div class="service-desc">Газрын эзэмшлийн гэрчилгээ авах цахим хүсэлт.</div>
        <div class="service-meta"><span class="service-badge badge-paid">💵 10,000₮</span><span class="service-badge badge-days">⏱️ 10 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🗺️ Газрын газар</span><button class="service-btn" onclick="event.stopPropagation();openModal('Газрын гэрчилгээ авах','GH-001')">Өргөдөл →</button></div>
      </a>
      <a class="service-card orange" data-cat="gazar" onclick="openModal('Газар шилжүүлэх','GH-002')">
        <div class="service-header"><span class="service-icon">🔄</span><div class="service-title">Газар шилжүүлэх</div></div>
        <div class="service-desc">Газрын эзэмшигчийг шилжүүлэх хүсэлт.</div>
        <div class="service-meta"><span class="service-badge badge-paid">💵 15,000₮</span><span class="service-badge badge-days">⏱️ 15 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🗺️ Газрын газар</span><button class="service-btn" onclick="event.stopPropagation();openModal('Газар шилжүүлэх','GH-002')">Өргөдөл →</button></div>
      </a>
      <a class="service-card orange" data-cat="gazar" onclick="openModal('Кадастрын мэдээлэл','GH-003')">
        <div class="service-header"><span class="service-icon">🗺️</span><div class="service-title">Кадастрын мэдээлэл</div></div>
        <div class="service-desc">Газрын зургийн мэдээлэл харах, шалгах.</div>
        <div class="service-meta"><span class="service-badge badge-free">✅ Үнэгүй</span><span class="service-badge badge-days">⏱️ 1 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🗺️ Газрын газар</span><button class="service-btn" onclick="event.stopPropagation();openModal('Кадастрын мэдээлэл','GH-003')">Үзэх →</button></div>
      </a>
      <!-- tatvar -->
      <a class="service-card" data-cat="tatvar" onclick="openModal('Татварын тайлан','TV-001')">
        <div class="service-header"><span class="service-icon">📊</span><div class="service-title">Татварын тайлан</div></div>
        <div class="service-desc">Хувь хүний орлогын татварын тайлан илгээх.</div>
        <div class="service-meta"><span class="service-badge badge-free">✅ Үнэгүй</span><span class="service-badge badge-days">⏱️ 3 хоног</span></div>
        <div class="service-footer"><span class="service-dept">💰 Татварын газар</span><button class="service-btn" onclick="event.stopPropagation();openModal('Татварын тайлан','TV-001')">Илгээх →</button></div>
      </a>
      <a class="service-card" data-cat="tatvar" onclick="openModal('ААН татварын бүртгэл','TV-002')">
        <div class="service-header"><span class="service-icon">🏢</span><div class="service-title">ААН татварын бүртгэл</div></div>
        <div class="service-desc">Аж ахуйн нэгжийг татварт бүртгэх.</div>
        <div class="service-meta"><span class="service-badge badge-free">✅ Үнэгүй</span><span class="service-badge badge-days">⏱️ 5 хоног</span></div>
        <div class="service-footer"><span class="service-dept">💰 Татварын газар</span><button class="service-btn" onclick="event.stopPropagation();openModal('ААН татварын бүртгэл','TV-002')">Бүртгүүлэх →</button></div>
      </a>
      <!-- eruel -->
      <a class="service-card green" data-cat="eruel" onclick="openModal('Эмнэлэгт цаг авах','EM-001')">
        <div class="service-header"><span class="service-icon">🏥</span><div class="service-title">Эмнэлэгт цаг авах</div></div>
        <div class="service-desc">Дорнод аймгийн эмнэлэгт цаг авах.</div>
        <div class="service-meta"><span class="service-badge badge-free">✅ Үнэгүй</span><span class="service-badge badge-days">⏱️ Тэр өдрөө</span></div>
        <div class="service-footer"><span class="service-dept">🏥 Эрүүл мэнд</span><button class="service-btn" onclick="event.stopPropagation();openModal('Эмнэлэгт цаг авах','EM-001')">Цаг авах →</button></div>
      </a>
      <a class="service-card green" data-cat="eruel" onclick="openModal('Эрүүл мэндийн даатгал','EM-002')">
        <div class="service-header"><span class="service-icon">💊</span><div class="service-title">Эрүүл мэндийн даатгал</div></div>
        <div class="service-desc">ЭМД-ын мэдээлэл шалгах, баталгаажуулах.</div>
        <div class="service-meta"><span class="service-badge badge-free">✅ Үнэгүй</span><span class="service-badge badge-days">⏱️ 1 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🏥 Эрүүл мэнд</span><button class="service-btn" onclick="event.stopPropagation();openModal('Эрүүл мэндийн даатгал','EM-002')">Шалгах →</button></div>
      </a>
      <!-- bolov -->
      <a class="service-card purple" data-cat="bolov" onclick="openModal('Сургуульд бүртгэх','BL-001')">
        <div class="service-header"><span class="service-icon">🎒</span><div class="service-title">Сургуульд бүртгэх</div></div>
        <div class="service-desc">Хүүхдийг сургуульд бүртгүүлэх онлайн.</div>
        <div class="service-meta"><span class="service-badge badge-free">✅ Үнэгүй</span><span class="service-badge badge-days">⏱️ 3 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🎓 Боловсрол</span><button class="service-btn" onclick="event.stopPropagation();openModal('Сургуульд бүртгэх','BL-001')">Бүртгүүлэх →</button></div>
      </a>
      <!-- halams -->
      <a class="service-card teal" data-cat="halams" onclick="openModal('Хүүхдийн мөнгө','NH-001')">
        <div class="service-header"><span class="service-icon">👶</span><div class="service-title">Хүүхдийн мөнгө</div></div>
        <div class="service-desc">Хүүхдийн мөнгөний мэдэгдэл харах.</div>
        <div class="service-meta"><span class="service-badge badge-free">✅ Үнэгүй</span><span class="service-badge badge-days">⏱️ 1 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🤝 Халамж</span><button class="service-btn" onclick="event.stopPropagation();openModal('Хүүхдийн мөнгө','NH-001')">Шалгах →</button></div>
      </a>
      <a class="service-card teal" data-cat="halams" onclick="openModal('Тэтгэвэр','NH-002')">
        <div class="service-header"><span class="service-icon">👴</span><div class="service-title">Тэтгэвэр</div></div>
        <div class="service-desc">Тэтгэврийн хэмжээ болон мэдэгдэл шалгах.</div>
        <div class="service-meta"><span class="service-badge badge-free">✅ Үнэгүй</span><span class="service-badge badge-days">⏱️ 1 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🤝 Халамж</span><button class="service-btn" onclick="event.stopPropagation();openModal('Тэтгэвэр','NH-002')">Шалгах →</button></div>
      </a>
      <!-- teever -->
      <a class="service-card red" data-cat="teever" onclick="openModal('Тээврийн хэрэгсэл бүртгэл','ZH-001')">
        <div class="service-header"><span class="service-icon">🚗</span><div class="service-title">Тээврийн хэрэгсэл бүртгэл</div></div>
        <div class="service-desc">Автомашин шинээр бүртгэх, шилжүүлэх.</div>
        <div class="service-meta"><span class="service-badge badge-paid">💵 20,000₮</span><span class="service-badge badge-days">⏱️ 7 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🚦 ЗХА</span><button class="service-btn" onclick="event.stopPropagation();openModal('Тээврийн хэрэгсэл бүртгэл','ZH-001')">Бүртгүүлэх →</button></div>
      </a>
      <a class="service-card red" data-cat="teever" onclick="openModal('Жолооны үнэмлэх','ZH-002')">
        <div class="service-header"><span class="service-icon">🪪</span><div class="service-title">Жолооны үнэмлэх</div></div>
        <div class="service-desc">Жолооны үнэмлэх авах, шинэчлэх.</div>
        <div class="service-meta"><span class="service-badge badge-paid">💵 10,000₮</span><span class="service-badge badge-days">⏱️ 10 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🚦 ЗХА</span><button class="service-btn" onclick="event.stopPropagation();openModal('Жолооны үнэмлэх','ZH-002')">Өргөдөл →</button></div>
      </a>
      <!-- aaan -->
      <a class="service-card purple" data-cat="aaan" onclick="openModal('Компани бүртгэл','AA-001')">
        <div class="service-header"><span class="service-icon">🏢</span><div class="service-title">Компани бүртгэл</div></div>
        <div class="service-desc">Шинэ ХХК, компани бүртгэх.</div>
        <div class="service-meta"><span class="service-badge badge-free">✅ Үнэгүй</span><span class="service-badge badge-days">⏱️ 5 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🏢 ААН</span><button class="service-btn" onclick="event.stopPropagation();openModal('Компани бүртгэл','AA-001')">Бүртгүүлэх →</button></div>
      </a>
      <a class="service-card purple" data-cat="aaan" onclick="openModal('Тусгай зөвшөөрөл','AA-002')">
        <div class="service-header"><span class="service-icon">📃</span><div class="service-title">Тусгай зөвшөөрөл</div></div>
        <div class="service-desc">Аж ахуйн тусгай зөвшөөрөл авах.</div>
        <div class="service-meta"><span class="service-badge badge-free">✅ Үнэгүй</span><span class="service-badge badge-days">⏱️ 10 хоног</span></div>
        <div class="service-footer"><span class="service-dept">🏢 ААН</span><button class="service-btn" onclick="event.stopPropagation();openModal('Тусгай зөвшөөрөл','AA-002')">Өргөдөл →</button></div>
      </a>
    </div>
  </section>
</div>

<!-- ============================================================ -->
<!-- PAGE: NEWS -->
<!-- ============================================================ -->
<div class="page" id="page-news">
  <div class="page-hero">
    <div class="breadcrumb">🏠 Нүүр → <span>Мэдэгдэл & Мэдээ</span></div>
    <h2>📰 Мэдэгдэл & Зарлал</h2>
    <p>Дорнод аймгийн цахим засгийн газрын сүүлийн мэдээ, мэдэгдэл, аян</p>
  </div>
  <div class="filter-bar">
    <button class="filter-btn active" onclick="filterNews('all',this)">🌐 Бүгд</button>
    <button class="filter-btn" onclick="filterNews('medegdel',this)">📢 Мэдэгдэл</button>
    <button class="filter-btn" onclick="filterNews('zaraal',this)">📋 Зарлал</button>
    <button class="filter-btn" onclick="filterNews('ayan',this)">🌐 Аян</button>
  </div>
  <section class="section">
    <div class="news-grid" id="newsGrid">
      <div class="news-card" data-type="ayan">
        <div class="news-img" style="background:linear-gradient(135deg,#1565c0,#ff6d00)">💻</div>
        <div class="news-body">
          <span class="news-tag orange-tag">АЯН</span>
          <div class="news-title">DRONCON 2025 — Аймгийн өсвөр үеийн "ХУРЛАН" клубийн 13 тамирчин оролцлоо</div>
          <div class="news-date">📅 2025 оны 5 дугаар сар</div>
          <p style="font-size:12px;color:var(--gray);margin-top:10px;line-height:1.6">Дорнод аймгийн цахим шилжилтийн хэлтэсээс зохиосон DRONCON 2025 арга хэмжээнд аймгийн өсвөр үеийн хурлан клубийн 13 тамирчин идэвхтэй оролцлоо. Арга хэмжээнд дрон нисгэх тэмцээн, цахим мэдлэгийн уралдаан зохиогдлоо.</p>
        </div>
      </div>
      <div class="news-card" data-type="medegdel">
        <div class="news-img" style="background:linear-gradient(135deg,#0d2b5e,#1565c0)">📱</div>
        <div class="news-body">
          <span class="news-tag">МЭДЭГДЭЛ</span>
          <div class="news-title">Цахим үйлчилгээний шинэ функцүүд нэмэгдлээ</div>
          <div class="news-date">📅 2025 оны 4 дүгээр сар</div>
          <p style="font-size:12px;color:var(--gray);margin-top:10px;line-height:1.6">Дорнод аймгийн цахим үйлчилгээний вэбсайтад иргэний бүртгэлийн шинэ функцүүд нэмэгдлээ. Иргэд гэрийнхээ дулаанаас тав тухтайгаар үйлчилгээ авах боломжтой боллоо.</p>
        </div>
      </div>
      <div class="news-card" data-type="ayan">
        <div class="news-img" style="background:linear-gradient(135deg,#43a047,#0d2b5e)">🌐</div>
        <div class="news-body">
          <span class="news-tag green-tag">АЯН</span>
          <div class="news-title">Цахимд ч Найз байя — Үндэсний нөлөөллийн аян</div>
          <div class="news-date">📅 2025 оны 3 дугаар сар</div>
          <p style="font-size:12px;color:var(--gray);margin-top:10px;line-height:1.6">Монгол Улсын Ерөнхий сайдын ивээл дор явагдаж буй "Цахимд ч Найз байя" үндэсний нөлөөллийн аян Дорнод аймагт идэвхтэй явагдаж байна.</p>
        </div>
      </div>
      <div class="news-card" data-type="zaraal">
        <div class="news-img" style="background:linear-gradient(135deg,#7b1fa2,#0d2b5e)">📋</div>
        <div class="news-body">
          <span class="news-tag" style="background:rgba(123,31,162,0.1);color:#7b1fa2">ЗАРЛАЛ</span>
          <div class="news-title">2025 оны цахим засгийн газрын үйл ажиллагааны тайлан</div>
          <div class="news-date">📅 2025 оны 2 дугаар сар</div>
          <p style="font-size:12px;color:var(--gray);margin-top:10px;line-height:1.6">Дорнод аймгийн цахим шилжилтийн хэлтэс 2024 оны үйл ажиллагааны тайлангаа олон нийтэд нээлттэй танилцуулав. Нийт 2,345 иргэнд үйлчилгээ үзүүлсэн байна.</p>
        </div>
      </div>
      <div class="news-card" data-type="medegdel">
        <div class="news-img" style="background:linear-gradient(135deg,#e65100,#1565c0)">🔐</div>
        <div class="news-body">
          <span class="news-tag">МЭДЭГДЭЛ</span>
          <div class="news-title">Цахим аюулгүй байдлын сургалт аймгийн ажилтнуудад зориулав</div>
          <div class="news-date">📅 2025 оны 1 дүгээр сар</div>
          <p style="font-size:12px;color:var(--gray);margin-top:10px;line-height:1.6">Аймгийн нийт ажилтнуудад цахим аюулгүй байдлын сургалтыг амжилттай явуулж, 120 ажилтан сертификат хүлээн авлаа.</p>
        </div>
      </div>
      <div class="news-card" data-type="ayan">
        <div class="news-img" style="background:linear-gradient(135deg,#ff6d00,#43a047)">🌱</div>
        <div class="news-body">
          <span class="news-tag orange-tag">АЯН</span>
          <div class="news-title">Ногоон цахим — Цаасгүй засаг аяны хүрээнд 5,000 хэрэглэгч бүртгэгдлээ</div>
          <div class="news-date">📅 2024 оны 12 дугаар сар</div>
          <p style="font-size:12px;color:var(--gray);margin-top:10px;line-height:1.6">Цаасгүй засгийн газрын зорилтын хүрээнд аймгийн иргэдийн 5,000 гаруй нь цахим үйлчилгээнд бүртгэгдэн, тогтмол хэрэглэгч болсон байна.</p>
        </div>
      </div>
    </div>
  </section>
</div>

<!-- ============================================================ -->
<!-- PAGE: REPORT -->
<!-- ============================================================ -->
<div class="page" id="page-report">
  <div class="page-hero">
    <div class="breadcrumb">🏠 Нүүр → <span>Тайлан & Статистик</span></div>
    <h2>📊 Үйл ажиллагааны тайлан</h2>
    <p>Дорнод аймгийн цахим үйлчилгээний статистик мэдээлэл — 2025 он</p>
  </div>
  <section class="section">
    <div class="dashboard-grid">
      <div class="dash-card"><div class="dash-num">2,847</div><div class="dash-label">Нийт өргөдөл</div><div class="dash-change">▲ +12% өмнөх сараас</div></div>
      <div class="dash-card orange"><div class="dash-num">234</div><div class="dash-label">Хүлээгдэж буй</div><div class="dash-change" style="color:var(--orange)">▶ Хянагдаж байна</div></div>
      <div class="dash-card green"><div class="dash-num">2,489</div><div class="dash-label">Дууссан</div><div class="dash-change">▲ 87.4% гүйцэтгэл</div></div>
      <div class="dash-card purple"><div class="dash-num">124</div><div class="dash-label">Татгалзсан</div><div class="dash-change" style="color:#7b1fa2">▼ -3% буурсан</div></div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
      <div class="chart-card">
        <div class="chart-title">📈 Сарын өргөдлийн тоо (2025)</div>
        <div class="bar-chart">
          <div class="bar-col"><div class="bar-val">187</div><div class="bar" style="height:60%"></div><div class="bar-label">1-р сар</div></div>
          <div class="bar-col"><div class="bar-val">210</div><div class="bar" style="height:67%"></div><div class="bar-label">2-р сар</div></div>
          <div class="bar-col"><div class="bar-val">245</div><div class="bar" style="height:78%"></div><div class="bar-label">3-р сар</div></div>
          <div class="bar-col"><div class="bar-val">198</div><div class="bar" style="height:63%"></div><div class="bar-label">4-р сар</div></div>
          <div class="bar-col"><div class="bar-val">312</div><div class="bar" style="height:100%;background:var(--orange)"></div><div class="bar-label">5-р сар</div></div>
        </div>
      </div>
      <div class="chart-card">
        <div class="chart-title">🏆 Хэлтсийн гүйцэтгэл</div>
        <div class="progress-wrap"><div class="progress-label"><span>👤 ИТА</span><span>94%</span></div><div class="progress-bar"><div class="progress-fill" style="width:94%"></div></div></div>
        <div class="progress-wrap"><div class="progress-label"><span>🗺️ Газрын газар</span><span>81%</span></div><div class="progress-bar"><div class="progress-fill green" style="width:81%"></div></div></div>
        <div class="progress-wrap"><div class="progress-label"><span>💰 Татварын газар</span><span>88%</span></div><div class="progress-bar"><div class="progress-fill" style="width:88%"></div></div></div>
        <div class="progress-wrap"><div class="progress-label"><span>🏥 Эрүүл мэнд</span><span>96%</span></div><div class="progress-bar"><div class="progress-fill green" style="width:96%"></div></div></div>
        <div class="progress-wrap"><div class="progress-label"><span>🚗 ЗХА</span><span>79%</span></div><div class="progress-bar"><div class="progress-fill orange" style="width:79%"></div></div></div>
        <div class="progress-wrap"><div class="progress-label"><span>🤝 Халамж</span><span>91%</span></div><div class="progress-bar"><div class="progress-fill" style="width:91%"></div></div></div>
      </div>
    </div>

    <div style="margin-top:16px">
      <div class="table-card">
        <div class="chart-title">📋 Сүүлийн өргөдлүүд</div>
        <table>
          <thead><tr><th>Дугаар</th><th>Иргэн</th><th>Үйлчилгээ</th><th>Хэлтэс</th><th>Огноо</th><th>Статус</th></tr></thead>
          <tbody>
            <tr><td>URG-2025-000001</td><td>Батсайхан Дорж</td><td>🪪 Иргэний үнэмлэх</td><td>ИТА</td><td>2025-05-10</td><td><span class="status-badge s-havalj">Хянагдаж байна</span></td></tr>
            <tr><td>URG-2025-000002</td><td>Мөнхбаатар Сувд</td><td>📜 Газрын гэрчилгээ</td><td>Газрын газар</td><td>2025-05-09</td><td><span class="status-badge s-irsen">Ирсэн</span></td></tr>
            <tr><td>URG-2025-000003</td><td>Гантулга Болд</td><td>🏥 Эмнэлэгт цаг</td><td>Эрүүл мэнд</td><td>2025-05-09</td><td><span class="status-badge s-batalgaa">Баталгаажсан</span></td></tr>
            <tr><td>URG-2025-000004</td><td>Оюунцэцэг Д.</td><td>🚗 Тээвэр бүртгэл</td><td>ЗХА</td><td>2025-05-08</td><td><span class="status-badge s-duussen">Дууссан</span></td></tr>
            <tr><td>URG-2025-000005</td><td>Энхбаатар Г.</td><td>💊 ЭМД шалгах</td><td>Эрүүл мэнд</td><td>2025-05-08</td><td><span class="status-badge s-duussen">Дууссан</span></td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </section>
</div>

<!-- ============================================================ -->
<!-- PAGE: ACCOUNT / DANS -->
<!-- ============================================================ -->
<div class="page" id="page-account">
  <div id="loginView">
    <div class="login-section">
      <div class="login-card">
        <div class="login-logo">🌐</div>
        <h3>Нэвтрэх</h3>
        <p>Дорнод аймгийн цахим үйлчилгээний системд нэвтрэх</p>
        <div class="form-group">
          <label>Регистрийн дугаар</label>
          <input type="text" placeholder="УА99012345" id="loginReg">
        </div>
        <div class="form-group">
          <label>Нууц үг</label>
          <input type="password" placeholder="••••••••" id="loginPass">
        </div>
        <button class="btn-primary" onclick="doLogin()">🔐 Нэвтрэх</button>
        <div class="login-divider">эсвэл</div>
        <button class="btn-orange" onclick="doLogin()">📱 e-Mongolia-р нэвтрэх</button>
        <p style="text-align:center;margin-top:16px;font-size:12px;color:var(--gray)">Бүртгэлгүй бол <a href="#" style="color:var(--blue-accent)">энд бүртгүүлнэ үү</a></p>
      </div>
    </div>
  </div>

  <div id="profileView" style="display:none">
    <div class="account-hero">
      <div class="account-avatar">👤</div>
      <div>
        <div class="account-name">Батсайхан Дорж</div>
        <div class="account-reg">УА99012345 | Дорнод аймаг, Чойбалсан хот</div>
        <div style="margin-top:8px;font-size:12px;color:rgba(255,255,255,0.5)">📞 99112233 | ✉️ dorj@example.mn</div>
      </div>
      <div style="margin-left:auto">
        <button onclick="doLogout()" style="padding:8px 18px;background:rgba(255,255,255,0.15);color:white;border:1px solid rgba(255,255,255,0.3);border-radius:20px;cursor:pointer;font-size:13px;font-family:inherit">🚪 Гарах</button>
      </div>
    </div>

    <div class="account-tabs">
      <div class="acc-tab active" onclick="switchTab('info',this)">👤 Мэдээлэл</div>
      <div class="acc-tab" onclick="switchTab('apps',this)">📋 Өргөдлүүд</div>
      <div class="acc-tab" onclick="switchTab('notif',this)">🔔 Мэдэгдэл</div>
      <div class="acc-tab" onclick="switchTab('settings',this)">⚙️ Тохиргоо</div>
    </div>

    <div class="acc-panel active" id="tab-info">
      <div class="section-title" style="margin-bottom:16px">👤 Хувийн мэдээлэл</div>
      <div class="info-grid">
        <div class="info-item"><div class="info-label">ОВОГ</div><div class="info-val">Батсайхан</div></div>
        <div class="info-item"><div class="info-label">НЭР</div><div class="info-val">Дорж</div></div>
        <div class="info-item"><div class="info-label">РЕГИСТР</div><div class="info-val">УА99012345</div></div>
        <div class="info-item"><div class="info-label">УТАС</div><div class="info-val">99112233</div></div>
        <div class="info-item"><div class="info-label">И-МЭЙЛ</div><div class="info-val">dorj@example.mn</div></div>
        <div class="info-item"><div class="info-label">ХАЯГ</div><div class="info-val">Дорнод аймаг, Чойбалсан хот, 1-р баг</div></div>
      </div>
      <button class="service-btn" style="padding:10px 24px;font-size:13px" onclick="showToast('Мэдээлэл шинэчлэгдлээ!')">✏️ Мэдээлэл засах</button>
    </div>

    <div class="acc-panel" id="tab-apps">
      <div class="section-title" style="margin-bottom:16px">📋 Миний өргөдлүүд</div>
      <div class="table-card" style="margin-bottom:16px">
        <table>
          <thead><tr><th>Дугаар</th><th>Үйлчилгээ</th><th>Огноо</th><th>Статус</th><th>Үйлдэл</th></tr></thead>
          <tbody>
            <tr><td>URG-2025-000001</td><td>🪪 Иргэний үнэмлэх</td><td>2025-05-10</td><td><span class="status-badge s-havalj">Хянагдаж байна</span></td><td><button class="service-btn" style="font-size:10px" onclick="showToast('Өргөдлийн дэлгэрэнгүй')">Дэлгэрэнгүй</button></td></tr>
          </tbody>
        </table>
      </div>
      <button class="service-btn" style="padding:10px 24px;font-size:13px" onclick="openModal('Шинэ өргөдөл','NEW')">➕ Шинэ өргөдөл</button>
    </div>

    <div class="acc-panel" id="tab-notif">
      <div class="section-title" style="margin-bottom:16px">🔔 Мэдэгдлүүд</div>
      <div class="timeline">
        <div class="tl-item">
          <div class="tl-left"><div class="tl-dot">🪪</div><div class="tl-line"></div></div>
          <div class="tl-content"><div class="tl-title">Иргэний үнэмлэх шинэчлэлтийн өргөдөл хүлээн авагдлаа</div><div class="tl-date">📅 2025-05-10 10:30</div></div>
        </div>
        <div class="tl-item">
          <div class="tl-left"><div class="tl-dot orange">📧</div><div class="tl-line"></div></div>
          <div class="tl-content"><div class="tl-title">Системд амжилттай бүртгэгдлээ</div><div class="tl-date">📅 2025-05-01 09:00</div></div>
        </div>
        <div class="tl-item">
          <div class="tl-left"><div class="tl-dot green">✅</div><div class="tl-line" style="background:transparent"></div></div>
          <div class="tl-content"><div class="tl-title">Нууц үг амжилттай тохируулагдлаа</div><div class="tl-date">📅 2025-04-28 14:15</div></div>
        </div>
      </div>
    </div>

    <div class="acc-panel" id="tab-settings">
      <div class="section-title" style="margin-bottom:16px">⚙️ Тохиргоо</div>
      <div class="contact-card" style="max-width:480px">
        <div class="form-group"><label>Нууц үг солих</label><input type="password" placeholder="Хуучин нууц үг"></div>
        <div class="form-group"><input type="password" placeholder="Шинэ нууц үг"></div>
        <div class="form-group"><input type="password" placeholder="Шинэ нууц үг давтах"></div>
        <div class="form-group">
          <label>Мэдэгдэл хүлээн авах</label>
          <select><option>И-мэйл + SMS</option><option>Зөвхөн и-мэйл</option><option>Зөвхөн SMS</option></select>
        </div>
        <button class="btn-primary" onclick="showToast('Тохиргоо хадгалагдлаа!')">💾 Хадгалах</button>
      </div>
    </div>
  </div>
</div>

<!-- ============================================================ -->
<!-- PAGE: CONTACT -->
<!-- ============================================================ -->
<div class="page" id="page-contact">
  <div class="page-hero">
    <div class="breadcrumb">🏠 Нүүр → <span>Холбоо барих</span></div>
    <h2>📞 Холбоо барих</h2>
    <p>Дорнод аймгийн цахим шилжилтийн хэлтэс болон хэлтсүүдийн хаяг, холбоо барих мэдээлэл</p>
  </div>
  <section class="section">
    <div class="contact-grid">
      <div>
        <div class="map-placeholder">
          <div class="map-icon">📍</div>
          <div>Дорнод аймаг, Чойбалсан хот</div>
          <div style="font-size:12px;opacity:0.7">Аймгийн Засаг даргын тамгын газар</div>
        </div>
        <div class="dept-list">
          <div class="dept-item"><div class="dept-icon">👤</div><div><div class="dept-name">ИТА — Иргэний Төлөв байдал, Архивын газар</div><div class="dept-info"><span>📞 70582001</span><span>✉️ ita@dornod.gov.mn</span><span>🕐 09:00-18:00 (Да-Пү)</span></div></div></div>
          <div class="dept-item"><div class="dept-icon">🗺️</div><div><div class="dept-name">Газрын харилцааны газар</div><div class="dept-info"><span>📞 70582002</span><span>✉️ gazar@dornod.gov.mn</span><span>🕐 09:00-18:00 (Да-Пү)</span></div></div></div>
          <div class="dept-item"><div class="dept-icon">💰</div><div><div class="dept-name">Татварын газар</div><div class="dept-info"><span>📞 70582003</span><span>✉️ tatvar@dornod.gov.mn</span><span>🕐 09:00-17:30 (Да-Пү)</span></div></div></div>
          <div class="dept-item"><div class="dept-icon">🏥</div><div><div class="dept-name">Эрүүл мэндийн газар</div><div class="dept-info"><span>📞 70582004</span><span>✉️ eruel@dornod.gov.mn</span><span>🕐 09:00-18:00 (Да-Пү)</span></div></div></div>
          <div class="dept-item"><div class="dept-icon">🎓</div><div><div class="dept-name">Боловсрол, соёлын газар</div><div class="dept-info"><span>📞 70582005</span><span>✉️ bolv@dornod.gov.mn</span><span>🕐 09:00-18:00 (Да-Пү)</span></div></div></div>
          <div class="dept-item"><div class="dept-icon">🤝</div><div><div class="dept-name">Нийгмийн халамжийн газар</div><div class="dept-info"><span>📞 70582006</span><span>✉️ nhalams@dornod.gov.mn</span><span>🕐 09:00-18:00 (Да-Пү)</span></div></div></div>
          <div class="dept-item"><div class="dept-icon">🚗</div><div><div class="dept-name">ЗХА — Замын хөдөлгөөний газар</div><div class="dept-info"><span>📞 70582007</span><span>✉️ zha@dornod.gov.mn</span><span>🕐 09:00-18:00 (Да-Пү)</span></div></div></div>
          <div class="dept-item"><div class="dept-icon">🏢</div><div><div class="dept-name">ААН Бүртгэлийн газар</div><div class="dept-info"><span>📞 70582008</span><span>✉️ aaan@dornod.gov.mn</span><span>🕐 09:00-18:00 (Да-Пү)</span></div></div></div>
        </div>
      </div>
      <div>
        <div class="contact-form-card">
          <h3>📩 Санал, гомдол илгээх</h3>
          <div class="form-group"><label>Таны нэр</label><input type="text" placeholder="Овог нэр"></div>
          <div class="form-group"><label>Утасны дугаар</label><input type="text" placeholder="99001122"></div>
          <div class="form-group"><label>И-мэйл</label><input type="email" placeholder="example@gmail.com"></div>
          <div class="form-group"><label>Хандах хэлтэс</label>
            <select>
              <option>ИТА — Иргэний бүртгэл</option>
              <option>Газрын харилцаа</option>
              <option>Татварын газар</option>
              <option>Эрүүл мэнд</option>
              <option>Боловсрол</option>
              <option>Нийгмийн халамж</option>
              <option>ЗХА</option>
              <option>ААН бүртгэл</option>
              <option>Ерөнхий асуулт</option>
            </select>
          </div>
          <div class="form-group"><label>Гарчиг</label><input type="text" placeholder="Санал, гомдлын гарчиг"></div>
          <div class="form-group"><label>Дэлгэрэнгүй</label><textarea placeholder="Санал, гомдлоо дэлгэрэнгүй бичнэ үү..."></textarea></div>
          <div style="display:flex;gap:10px">
            <button class="btn-primary" onclick="showToast('Санал амжилттай илгээгдлээ! Удахгүй хариу өгнө.')">📤 Илгээх</button>
          </div>
        </div>

        <div class="contact-form-card" style="margin-top:16px">
          <h3>⏰ Ажлын цаг</h3>
          <table style="width:100%">
            <tr><td style="padding:8px;font-size:13px">Даваа - Баасан</td><td style="padding:8px;font-size:13px;font-weight:700;color:var(--blue-dark)">09:00 - 18:00</td></tr>
            <tr style="background:var(--gray-light)"><td style="padding:8px;font-size:13px">Бямба</td><td style="padding:8px;font-size:13px;color:var(--gray)">Амарна</td></tr>
            <tr><td style="padding:8px;font-size:13px">Ням</td><td style="padding:8px;font-size:13px;color:var(--gray)">Амарна</td></tr>
            <tr style="background:var(--gray-light)"><td style="padding:8px;font-size:13px">Онлайн үйлчилгээ</td><td style="padding:8px;font-size:13px;font-weight:700;color:var(--green)">24/7</td></tr>
          </table>
        </div>
      </div>
    </div>
  </section>
</div>

<!-- ============================================================ -->
<!-- PAGE: HELP -->
<!-- ============================================================ -->
<div class="page" id="page-help">
  <div class="page-hero">
    <div class="breadcrumb">🏠 Нүүр → <span>Тусламж</span></div>
    <h2>❓ Тусламж & Заавар</h2>
    <p>Цахим үйлчилгээг хэрхэн ашиглах тухай дэлгэрэнгүй мэдээлэл</p>
  </div>
  <section class="section">
    <div class="help-grid">
      <div class="help-card" onclick="showToast('Заавар PDF татаж авна...')"><div class="hc-icon">📖</div><div class="hc-title">Хэрэглэгчийн заавар</div><div class="hc-desc">Цахим үйлчилгээ ашиглах дэлгэрэнгүй заавар</div></div>
      <div class="help-card" onclick="showToast('Видео нээгдэж байна...')"><div class="hc-icon">🎬</div><div class="hc-title">Видео заавар</div><div class="hc-desc">Алхам алхмаар үзүүлсэн видео зааварчилгаа</div></div>
      <div class="help-card" onclick="openModal('Холбоо барих','CONTACT')"><div class="hc-icon">💬</div><div class="hc-title">Онлайн тусламж</div><div class="hc-desc">Ажилтантай шууд холбогдох боломж</div></div>
      <div class="help-card" onclick="showPage('contact')"><div class="hc-icon">📞</div><div class="hc-title">Утсаар холбогдох</div><div class="hc-desc">Ажлын цагаар (0582) 12345 дугаарт залгана уу</div></div>
    </div>

    <div class="section-title" style="margin-bottom:16px">🙋 Түгээмэл асуулт хариулт</div>
    <div class="faq-list">
      <div class="faq-item">
        <div class="faq-q" onclick="toggleFaq(this)">Өргөдлийн статусыг хэрхэн шалгах вэ? <span class="faq-toggle">+</span></div>
        <div class="faq-a">Нүүр хуудсны "Хурдан хандалт" хэсэгт байрлах "Өргөдлийн статус шалгах" товчийг дарна уу. Өргөдлийн дугаар эсвэл регистрийн дугаараараа шалгах боломжтой. Бүртгэлтэй хэрэглэгчид "Дансны мэдээлэл" хэсгийн "Өргөдлүүд" таб-аас харах боломжтой.</div>
      </div>
      <div class="faq-item">
        <div class="faq-q" onclick="toggleFaq(this)">Иргэний үнэмлэх шинэчлэхэд ямар бичиг баримт хэрэгтэй вэ? <span class="faq-toggle">+</span></div>
        <div class="faq-a">Иргэний үнэмлэх шинэчлэхэд дараах бичиг баримт шаардлагатай: 1) Хуучин иргэний үнэмлэх, 2) Бүртгэлийн хуудас (ИТА-аас авна), 3) 2 ширхэг зураг (3x4см), 4) Хөлс төлөлтийн баримт (5,000₮).</div>
      </div>
      <div class="faq-item">
        <div class="faq-q" onclick="toggleFaq(this)">Онлайн өргөдөл илгээсний дараа хэзээ хариу авах вэ? <span class="faq-toggle">+</span></div>
        <div class="faq-a">Өргөдлийн хариуг үйлчилгээний төрлөөс хамааран 1-15 ажлын өдрийн дотор өгнө. Яаралтай тохиолдолд (эмнэлгийн цаг авах) тэр өдрөөс эхлэн боломжтой. Статусыг цахим системээр шалгах боломжтой.</div>
      </div>
      <div class="faq-item">
        <div class="faq-q" onclick="toggleFaq(this)">Цахим хөлс яаж төлөх вэ? <span class="faq-toggle">+</span></div>
        <div class="faq-a">Хөлсийг дараах аргаар төлөх боломжтой: 1) QPay, 2) SocialPay, 3) Интернэт банк, 4) Банкны картаар онлайн. Мөн биечлэн ажилтанд өгч болно.</div>
      </div>
      <div class="faq-item">
        <div class="faq-q" onclick="toggleFaq(this)">Бүртгэлгүйгээр үйлчилгээ авах боломжтой юу? <span class="faq-toggle">+</span></div>
        <div class="faq-a">Тийм, зарим үйлчилгээнд бүртгэлгүй хандах боломжтой. Гэвч бүртгэлтэй хэрэглэгчид өргөдлийн статус шалгах, мэдэгдэл авах, түүхийг харах зэрэг давуу эрх эдэлнэ.</div>
      </div>
      <div class="faq-item">
        <div class="faq-q" onclick="toggleFaq(this)">Нууц үгээ мартсан тохиолдолд юу хийх вэ? <span class="faq-toggle">+</span></div>
        <div class="faq-a">Нэвтрэх хэсгийн "Нууц үг мартсан" холбоосыг дарж, бүртгэлтэй и-мэйл хаяг эсвэл утасны дугаараа оруулна уу. Шинэ нууц үг тохируулах холбоос илгээгдэнэ.</div>
      </div>
      <div class="faq-item">
        <div class="faq-q" onclick="toggleFaq(this)">Компани бүртгэхэд ямар хугацаа шаардагдах вэ? <span class="faq-toggle">+</span></div>
        <div class="faq-a">Компани бүртгэлийн хүсэлтийг хүлээн авснаас хойш 5 ажлын өдрийн дотор боловсруулна. Бичиг баримт бүрэн, зөв бол хугацаа богиносч болно.</div>
      </div>
    </div>

    <div style="background:linear-gradient(135deg,var(--blue-dark),var(--blue-accent));border-radius:16px;padding:32px;margin-top:28px;text-align:center;color:white">
      <div style="font-size:36px;margin-bottom:12px">📞</div>
      <div style="font-size:18px;font-weight:700;margin-bottom:8px">Нэмэлт тусламж хэрэгтэй юу?</div>
      <div style="color:rgba(255,255,255,0.7);margin-bottom:20px;font-size:14px">Манай мэргэжилтнүүд таны асуултад хариулахад бэлэн байна</div>
      <button onclick="showPage('contact')" style="background:var(--orange);color:white;border:none;padding:12px 28px;border-radius:24px;font-size:14px;font-weight:700;cursor:pointer;font-family:inherit">📩 Холбоо барих →</button>
    </div>
  </section>
</div>

<!-- FOOTER -->
<footer>
  <div class="footer-grid">
    <div>
      <div class="footer-logo">
        <div class="footer-logo-globe">🌐</div>
        <div class="footer-logo-text">Дорнод аймгийн<br>Цахим шилжилт, үйлчилгээний хэлтэс</div>
      </div>
      <p class="footer-desc">Дорнод аймгийн иргэдэд цахим засгийн газрын үйлчилгээг хүртээмжтэй, шуурхай, ил тод хүргэх нь бидний зорилго.</p>
      <div class="footer-contact">
        <p>📍 Дорнод аймаг, Чойбалсан хот</p>
        <p>📞 (0582) 12345 | ✉️ info@dornod-digital.mn</p>
        <p>🕐 Ажлын цаг: 09:00–18:00 (Да-Пү)</p>
      </div>
    </div>
    <div class="footer-col">
      <h4>Үйлчилгээ</h4>
      <ul>
        <li><a onclick="showServicesFiltered('irged')">Иргэний бүртгэл</a></li>
        <li><a onclick="showServicesFiltered('gazar')">Газрын харилцаа</a></li>
        <li><a onclick="showServicesFiltered('tatvar')">Татвар санхүү</a></li>
        <li><a onclick="showServicesFiltered('halams')">Нийгмийн халамж</a></li>
        <li><a onclick="showServicesFiltered('teever')">Тээвэр & ЗХА</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Холбоос</h4>
      <ul>
        <li><a href="https://e-mongolia.mn" target="_blank">e-Mongolia</a></li>
        <li><a onclick="showServicesFiltered('irged')">ИТА</a></li>
        <li><a href="#">Хот хөгжил</a></li>
        <li><a href="#">ЗДТГ</a></li>
        <li><a onclick="showServicesFiltered('tatvar')">Татварын газар</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Тусламж</h4>
      <ul>
        <li><a onclick="showPage('help')">Хэрхэн ашиглах</a></li>
        <li><a onclick="showPage('help')">Түгээмэл асуулт</a></li>
        <li><a onclick="showPage('contact')">Холбоо барих</a></li>
        <li><a onclick="showPage('contact')">Санал гомдол</a></li>
        <li><a href="#">Нууцлалын бодлого</a></li>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">
    <span>© 2025 Дорнод аймгийн Цахим шилжилт, үйлчилгээний хэлтэс. Бүх эрх хуулиар хамгаалагдсан.</span>
    <span>
      <a href="#" style="color:var(--orange-light);margin-left:12px;text-decoration:none">Facebook</a>
      <a href="#" style="color:var(--orange-light);margin-left:12px;text-decoration:none">YouTube</a>
    </span>
  </div>
</footer>

<!-- MODAL -->
<div class="modal-overlay" id="modalOverlay" onclick="if(event.target===this)closeModal()">
  <div class="modal">
    <h3 id="modalTitle">Үйлчилгээний өргөдөл</h3>
    <p id="modalDesc">Доорх маягтыг бөглөн өргөдлөө илгээнэ үү.</p>
    <input type="hidden" id="modalServiceCode" value="">
    <div class="form-group"><label>Иргэний регистрийн дугаар</label><input type="text" id="modalRegister" placeholder="УА99012345" maxlength="12"></div>
    <div class="form-group"><label>Утасны дугаар</label><input type="text" id="modalPhone" placeholder="88123456" maxlength="8"></div>
    <div class="form-group"><label>Тайлбар / Нэмэлт мэдээлэл</label><textarea id="modalDesc2" placeholder="Өргөдлийн тайлбарыг энд бичнэ үү..."></textarea></div>
    <div class="modal-btns">
      <button class="btn-cancel" onclick="closeModal()">Болих</button>
      <button class="btn-submit" id="submitBtn" onclick="submitForm()">✅ Илгээх</button>
    </div>
  </div>
</div>

<div class="toast" id="toast">✅ Таны өргөдөл амжилттай илгээгдлээ!</div>

<script>
  // =====================================================
  // DATABASE-ТЭЙГЭЭР ХОЛБОГДСОН ФУНКЦҮҮД
  // =====================================================

  // PAGE NAVIGATION
  function showPage(page) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('nav a').forEach(a => a.classList.remove('active'));
    document.getElementById('page-' + page).classList.add('active');
    const navEl = document.getElementById('nav-' + page);
    if (navEl) navEl.classList.add('active');
    window.scrollTo(0, 0);
  }

  function showServicesFiltered(cat) {
    showPage('services');
    setTimeout(() => {
      filterServices(cat, document.querySelector('.filter-btn'));
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      const map = {irged:1,gazar:2,tatvar:3,eruel:4,bolov:5,halams:6,teever:7,aaan:8};
      const btns = document.querySelectorAll('.filter-btn');
      if (map[cat] !== undefined) btns[map[cat]].classList.add('active');
    }, 50);
  }

  function filterServices(cat, btn) {
    if (btn) {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    }
    document.querySelectorAll('#allServicesGrid .service-card').forEach(card => {
      card.style.display = (cat === 'all' || card.dataset.cat === cat) ? '' : 'none';
    });
  }

  function searchServices() {
    const q = document.getElementById('svcSearch').value.toLowerCase();
    document.querySelectorAll('#allServicesGrid .service-card').forEach(card => {
      card.style.display = card.innerText.toLowerCase().includes(q) ? '' : 'none';
    });
  }

  function filterNews(type, btn) {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('#newsGrid .news-card').forEach(card => {
      card.style.display = (type === 'all' || card.dataset.type === type) ? '' : 'none';
    });
  }

  function doSearch() {
    const q = document.getElementById('homeSearch').value.toLowerCase();
    if (q.includes('иргэн') || q.includes('үнэмлэх')) openModal('Иргэний үнэмлэх шинэчлэх', 'IU-001');
    else if (q.includes('газар')) openModal('Газрын гэрчилгээ авах', 'GH-001');
    else if (q.includes('эмнэлэг') || q.includes('цаг')) openModal('Эмнэлэгт цаг авах', 'EM-001');
    else if (q.includes('татвар')) openModal('Татварын тайлан', 'TV-001');
    else if (q.includes('компани') || q.includes('бизнес')) openModal('Компани бүртгэл', 'AA-001');
    else if (q) { showPage('services'); }
  }

  document.getElementById('homeSearch').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') doSearch();
  });

  // =====================================================
  // MODAL — DATABASE-РУУ ИЛГЭЭХ
  // =====================================================
  const serviceDescs = {
    'IU-001': 'Иргэний үнэмлэхийг цахимаар шинэчлэх өргөдлөө илгээнэ үү.',
    'IU-002': 'Шинээр төрсөн хүүхдийн бүртгэл хийлгэх өргөдөл.',
    'IU-003': 'Гэрлэлт бүртгэх болон гэрчилгээ авах.',
    'IU-004': 'Оршин суугаа хаяг шилжүүлэх.',
    'GH-001': 'Газрын эзэмшлийн гэрчилгээ авах.',
    'GH-002': 'Газрын эзэмшигч шилжүүлэх.',
    'GH-003': 'Газрын кадастрын мэдээлэл харах болон шалгах.',
    'TV-001': 'Хувь хүний орлогын татварын тайлан илгээх.',
    'TV-002': 'Аж ахуйн нэгжийг татварт бүртгэх хүсэлт.',
    'EM-001': 'Дорнод аймгийн эмнэлэгт цаг авах.',
    'EM-002': 'Эрүүл мэндийн даатгалын мэдээлэл шалгах.',
    'BL-001': 'Хүүхдийг сургуульд бүртгүүлэх.',
    'NH-001': 'Хүүхдийн мөнгөний мэдэгдэл болон дансны мэдээлэл харах.',
    'NH-002': 'Тэтгэврийн хэмжээ болон төлбөрийн мэдэгдэл шалгах.',
    'ZH-001': 'Тээврийн хэрэгсэл шинээр бүртгэх.',
    'ZH-002': 'Жолооны үнэмлэх авах эсвэл шинэчлэх өргөдөл.',
    'AA-001': 'Шинэ ХХК, компани бүртгэх.',
    'AA-002': 'Аж ахуйн тусгай зөвшөөрөл авах хүсэлт.',
  };

  function openModal(title, code) {
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalDesc').textContent = serviceDescs[code] || 'Доорх маягтыг бөглөн өргөдлөө илгээнэ үү.';
    document.getElementById('modalServiceCode').value = code;
    document.getElementById('modalRegister').value = '';
    document.getElementById('modalPhone').value = '';
    document.getElementById('modalDesc2').value = '';
    document.getElementById('modalOverlay').classList.add('active');
  }

  function closeModal() {
    document.getElementById('modalOverlay').classList.remove('active');
  }

  async function submitForm() {
    const register_no  = document.getElementById('modalRegister').value.trim();
    const phone        = document.getElementById('modalPhone').value.trim();
    const service_code = document.getElementById('modalServiceCode').value;
    const description  = document.getElementById('modalDesc2').value.trim();

    if (!register_no || !phone) {
      showToast('⚠️ Регистр болон утасны дугаар оруулна уу!');
      return;
    }

    const btn = document.getElementById('submitBtn');
    btn.disabled = true;
    btn.textContent = '⏳ Илгээж байна...';

    try {
      const res = await fetch('api/submit_application.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ register_no, phone, service_code, description })
      });
      const data = await res.json();

      if (data.success) {
        closeModal();
        showToast('✅ Өргөдөл бүртгэгдлээ! Дугаар: ' + data.data.app_number);
      } else {
        showToast('❌ ' + data.message);
      }
    } catch (e) {
      showToast('❌ Сервертэй холбогдож чадсангүй. XAMPP ажиллаж байгаа эсэхийг шалгана уу.');
    }

    btn.disabled = false;
    btn.textContent = '✅ Илгээх';
  }

  // =====================================================
  // СТАТУС ШАЛГАХ
  // =====================================================
  async function checkStatus() {
    const q = prompt('Өргөдлийн дугаар эсвэл регистрийн дугаараа оруулна уу:\n(жш: APP-2025-00001 эсвэл УА99012345)');
    if (!q) return;

    try {
      const res = await fetch('api/check_status.php?q=' + encodeURIComponent(q.trim()));
      const data = await res.json();

      if (data.success && data.data.length > 0) {
        const statusMn = { irsen:'🟡 Хүлээн авсан', havalj:'🔵 Хянаж байна', batalgaa:'🟢 Батлагдсан', duussen:'✅ Дууссан', tsutsgasan:'🔴 Цуцлагдсан' };
        let msg = '📋 ӨРГӨДЛИЙН МЭДЭЭЛЭЛ\n' + '─'.repeat(30) + '\n';
        data.data.forEach(r => {
          msg += `Дугаар: ${r.app_number}\nҮйлчилгээ: ${r.service_name}\nСтатус: ${statusMn[r.status] || r.status}\nОгноо: ${r.submitted_at}\n\n`;
        });
        alert(msg);
      } else {
        showToast('❌ ' + (data.message || 'Өргөдөл олдсонгүй'));
      }
    } catch(e) {
      showToast('❌ Сервертэй холбогдож чадсангүй');
    }
  }

  // =====================================================
  // НЭВТРЭХ — DATABASE
  // =====================================================
  async function doLogin() {
    const register_no = document.getElementById('loginRegister')?.value.trim();
    const phone       = document.getElementById('loginPhone')?.value.trim();

    if (!register_no || !phone) {
      showToast('⚠️ Регистр болон утасны дугаар оруулна уу!');
      return;
    }

    try {
      const res = await fetch('api/login.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ register_no, phone })
      });
      const data = await res.json();

      if (data.success) {
        document.getElementById('loginView').style.display = 'none';
        document.getElementById('profileView').style.display = 'block';
        showToast(data.data.is_new ? '✅ Шинэ данс үүсгэж нэвтэрлээ!' : '✅ Амжилттай нэвтэрлээ!');
        // Нэрийг харуулах
        const nameEl = document.getElementById('profileName');
        if (nameEl) nameEl.textContent = (data.data.first_name || '') + ' ' + (data.data.last_name || data.data.register_no);
      } else {
        showToast('❌ ' + data.message);
      }
    } catch(e) {
      showToast('❌ Сервертэй холбогдож чадсангүй. XAMPP ажиллаж байгаа эсэхийг шалгана уу.');
    }
  }

  function doLogout() {
    document.getElementById('profileView').style.display = 'none';
    document.getElementById('loginView').style.display = 'block';
    showToast('🚪 Системээс гарлаа');
    // Server session clear
    fetch('api/logout.php').catch(() => {});
  }

  // =====================================================
  // ХОЛБОО БАРИХ МАЯГТ — DATABASE
  // =====================================================
  async function sendContactForm() {
    const name    = document.getElementById('contactName')?.value.trim();
    const phone   = document.getElementById('contactPhone')?.value.trim();
    const email   = document.getElementById('contactEmail')?.value.trim();
    const subject = document.getElementById('contactSubject')?.value.trim();
    const message = document.getElementById('contactMessage')?.value.trim();

    if (!name || !phone || !message) {
      showToast('⚠️ Нэр, утас, мэдэгдэл заавал байна!');
      return;
    }

    try {
      const res = await fetch('api/contact.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, phone, email, subject, message })
      });
      const data = await res.json();
      if (data.success) {
        showToast('✅ ' + data.message);
        // Form цэвэрлэх
        ['contactName','contactPhone','contactEmail','contactSubject','contactMessage'].forEach(id => {
          const el = document.getElementById(id);
          if (el) el.value = '';
        });
      } else {
        showToast('❌ ' + data.message);
      }
    } catch(e) {
      showToast('❌ Сервертэй холбогдож чадсангүй');
    }
  }

  function showToast(msg) {
    const toast = document.getElementById('toast');
    toast.textContent = msg || '✅ Амжилттай!';
    toast.style.display = 'block';
    setTimeout(() => { toast.style.display = 'none'; }, 4000);
  }

  function switchTab(tab, el) {
    document.querySelectorAll('.acc-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.acc-panel').forEach(p => p.classList.remove('active'));
    el.classList.add('active');
    document.getElementById('tab-' + tab).classList.add('active');
  }

  function toggleFaq(el) {
    const ans = el.nextElementSibling;
    const tog = el.querySelector('.faq-toggle');
    ans.classList.toggle('open');
    tog.classList.toggle('open');
  }

  function setLang(l) {
    document.getElementById('lang-mn').style.color = l === 'mn' ? 'var(--orange-light)' : 'var(--gray)';
    document.getElementById('lang-en').style.color = l === 'en' ? 'var(--orange-light)' : 'var(--gray)';
    showToast(l === 'mn' ? '🇲🇳 Монгол хэлрүү шилжлээ' : '🇬🇧 Switched to English');
  }
</script>
</body>
</html>
