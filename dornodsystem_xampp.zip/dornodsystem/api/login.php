<?php
// =====================================================
// api/login.php
// Иргэн / Ажилтан нэвтрэх API
// POST /api/login.php
// =====================================================

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

require_once __DIR__ . '/../includes/db.php';

session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'POST хүсэлт шаардлагатай', null, 405);
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;

$register_no = trim($input['register_no'] ?? '');
$phone       = trim($input['phone'] ?? '');
$password    = $input['password'] ?? '';

if (!$register_no || (!$phone && !$password)) {
    jsonResponse(false, 'Регистрийн дугаар болон нууц үг/утас оруулна уу', null, 422);
}

$db = getDB();

// Хэрэглэгч хайх
$stmt = $db->prepare("SELECT * FROM users WHERE register_no = ? AND is_active = 1");
$stmt->execute([$register_no]);
$user = $stmt->fetch();

// Энгийн иргэн: утасны дугаараар нэвтэрнэ
if (!$user) {
    // Шинэ иргэн автоматаар бүртгэх (утасны дугаараар)
    if ($phone && preg_match('/^\d{8}$/', $phone)) {
        $hash = password_hash($phone, PASSWORD_BCRYPT);
        $ins = $db->prepare("INSERT INTO users (register_no, phone, password_hash, role) VALUES (?, ?, ?, 'irgenii')");
        $ins->execute([$register_no, $phone, $hash]);
        $userId = $db->lastInsertId();
        $user = ['id' => $userId, 'register_no' => $register_no, 'phone' => $phone, 'role' => 'irgenii', 'first_name' => '', 'last_name' => ''];
        
        // login огноо шинэчлэх
        $db->prepare("UPDATE users SET last_login = NOW() WHERE id = ?")->execute([$userId]);
        $db->prepare("UPDATE stats SET stat_value = stat_value + 1 WHERE stat_key = 'total_users'")->execute();
        
        $_SESSION['user_id']   = $userId;
        $_SESSION['register']  = $register_no;
        $_SESSION['role']      = 'irgenii';
        
        jsonResponse(true, 'Амжилттай бүртгэгдэж нэвтэрлээ', [
            'user_id'     => $userId,
            'register_no' => $register_no,
            'role'        => 'irgenii',
            'is_new'      => true,
        ]);
    }
    jsonResponse(false, 'Хэрэглэгч олдсонгүй', null, 401);
}

// Нууц үгээр шалгах (admin)
if ($password) {
    if (!password_verify($password, $user['password_hash'])) {
        jsonResponse(false, 'Нууц үг буруу байна', null, 401);
    }
} else {
    // Утасны дугаараар шалгах
    if ($user['phone'] !== $phone) {
        jsonResponse(false, 'Утасны дугаар буруу байна', null, 401);
    }
}

// Login хадгалах
$db->prepare("UPDATE users SET last_login = NOW() WHERE id = ?")->execute([$user['id']]);

$_SESSION['user_id']  = $user['id'];
$_SESSION['register'] = $register_no;
$_SESSION['role']     = $user['role'];

jsonResponse(true, 'Амжилттай нэвтэрлээ', [
    'user_id'     => $user['id'],
    'register_no' => $user['register_no'],
    'first_name'  => $user['first_name'],
    'last_name'   => $user['last_name'],
    'role'        => $user['role'],
    'is_new'      => false,
]);
