<?php
// =====================================================
// api/submit_application.php
// Өргөдөл илгээх API
// POST /api/submit_application.php
// =====================================================

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

require_once __DIR__ . '/../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'POST хүсэлт шаардлагатай', null, 405);
}

// Input авах (JSON эсвэл form-data)
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;

$register_no   = trim($input['register_no'] ?? '');
$phone         = trim($input['phone'] ?? '');
$service_code  = trim($input['service_code'] ?? '');
$description   = trim($input['description'] ?? '');

// Шалгах
if (!$register_no || !$phone || !$service_code) {
    jsonResponse(false, 'Бүх шаардлагатай талбарыг бөглөнө үү', null, 422);
}

if (!preg_match('/^[А-ЯӨҮа-яөүA-Z]{2}\d{8}$|^[А-ЯӨҮа-яөүA-Z]{2}\d{8}$/u', $register_no)) {
    jsonResponse(false, 'Регистрийн дугаар буруу формат байна (жш: УА99012345)', null, 422);
}

if (!preg_match('/^\d{8}$/', $phone)) {
    jsonResponse(false, 'Утасны дугаар 8 оронтой байна', null, 422);
}

$db = getDB();

// Үйлчилгээ олох
$stmt = $db->prepare("SELECT id, title FROM services WHERE code = ? AND is_active = 1");
$stmt->execute([$service_code]);
$service = $stmt->fetch();

if (!$service) {
    jsonResponse(false, 'Үйлчилгээ олдсонгүй: ' . $service_code, null, 404);
}

// Дугаар үүсгэх
$yearNum = date('Y');
$countStmt = $db->query("SELECT COUNT(*) FROM applications WHERE YEAR(submitted_at) = $yearNum");
$count = (int)$countStmt->fetchColumn() + 1;
$app_number = 'APP-' . $yearNum . '-' . str_pad($count, 5, '0', STR_PAD_LEFT);

// Хэрэглэгч session байвал авах (энгийн хувилбарт NULL)
$user_id = $_SESSION['user_id'] ?? null;

// Хадгалах
$insert = $db->prepare("
    INSERT INTO applications (app_number, user_id, service_id, service_code, register_no, phone, description, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'irsen')
");
$insert->execute([$app_number, $user_id, $service['id'], $service_code, $register_no, $phone, $description]);

// Статистик шинэчлэх
$db->exec("UPDATE stats SET stat_value = stat_value + 1 WHERE stat_key = 'total_applications'");

jsonResponse(true, 'Өргөдөл амжилттай бүртгэгдлээ', [
    'app_number'   => $app_number,
    'service_name' => $service['title'],
    'status'       => 'irsen',
    'submitted_at' => date('Y-m-d H:i:s'),
]);
