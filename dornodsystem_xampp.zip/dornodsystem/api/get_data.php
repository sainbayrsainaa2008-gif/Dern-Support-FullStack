<?php
// =====================================================
// api/get_data.php
// Үйлчилгээ, мэдээ, статистик авах API
// GET /api/get_data.php?type=services
// GET /api/get_data.php?type=news
// GET /api/get_data.php?type=stats
// GET /api/get_data.php?type=services&cat=irged
// =====================================================

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../includes/db.php';

$type = $_GET['type'] ?? 'services';
$cat  = $_GET['cat']  ?? '';
$db   = getDB();

switch ($type) {
    // --- Үйлчилгээнүүд ---
    case 'services':
        if ($cat) {
            $stmt = $db->prepare("SELECT * FROM services WHERE category = ? AND is_active = 1 ORDER BY id");
            $stmt->execute([$cat]);
        } else {
            $stmt = $db->query("SELECT * FROM services WHERE is_active = 1 ORDER BY category, id");
        }
        jsonResponse(true, '', $stmt->fetchAll());

    // --- Мэдээ ---
    case 'news':
        $limit = (int)($_GET['limit'] ?? 20);
        $stmt = $db->prepare("SELECT * FROM news WHERE is_published = 1 ORDER BY published_at DESC LIMIT ?");
        $stmt->execute([$limit]);
        jsonResponse(true, '', $stmt->fetchAll());

    // --- Статистик ---
    case 'stats':
        $stmt = $db->query("SELECT stat_key, stat_value, label FROM stats");
        $rows = $stmt->fetchAll();
        $result = [];
        foreach ($rows as $r) {
            $result[$r['stat_key']] = ['value' => $r['stat_value'], 'label' => $r['label']];
        }
        jsonResponse(true, '', $result);

    // --- Өргөдлүүд (admin) ---
    case 'applications':
        // TODO: session шалгах
        $limit = (int)($_GET['limit'] ?? 50);
        $status = $_GET['status'] ?? '';
        if ($status) {
            $stmt = $db->prepare("
                SELECT a.*, s.title as service_name
                FROM applications a LEFT JOIN services s ON a.service_id = s.id
                WHERE a.status = ? ORDER BY a.submitted_at DESC LIMIT ?
            ");
            $stmt->execute([$status, $limit]);
        } else {
            $stmt = $db->prepare("
                SELECT a.*, s.title as service_name
                FROM applications a LEFT JOIN services s ON a.service_id = s.id
                ORDER BY a.submitted_at DESC LIMIT ?
            ");
            $stmt->execute([$limit]);
        }
        jsonResponse(true, '', $stmt->fetchAll());

    default:
        jsonResponse(false, 'Буруу type параметр: ' . $type, null, 400);
}
