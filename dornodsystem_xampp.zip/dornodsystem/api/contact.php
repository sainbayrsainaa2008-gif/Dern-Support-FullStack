<?php
// =====================================================
// api/contact.php
// Холбоо барих мэдэгдэл хадгалах API
// POST /api/contact.php
// =====================================================

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

require_once __DIR__ . '/../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'POST хүсэлт шаардлагатай', null, 405);
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;

$name    = trim($input['name']    ?? '');
$phone   = trim($input['phone']   ?? '');
$email   = trim($input['email']   ?? '');
$subject = trim($input['subject'] ?? '');
$message = trim($input['message'] ?? '');

if (!$name || !$phone || !$message) {
    jsonResponse(false, 'Нэр, утас, мэдэгдэл заавал байна', null, 422);
}

$db = getDB();
$stmt = $db->prepare("INSERT INTO contact_messages (name, phone, email, subject, message) VALUES (?, ?, ?, ?, ?)");
$stmt->execute([$name, $phone, $email, $subject, $message]);

jsonResponse(true, 'Таны мэдэгдэл амжилттай хүлээн авлаа. Ажлын 1-2 өдрийн дотор холбогдоно.');
