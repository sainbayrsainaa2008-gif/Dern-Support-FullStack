<?php
// =====================================================
// api/check_status.php
// Өргөдлийн статус шалгах API
// GET /api/check_status.php?q=APP-2025-00001
// эсвэл ?q=УА99012345 (регистрийн дугаараар)
// =====================================================

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../includes/db.php';

$q = trim($_GET['q'] ?? '');
if (!$q) {
    jsonResponse(false, 'Өргөдлийн дугаар эсвэл регистрийн дугаар оруулна уу', null, 422);
}

$db = getDB();

// APP дугаараар эсвэл регистрийн дугаараар хайх
$stmt = $db->prepare("
    SELECT a.app_number, a.status, a.submitted_at, a.updated_at, a.description,
           s.title AS service_name, s.working_days
    FROM applications a
    LEFT JOIN services s ON a.service_id = s.id
    WHERE a.app_number = ? OR a.register_no = ?
    ORDER BY a.submitted_at DESC
    LIMIT 10
");
$stmt->execute([$q, $q]);
$rows = $stmt->fetchAll();

if (!$rows) {
    jsonResponse(false, 'Өргөдөл олдсонгүй. Дугаараа шалгаад дахин оролдоно уу.', null, 404);
}

$statusLabels = [
    'irsen'      => 'Хүлээн авсан',
    'havalj'     => 'Хянаж байна',
    'batalgaa'   => 'Батлагдсан',
    'duussen'    => 'Дууссан',
    'tsutsgasan' => 'Цуцлагдсан',
];

foreach ($rows as &$r) {
    $r['status_label'] = $statusLabels[$r['status']] ?? $r['status'];
}

jsonResponse(true, count($rows) . ' өргөдөл олдлоо', $rows);
