<?php
// =====================================================
// db.php — Мэдээллийн сангийн холболт
// XAMPP дээр ажиллуулахад энэ файлыг тохируулна
// =====================================================

define('DB_HOST', 'localhost');
define('DB_NAME', 'dornodsystem');
define('DB_USER', 'root');       // XAMPP default
define('DB_PASS', '');           // XAMPP default (нууц үг байвал энд бичнэ)
define('DB_CHARSET', 'utf8mb4');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['success' => false, 'message' => 'Мэдээллийн сантай холбогдож чадсангүй: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}

// JSON хариу буцаах тусгай функц
function jsonResponse(bool $success, string $message = '', $data = null, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data'    => $data,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}
