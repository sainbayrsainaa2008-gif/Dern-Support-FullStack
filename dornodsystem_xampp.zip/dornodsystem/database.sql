-- =====================================================
-- Дорнод аймгийн Цахим Шилжилт - Мэдээллийн Сан
-- XAMPP / phpMyAdmin дээр ажиллуулна
-- =====================================================

CREATE DATABASE IF NOT EXISTS dornodsystem CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dornodsystem;

-- -------------------------------------------------------
-- 1. ХЭРЭГЛЭГЧИД (users)
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    register_no VARCHAR(12) NOT NULL UNIQUE COMMENT 'Регистрийн дугаар',
    phone VARCHAR(20) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    email VARCHAR(150),
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('irgenii','admin') DEFAULT 'irgenii',
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- 2. ҮЙЛЧИЛГЭЭНҮҮД (services)
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(20) NOT NULL UNIQUE COMMENT 'IU-001 гэх мэт',
    category ENUM('irged','gazar','tatvar','eruel','bolov','halams','teever','aaan') NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    icon VARCHAR(10) DEFAULT '📄',
    is_free TINYINT(1) DEFAULT 1,
    fee_amount DECIMAL(10,2) DEFAULT 0,
    working_days INT DEFAULT 3,
    color_class VARCHAR(20) DEFAULT '',
    is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- 3. ӨРГӨДЛҮҮД (applications)
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    app_number VARCHAR(20) NOT NULL UNIQUE COMMENT 'APP-2025-00001',
    user_id INT,
    service_id INT,
    service_code VARCHAR(20),
    register_no VARCHAR(12) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    description TEXT,
    status ENUM('irsen','havalj','batalgaa','duussen','tsutsgasan') DEFAULT 'irsen',
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    processed_by INT NULL,
    notes TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE SET NULL,
    FOREIGN KEY (processed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- 4. МЭДЭЭ / ЗАРЛАЛ (news)
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS news (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    body TEXT,
    icon VARCHAR(10) DEFAULT '📰',
    type ENUM('news','zarliig','medegdel') DEFAULT 'news',
    published_at DATE NOT NULL,
    is_published TINYINT(1) DEFAULT 1,
    author_id INT,
    FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- 5. ХОЛБОО БАРИХ (contact_messages)
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(150),
    subject VARCHAR(255),
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------
-- 6. СТАТИСТИК (stats)
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS stats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    stat_key VARCHAR(50) NOT NULL UNIQUE,
    stat_value INT DEFAULT 0,
    label VARCHAR(100),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- АНХНЫ ӨГӨГДӨЛ
-- =====================================================

-- Статистик
INSERT INTO stats (stat_key, stat_value, label) VALUES
('total_services', 24, 'Нийт үйлчилгээ'),
('total_applications', 1284, 'Нийт өргөдөл'),
('total_users', 3421, 'Иргэн хэрэглэгч'),
('avg_days', 3, 'Дундаж өдөр');

-- Үйлчилгээнүүд
INSERT INTO services (code, category, title, description, icon, is_free, fee_amount, working_days, color_class) VALUES
('IU-001','irged','Иргэний үнэмлэх шинэчлэх','Иргэний үнэмлэхийг цахимаар шинэчлэх өргөдлөө илгээнэ үү.','🪪',0,3000,5,''),
('IU-002','irged','Хүүхэд төрсөн бүртгэл','Шинээр төрсөн хүүхдийн бүртгэл хийлгэх.','👶',1,0,3,'green'),
('IU-003','irged','Гэрлэлт бүртгэх','Гэрлэлт бүртгэх болон гэрчилгээ авах.','💍',0,2000,5,'orange'),
('IU-004','irged','Хаяг шилжүүлэх','Оршин суугаа хаяг шилжүүлэх.','🏠',1,0,2,''),
('GH-001','gazar','Газрын гэрчилгээ авах','Газрын эзэмшлийн гэрчилгээ авах.','📋',0,5000,10,'orange'),
('GH-002','gazar','Эзэмшигч шилжүүлэх','Газрын эзэмшигч шилжүүлэх.','🔄',0,3000,7,''),
('GH-003','gazar','Кадастрын мэдээлэл','Газрын кадастрын мэдээлэл харах.','🗺️',1,0,1,'green'),
('TV-001','tatvar','Татварын тайлан','Хувь хүний орлогын татварын тайлан илгээх.','💰',1,0,1,''),
('TV-002','tatvar','Татварт бүртгэх','Аж ахуйн нэгжийг татварт бүртгэх.','🏢',1,0,3,'orange'),
('EM-001','eruel','Эмнэлэгт цаг авах','Дорнод аймгийн эмнэлэгт цаг авах.','🏥',1,0,1,'green'),
('EM-002','eruel','Даатгал шалгах','Эрүүл мэндийн даатгалын мэдээлэл шалгах.','🛡️',1,0,1,'teal'),
('BL-001','bolov','Сургуульд бүртгүүлэх','Хүүхдийг сургуульд бүртгүүлэх.','🏫',1,0,3,'purple'),
('NH-001','halams','Хүүхдийн мөнгө','Хүүхдийн мөнгөний мэдэгдэл харах.','👨‍👩‍👧',1,0,1,'green'),
('NH-002','halams','Тэтгэвэр шалгах','Тэтгэврийн хэмжээ болон төлбөрийн мэдэгдэл.','👴',1,0,1,'orange'),
('ZH-001','teever','Тээврийн хэрэгсэл бүртгэх','Тээврийн хэрэгсэл шинээр бүртгэх.','🚗',0,15000,5,''),
('ZH-002','teever','Жолооны үнэмлэх','Жолооны үнэмлэх авах эсвэл шинэчлэх.','🪪',0,8000,7,'teal'),
('AA-001','aaan','Компани бүртгэл','Шинэ ХХК, компани бүртгэх.','🏢',0,12000,10,'purple'),
('AA-002','aaan','Тусгай зөвшөөрөл','Аж ахуйн тусгай зөвшөөрөл авах.','📜',0,20000,14,'red');

-- Мэдээ
INSERT INTO news (title, body, icon, type, published_at) VALUES
('Цахим үйлчилгээ шинэчлэгдлээ','2025 оноос эхлэн иргэний 14 үйлчилгээ цахимаар боломжтой болов.','📢','zarliig','2025-05-01'),
('Иргэний үнэмлэхийн хугацаа сунгалт','Иргэний үнэмлэхийн хугацаа дуусахаас 30 хоногийн өмнө сунгах боломжтой.','🪪','news','2025-04-15'),
('Газрын кадастрын систем шинэчлэгдлээ','Газрын кадастрын мэдээллийн сан шинэчлэгдэж, онлайнаар харах боломжтой болов.','🗺️','news','2025-04-10'),
('Татварын тайлангийн хугацаа сануулга','Хувь хүний татварын тайланг 2025 оны 5-р сарын 31-ний дотор илгээнэ үү.','💰','medegdel','2025-05-05'),
('Эмнэлэгт цаг авах системд өөрчлөлт','Цахимаар цаг авах хүсэлтийн хариуг SMS-ээр мэдэгдэх болов.','🏥','news','2025-04-20');

-- Анхны admin хэрэглэгч (нууц үг: admin123)
INSERT INTO users (register_no, phone, first_name, last_name, email, password_hash, role) VALUES
('AA00000001','88001234','Систем','Администратор','admin@dornodsystem.mn', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Туршилтын өргөдлүүд
INSERT INTO applications (app_number, register_no, phone, service_id, service_code, description, status) VALUES
('APP-2025-00001','УА99012345','88112233',1,'IU-001','Иргэний үнэмлэх хугацаа дууссан тул шинэчлэх хүсэлт','batalgaa'),
('APP-2025-00002','УА99012346','88112234',5,'GH-001','Газрын гэрчилгээ авах хүсэлт','havalj'),
('APP-2025-00003','УА99012347','88112235',10,'EM-001','Эмч Б.Дорж-д цаг авах хүсэлт','irsen'),
('APP-2025-00004','УА99012348','88112236',15,'ZH-001','Шинэ машин бүртгэх','duussen');
